// Advanced Robot Control System Ver.4.1
// 2011/07/21 Yuki YOKOKURA
//
// ARCS エントリポイント
//
// 本プログラムは全体的に亘ってエラー処理は行っていない。
// 可読性重視。動かないときは動かない。文句がある人は自分でやるべし(但し可読性向上に務めること)。
//
// -------- 以下コーティング既約 --------
//
// 改変した場合はコメントを添えて，Prameters.h の ConstParams::ARCS_REVISION を更新すること。
// 一時的にコメントアウトしたコードは最終的に消去すること。
// using namespace std; は例外なく使用禁止。
// 定数値は #define ではなく const を極力使用すること。
// グローバル変数の使用は極力回避すること。
// goto文の使用は極力回避すること。
// コメント文はなるべく付けて，コードとの相違がないようにすること。
// プロトタイプ宣言の引数変数は省略せずに書くこと。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "kbhit.hh"
#include "Parameters.hh"
#include "ARCSscreen.hh"
#include "RTAItask.hh"
#include "ControlFunctions.hh"

using namespace ARCS;

int main(void){
	// ここがすべての始まり
	
	ARCSscreen* ARCS = new ARCSscreen;				// ARCS画面初期化＆初期画面描画
	VariableParams* VarParams = new VariableParams;	// 様々な値を格納するVariableParamsクラス
	
	// ARCS開始指令入力画面の描画と入力の待機
	if(ARCS->CommandInput(ARCS_PHASE_START)==ARCS_ID_EXIT){
		// 入力された指令が「EXIT」の場合は，
		delete ARCS;		// ARCSを消去
		delete VarParams;	// Parameters消去
		return 0;			// 終了
	}
	
	// 制御ここから
	ARCS->Start();						// ARCS開始画面描画
	ControlFunctions* CtrlFuncs = new ControlFunctions;	// 制御用周期実行関数群の生成
	RTAItask* RtTasks = new RTAItask(	// RTAIタスクの生成
		ConstParams::THREAD_NUM,		// 動作させるスレッドの数
		(FuncPtrs)CtrlFuncs->pCFuncs,	// 制御用周期実行関数群への関数ポインタ
		CtrlFuncs,						// 関数ポインタ引数
		ConstParams::Ts					// 制御周期
	);
	CtrlFuncs->InitialProcess();		// 初期化モードの実行
	RtTasks->Start();					// RTAIタスクの開始
	while(!kbhit()){
		// 何かキーが押されるまでループ
		RtTasks->GetTimeValue(&VarParams->Time,VarParams->PeriodicTime,VarParams->ComputationTime);	// 時刻，周期，消費時間の取得
		CtrlFuncs->GetControlValue(VarParams);	// 制御用変数値を取得
		ARCS->PrintValue(VarParams);			// 各値の表示
		usleep(ConstParams::ARCS_UPDATE_TIME);	// 指定時間だけ待機
	}
	getchar();					// キー入力の都合上必要な"getchar"
	RtTasks->Stop();			// RTAIタスクの終了
	CtrlFuncs->ExitProcess();	// 終了処理モードの実行
	delete RtTasks;				// RTAIタスクの消去
	ARCS->Stop();				// ARCS終了画面描画
	// 制御ここまで
	
	// ARCS入力の待機
	if(ARCS->CommandInput(ARCS_PHASE_EXIT)==ARCS_ID_SAVEEXIT){
		// 入力された指令が「SAVE and EXIT」の場合は，
		CtrlFuncs->SaveDataFiles();
	}
	// 「DISCARD and EXIT」が入力された場合は何もしない
	
	delete CtrlFuncs;	// 制御用実行関数群の消去
	delete VarParams;	// Parameters消去
	delete ARCS;		// ARCS消去
	return 0;			// 終了
	
	// ここがすべての終わり
}



