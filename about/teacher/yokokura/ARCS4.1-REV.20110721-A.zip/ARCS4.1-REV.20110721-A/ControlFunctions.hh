// 制御用周期実行関数群クラス
// 2011/03/31 Yuki YOKOKURA
//
// 実際の制御プログラムを実行します。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef CONTROL_FUNCTIONS
#define CONTROL_FUCNTIONS

#include <math.h>
#include "Parameters.hh"
#include "PCI-3340.hh"
#include "PCI-6205.hh"
#include "DataStorage.hh"

namespace ARCS {	// ARCS名前空間
	enum CtrlFuncMode {
		CTRL_INIT,	// 初期化モード
		CTRL_LOOP,	// 周期モード
		CTRL_EXIT	// 終了処理モード
	};

	class ControlFunctions {
		private:
			// 制御用周期実行関数群
			static void ControlFunction0(ControlFunctions* pCF);	// 制御用周期実行関数0
			static void ControlFunction1(ControlFunctions* pCF);	// 制御用周期実行関数1
			static void ControlFunction2(ControlFunctions* pCF);	// 制御用周期実行関数2
			static void ControlFunction3(ControlFunctions* pCF);	// 制御用周期実行関数3
			static void ControlFunction4(ControlFunctions* pCF);	// 制御用周期実行関数4
			static void ControlFunction5(ControlFunctions* pCF);	// 制御用周期実行関数5
			static void ControlFunction6(ControlFunctions* pCF);	// 制御用周期実行関数6
			static void ControlFunction7(ControlFunctions* pCF);	// 制御用周期実行関数7
			
		public:
			ControlFunctions();									// コンストラクタ
			~ControlFunctions();								// デストラクタ
			void InitialProcess();								// 初期化モードの実行
			void ExitProcess();									// 終了処理モードの実行
			void SaveDataFiles();								// データファイルの保存
			void GetControlValue(VariableParams* VarParams);	// 制御用変数値を取得する関数
			void (*pCFuncs[8])(ControlFunctions*);				// 各制御用周期実行関数への関数ポインタ
	};
}

#endif

