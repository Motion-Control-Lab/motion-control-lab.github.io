// 定数値変数値格納用クラス
// 2011/04/12 Yuki YOKOKURA
//
// ARCSに必要な定数値および変数値を格納します。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef PARAMETERS
#define PARAMETERS

#include <string>
#include "DataStorage.hh"

using namespace ARCS;

// 定数値格納用名前空間 (参照するための using namespace は極力禁止)
namespace ConstParams {
	// ARCS改訂番号(ARCSコード改変時にちゃんと変えること)
	const char *const ARCS_REVISION = "[REV.20110721-A]";	// (16文字以内)
	
	// 実験データファイルの設定
	const char *const	DATA_NAME	= "DATA.csv";		// 		ファイル名
	const SaveType		DATA_TYPE	= STRG_FORMAT_CSV;	//		CSV形式「STRG_FORMAT_CSV」DAT形式(TAB区切り)「STRG_FORMAT_DAT」
	const double		DATA_TIME	= 10;				// [s]	保存時間
	const unsigned int	DATA_NUM	= 3;				//		保存する変数の数
	
	// RTAI実時間スレッドの設定
	const unsigned int THREAD_NUM = 2;	// 動作させるスレッドの数 (最大数8つまで)
	const unsigned long Ts[8]={
	//	s  m  u  n	制御周期は Ts[0] ≦ Ts[1] ≦ Ts[2] ≦ … ≦ Ts[7] になるようにすること
		    100000,	// [ns] 制御用周期実行関数0 (スレッド0) 制御周期
		    100000,	// [ns] 制御用周期実行関数1 (スレッド1) 制御周期
		   3000000,	// [ns] 制御用周期実行関数2 (スレッド2) 制御周期
		   4000000,	// [ns] 制御用周期実行関数3 (スレッド3) 制御周期
		   5000000,	// [ns] 制御用周期実行関数4 (スレッド4) 制御周期
		   6000000,	// [ns] 制御用周期実行関数5 (スレッド5) 制御周期
		   7000000,	// [ns] 制御用周期実行関数6 (スレッド6) 制御周期
		   8000000	// [ns] 制御用周期実行関数7 (スレッド7) 制御周期
	};
	
	// ARCSの設定
	const unsigned long ARCS_UPDATE_TIME = 50000;	// [us] ARCS画面描画の更新時間
	
	// 任意変数値表示の設定
	const unsigned int MAX_OPT_VARS = 8;		// 表示変数最大数
	const unsigned int NUM_OPT_VARS = 2;		// 表示したい変数の数 (最大数 8 まで)
	const std::string OPT_VAR_NAMES[MAX_OPT_VARS] = {
		"Fdis     [N]",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"Xres    [mm]",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
		"            ",	// 任意に表示したい変数値の変数名(12文字まで入力可)
	};
	
	// グラフA(上側)描画の設定
	const char *const	GRAPH_A_TITLE	= "FORCE [N]";	// グラフのタイトル
	const int 			GRAPH_A_YMAX	=  5;			// グラフの縦軸最大値 (整数のみ対応)
	const int			GRAPH_A_YMIN	= -5;			// グラフの縦軸最小値 (整数のみ対応)
	const unsigned int	MAX_GRAPH_A		=  8;			// グラフA変数最大値
	const unsigned int	GRAPH_A_NUM		=  1;			// 表示したい変数の数 (最大数 8 まで)
	const std::string	GRAPH_A_NAMES[MAX_GRAPH_A] = {
		"Fdis    ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
	};
	
	// グラフB(下側)描画の設定
	const char *const	GRAPH_B_TITLE	= "POSITION [mm]";	// グラフのタイトル
	const int 			GRAPH_B_YMAX	=  40;				// グラフの縦軸最大値 (整数のみ対応)
	const int			GRAPH_B_YMIN	= -40;				// グラフの縦軸最小値 (整数のみ対応)
	const unsigned int	MAX_GRAPH_B		=  8;				// グラフA変数最大値
	const unsigned int	GRAPH_B_NUM		=  1;				// 表示したい変数の数 (最大数 8 まで)
	const std::string	GRAPH_B_NAMES[MAX_GRAPH_B] = {
		"Xres    ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
		"        ",	// 凡例に表示する変数名 (8文字まで入力可)
	};
	
	
	// D/A変換器 PCI-3340 の設定 (ボード1枚目をA，2枚目をB，3枚目をC…)
	const unsigned int NUM_CH_3340 = 8; // PCI-3340 チャネル数
	// 先頭アドレスの設定
	// Interface Corp. "Device ID"=0x0D0C (scanpci -v か lspci -v で調べること)
	const int Base3340_A = 0x0000CA00;	// PCI-3340 1枚目 先頭アドレス0
	
	// エンコーダ計数器 PCI-6205 の設定 (ボード1枚目をA，2枚目をB，3枚目をC…)
	const unsigned int NUM_CH_6205 = 8; // PCI-6205 チャネル数
	// 先頭アドレスの設定
	// Interface Corp. "Device ID"=0x183D (scanpci -v か lspci -v で調べること)
	const int Base6205_A[4]={	// PCI-6205 1枚目 
		0x0000CF00,	// 先頭アドレス0
		0x0000CE00,	// 先頭アドレス1
		0x0000CD00,	// 先頭アドレス2
		0x0000CC00	// 先頭アドレス3
	};
	
	// 推力/トルク定数の設定 [D/A変換器 PCI-3340 1枚目 に対応するアクチュエータ]
	// アクチュエータのデータシートに従って変更すること
	const double Kf_A[NUM_CH_3340]={
		22,		// [N/A] or [Nm/A] CH1 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH2 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH3 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH4 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH5 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH6 アクチュエータ 推力 or トルク定数
		3.33,	// [N/A] or [Nm/A] CH7 アクチュエータ 推力 or トルク定数
		3.33	// [N/A] or [Nm/A] CH8 アクチュエータ 推力 or トルク定数
	};
	
	// 慣性の設定 [D/A変換器 PCI-3340 1枚目 に対応するアクチュエータ]
	// アクチュエータのデータシートに従って変更すること
	const double Mn_A[NUM_CH_3340]={
		0.3,	// [kg] or [kgm^2] CH1 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH2 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH3 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH4 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH5 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH6 アクチュエータ 慣性
		0.245,	// [kg] or [kgm^2] CH7 アクチュエータ 慣性
		0.245	// [kg] or [kgm^2] CH8 アクチュエータ 慣性
	};
	
	// 定格電流の設定 [D/A変換器 PCI-3340 1枚目 に対応するアクチュエータ]
	// アクチュエータのデータシートに従って変更すること
	const double Irat_A[NUM_CH_3340]={
		0.4,	// [A] CH1 アクチュエータ 定格電流
		0.81,	// [A] CH2 アクチュエータ 定格電流
		0.81,	// [A] CH3 アクチュエータ 定格電流
		0.81,	// [A] CH4 アクチュエータ 定格電流
		0.81,	// [A] CH5 アクチュエータ 定格電流
		0.81,	// [A] CH6 アクチュエータ 定格電流
		0.81,	// [A] CH7 アクチュエータ 定格電流
		0.81	// [A] CH8 アクチュエータ 定格電流
	};
	
	// 最大電流の設定 [D/A変換器 PCI-3340 1枚目 に対応するアクチュエータ]
	// アクチュエータのデータシートに従って変更すること
	const double Imax_A[NUM_CH_3340]={
		1.6,	// [A] CH1 アクチュエータ 最大電流
		2.7,	// [A] CH2 アクチュエータ 最大電流
		2.7,	// [A] CH3 アクチュエータ 最大電流
		2.7,	// [A] CH4 アクチュエータ 最大電流
		2.7,	// [A] CH5 アクチュエータ 最大電流
		2.7,	// [A] CH6 アクチュエータ 最大電流
		2.7,	// [A] CH7 アクチュエータ 最大電流
		2.7		// [A] CH8 アクチュエータ 最大電流
	};
	
	// サーボアンプ電圧電流換算ゲインの設定 [D/A変換器 PCI-3340 1枚目 に対応するサーボアンプ]
	// サーボアンプの設定に従い定数を変更すること
	// サーボアンプの設定例：3V/0.7275A → 3V 与えると 0.7275A 流す
	// 駆動電流の方向とエンコーダの方向に注意（向きが違う場合，下記の値は負になる）
	const double VAconv_A[NUM_CH_3340]={
		-3.0/0.154,	// [V/A] CH1 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH2 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH3 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH4 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH5 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH6 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275,	// [V/A] CH7 サーボアンプ電圧電流換算ゲイン
		3.0/0.7275	// [V/A] CH8 サーボアンプ電圧電流換算ゲイン
	};
	
	// エンコーダ分解能の設定 [エンコーダカウンタ PCI-6205 1枚目 に対応するエンコーダ]
	// エンコーダのデータシートに従って変更すること
	const double EncResolutions_A[NUM_CH_6205]={
		50e-9,	// [m] or [rad]	CH1 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH2 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH3 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH4 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH5 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH6 エンコーダ分解能
		100e-9,	// [m] or [rad]	CH7 エンコーダ分解能
		100e-9	// [m] or [rad]	CH8 エンコーダ分解能
	};

}

// Parametersクラス
// 実時間スレッド間，ARCS の間で共有される各種変数を格納する
// 以下の変数は Spinlock or Mutex で保護されるべきである(がとりあえず排他制御なしで様子見)
class VariableParams {
	private:
		
	public:
		// 以下はインターフェース関連の変数
		volatile double IrefA[ConstParams::NUM_CH_3340];	// [A] PCI-3340 1枚目 電流指令値
		volatile double XresA[ConstParams::NUM_CH_6205];	// [m] PCI-6205 1枚目 位置応答値
		
		// 以下はスレッド関連の変数
		volatile double Time;									// [s]  時刻 (一番速いスレッド THREAD0 の時刻)
		volatile long PeriodicTime[ConstParams::THREAD_NUM];	// [ns] 計測された制御周期
		volatile long ComputationTime[ConstParams::THREAD_NUM];	// [ns] 計測された消費時間
		
		// 以下は任意変数値表示のための変数
		volatile double OptionalVars[ConstParams::NUM_OPT_VARS];// ここに書き込めば好きな値を表示できる(最大8つまで)
		
		// 以下はグラフ描画関連の変数
		double GraphA[ConstParams::MAX_GRAPH_A];	// グラフA(上側)の表示値格納用
		double GraphB[ConstParams::MAX_GRAPH_B];	// グラフB(下側)の表示値格納用

};

#endif

