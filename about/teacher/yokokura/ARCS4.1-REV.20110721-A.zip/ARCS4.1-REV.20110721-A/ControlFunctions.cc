// 制御用周期実行関数群クラス
// 2011/03/31 Yuki YOKOKURA
//
// 実際の制御プログラムを実行します。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "ControlFunctions.hh"
#include "DistObsrv2.hh"		// 2次外乱オブザーバ
#include "PDcontroller.hh"		// PD制御器

using namespace ARCS;

// スレッド間での値のやり取りにはグローバル変数を使う
// 但し，無名名前空間内で宣言し変数のスコープをこのソース内に留めること
// Spinlock or Mutex による排他制御をすべきだが実際に問題が出てから実装する
namespace {	// 無名名前空間
	volatile CtrlFuncMode CmdFlag=CTRL_INIT;// 動作モード設定フラグ
	DataStorage* ExpData=0;					// 実験データ格納/保存クラスへのポインタ
	volatile unsigned long count=0;			// [回]	ループカウンタ (ControlFunction0を基準とする)
	volatile double t=0;					// [s]	時刻 (ControlFunction0を基準とする)
	volatile double GraphA[ConstParams::MAX_GRAPH_A]={0};		//		グラフA(上側)の表示値格納用 (ここに書き込めば好きな値を描画できる(最大8つまで))
	volatile double GraphB[ConstParams::MAX_GRAPH_B]={0};		//		グラフB(下側)の表示値格納用 (ここに書き込めば好きな値を描画できる(最大8つまで))
	volatile double OptionalVars[ConstParams::MAX_OPT_VARS]={0};// 		任意変数値表示用 (ここに書き込めば好きな値を表示できる(最大8つまで))
	volatile double IrefA[ConstParams::NUM_CH_3340]={0};		// [A]	D/Aコンバータ      1枚目 電流指令値
	volatile double XresA[ConstParams::NUM_CH_6205]={0};		// [m]	エンコーダカウンタ 1枚目 位置応答値
}

// 制御用周期実行関数群
// 以下の関数は初期化モード若しくは終了処理モードのときに非実時間空間上で動作する
// 周期モードのときは実時間スレッド( RTAItask.cc の RTAItask関数 で生成された RTAIthread.cc の RealTimeThread関数 )
// から関数ポインタを経由して，以下の関数が呼ばれる

void ControlFunctions::ControlFunction0(ControlFunctions* pCF){
	// 制御用周期実行関数0
	
	// 制御用定数設定
	static DAC3340* DacA;	// D/Aコンバータボード 1枚目
	static ENC6205* EncA;	// エンコーダカウンタボード 1枚目
	const double Ts = ConstParams::Ts[0]*1e-9;
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		DacA = new DAC3340(ConstParams::Base3340_A,ConstParams::Imax_A,ConstParams::VAconv_A);	// D/Aコンバータ 1枚目 初期化処理
		EncA = new ENC6205(ConstParams::Base6205_A,ConstParams::EncResolutions_A); 				// エンコーダカウンタ 1枚目 初期化処理
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
		count++;	// ループカウンタを進める
		t=count*Ts;	// 時刻の計算
		
		EncA->GetPositionRes(XresA);	// エンコーダカウンタボード 1枚目 から位置応答値を取得
		DacA->PutCurrentCmd(IrefA);	// D/Aコンバータボード 1枚目 から電流指令値を出力
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		delete DacA;	// D/Aコンバータボード 1枚目 終了処理
		delete EncA;	// エンコーダカウンタボード 1枚目 終了処理
	}
}

void ControlFunctions::ControlFunction1(ControlFunctions* pCF){
	// 制御用周期実行関数1
	
	// 制御用定数宣言
	const double Ts		= ConstParams::Ts[1]*1e-9;	// [s]		制御周期
	const double Kfn	= ConstParams::Kf_A[0];		// [N/A]	推力定数
	const double Mn		= ConstParams::Mn_A[0];		// [kg]		質量
	const double Kp		= 1000;						//			位置制御器比例ゲイン
	const double Kd		= 63;						//			位置制御器微分ゲイン
	const double gdis	= 300;						// [rad/s]	外乱オブザーバの帯域
	const double gpd	= 5000;						// [rad/s]	位置制御器擬似微分の帯域
	static DistObsrv2* DOB;							// 2次外乱オブザーバ
	static PDcontroller* PosCtrl;					// PD制御器
	
	// 制御用変数宣言
	static double Xcmd		= 0;	// [m]		位置指令値
	static double Iref		= 0;	// [A]		電流参照値
	static double XDDref	= 0;	// [m/s^2]	加速度参照値
	static double Xres		= 0;	// [m]		位置応答値
	static double Fdis		= 0;	// [N]		力応答値
	static double Data[ConstParams::DATA_NUM]={0};	// データ格納用変数
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		DOB		= new DistObsrv2(gdis,Mn,Kfn,Ts);	// 2次外乱オブザーバの生成
		PosCtrl	= new PDcontroller(Kp,Kd,gpd,Ts);	// 位置制御器の生成
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
		
		// 制御ここから
		Xres=XresA[0];							// [m]	位置応答値の取得
		
		Fdis=DOB->GetForce(Iref,Xres);			// [N]	力応答値の計算
		Xcmd=0;									// [m]	位置指令値の設定
		XDDref=PosCtrl->GetSignal(Xcmd-Xres);	// [m/s^2]	加速度参照値の計算
		Iref=XDDref*Mn/Kfn+Fdis/Kfn;			// [A]	電流参照値の計算
		
		IrefA[0]=Iref;							// [A]	電流参照値の出力
		// 制御ここまで
		
		// グラフ描画用
		GraphA[0]=Fdis;		// [N]	力応答値の描画
		GraphB[0]=Xres*1e3;	// [mm]	位置応答値の描画
		
		// 任意変数値表示用
		OptionalVars[0]=Fdis;		// [N]	力応答値の表示
		OptionalVars[1]=Xres*1e3;	// [mm]	位置応答値の表示
		
		// データの保存
		Data[0]=t;		// [s]	時刻の保存
		Data[1]=Fdis;	// [N]	力応答値の保存
		Data[2]=Xres;	// [m]	位置応答値の保存
		ExpData->PutData(Data,ConstParams::DATA_NUM);	// データ格納
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		delete DOB;		// 外乱オブザーバの消去
		delete PosCtrl;	// 位置制御器の消去
	}
}

void ControlFunctions::ControlFunction2(ControlFunctions* pCF){
	// 制御用周期実行関数2
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction3(ControlFunctions* pCF){
	// 制御用周期実行関数3
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction4(ControlFunctions* pCF){
	// 制御用周期実行関数4
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction5(ControlFunctions* pCF){
	// 制御用周期実行関数5
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction6(ControlFunctions* pCF){
	// 制御用周期実行関数6
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction7(ControlFunctions* pCF){
	// 制御用周期実行関数7
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(CmdFlag==CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(CmdFlag==CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(CmdFlag==CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::SaveDataFiles(){
	// データファイルの保存
	ExpData->SaveDataFile(ConstParams::DATA_NAME,ConstParams::DATA_TYPE);
}

void ControlFunctions::GetControlValue(VariableParams* VarParams){
	// 制御用変数値を取得する関数
	
	// memcpy，std::copy は使用不可(キャストによる volatile の無効化は禁止)
	unsigned int i;
	for(i=0;i<ConstParams::NUM_CH_3340;i++)VarParams->IrefA[i]=IrefA[i];				// [A]	D/Aコンバータ      1枚目 電流指令値
	for(i=0;i<ConstParams::NUM_CH_6205;i++)VarParams->XresA[i]=XresA[i];				// [m]	エンコーダカウンタ 1枚目 位置応答値
	for(i=0;i<ConstParams::GRAPH_A_NUM;i++)VarParams->GraphA[i]=GraphA[i];				//		グラフA(上側)の表示値
	for(i=0;i<ConstParams::GRAPH_B_NUM;i++)VarParams->GraphB[i]=GraphB[i];				//		グラフB(下側)の表示値
	for(i=0;i<ConstParams::NUM_OPT_VARS;i++)VarParams->OptionalVars[i]=OptionalVars[i];	// 		任意変数値表示用
}

void ControlFunctions::InitialProcess(){
	// 初期化モードの実行
	// 初期化モードでの各制御用周期実行関数の実行
	CmdFlag=CTRL_INIT;		// フラグを初期化モードに設定して，
	for(unsigned int i=0;i<ConstParams::THREAD_NUM;i++)(*pCFuncs[i])(this);	// 各々の制御関数(関数の配列)を実行
	CmdFlag=CTRL_LOOP;		// フラグを周期モードに設定
}

void ControlFunctions::ExitProcess(){
	// 終了処理モードの実行
	// 終了処理モードでの各制御用周期実行関数の実行
	CmdFlag=CTRL_EXIT;		// フラグを終了処理モードに設定して，
	for(unsigned int i=0;i<ConstParams::THREAD_NUM;i++)(*pCFuncs[i])(this);	// 各々の制御関数(関数の配列)を実行
}

ControlFunctions::ControlFunctions(){
	// コンストラクタ
	
	// 各制御用周期実行関数の関数ポインタを格納 (関数の配列となる)
	// (実時間スレッド生成に必要な作業)
	pCFuncs[0]=ControlFunction0;	pCFuncs[4]=ControlFunction4;
	pCFuncs[1]=ControlFunction1;	pCFuncs[5]=ControlFunction5;
	pCFuncs[2]=ControlFunction2;	pCFuncs[6]=ControlFunction6;
	pCFuncs[3]=ControlFunction3;	pCFuncs[7]=ControlFunction7;
	
	// データ格納クラスの生成
	ExpData = new ARCS::DataStorage(ConstParams::DATA_NUM,ConstParams::Ts[1],ConstParams::DATA_TIME);
}

ControlFunctions::~ControlFunctions(){
	// デストラクタ
	
	// データ格納クラスの消去
	delete ExpData;
}

