// PID制御器クラス
// 2011/02/16 Yuki YOKOKURA
//
// PID制御器 G(s) = Kp + Ki/s + Kd*s*gdis/(s+gdis) (双一次変換)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "PIDcontroller.hh"

using namespace ARCS;

PIDcontroller::PIDcontroller(double Pgain, double Igain, double Dgain, double Bandwidth, double SmplTime)
	// コンストラクタ
	// Pgain；比例ゲイン，Igain；積分ゲイン，Dgain；微分ゲイン，SmplTime；[s] 制御周期
	: Ts(SmplTime),		// [s]		制御周期の格納
	  Kp(Pgain),		// 			比例ゲインの格納
	  Ki(Igain),		// 			積分ゲインの格納
	  Kd(Dgain),		// 			微分ゲインの格納
	  gpd(Bandwidth),	// [rad/s]	擬似微分の帯域の格納
	  uZ1(0), uZ2(0), yZ1(0), yZ2(0)
{
	
}

PIDcontroller::~PIDcontroller(){
	// デストラクタ
}

double PIDcontroller::GetSignal(double u){
	// 出力信号の取得 u；入力信号
	double y;
	
	y = ( 2.0*Ts*(Ki+Kp*gpd)*(u-uZ2) + Ki*gpd*Ts*Ts*(u+2.0*uZ1+uZ2) + 4.0*(Kd*gpd+Kp)*(u-2.0*uZ1+uZ2) - (4.0-2.0*gpd*Ts)*yZ2 + 8.0*yZ1 )/(4.0+2.0*gpd*Ts);
	
	uZ2=uZ1;
	uZ1=u;
	yZ2=yZ1;
	yZ1=y;
	
	return y;
}

void PIDcontroller::SetPgain(double Pgain){
	// 比例ゲインの再設定 Pgain；比例ゲイン
	Kp=Pgain;
}

void PIDcontroller::SetIgain(double Igain){
	// 積分ゲインの再設定 Igain；積分ゲイン
	Ki=Igain;
}

void PIDcontroller::SetDgain(double Dgain){
	// 微分ゲインの再設定 Dgain；微分ゲイン
	Kd=Dgain;
}

void PIDcontroller::SetBandwidth(double Bandwidth){
	// 擬似微分の帯域の再設定 Bandwidth；[rad/s] 帯域
	gpd=Bandwidth;
}

void PIDcontroller::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts=SmplTime;	// [s] 制御周期の再設定
}

void PIDcontroller::ClearStateVars(void){
	// すべての状態変数のリセット
	uZ1=0;	// 状態変数1のゼロクリア
	uZ2=0;	// 状態変数2のゼロクリア
	yZ1=0;	// 状態変数3のゼロクリア
	yZ2=0;	// 状態変数4のゼロクリア
}


