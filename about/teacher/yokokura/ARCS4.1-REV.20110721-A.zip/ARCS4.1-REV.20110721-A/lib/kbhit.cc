// キーボード入力検知 (Unix版)
// 2011/02/14 Yuki YOKOKURA
//
// キーボードのボタンが何か押されたかどうか調べる
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "kbhit.hh"

int kbhit(void){
	// キー入力があった場合に1を返す なければ0を返す
	struct timeval tv;
	fd_set read_fd;
	tv.tv_sec=0;
	tv.tv_usec=0;
	FD_ZERO(&read_fd);
	FD_SET(0,&read_fd);
	if(select(1,&read_fd,NULL,NULL,&tv)==-1)return 0;	// キー入力がなかった
	if(FD_ISSET(0,&read_fd))return 1;					// キー入力があった
	return 0;
}


