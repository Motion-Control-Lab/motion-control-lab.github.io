// ノッチフィルタクラス
// 2011/02/14 Yuki YOKOKURA
//
// ノッチフィルタ G(s)=( s^2 + w^2 )/( s^2 + w/Q*s + w^2) (双一次変換)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef NOTCHFILTER
#define NOTCHFILTER

namespace ARCS {	// ARCS名前空間
	class NotchFilter {
		private:
			double Ts;	// [s]		制御周期
			double w;	// [rad/s]	遮断中心周波数
			double Q;	//			鋭さ
			double uZ1;	//			状態変数1 変数名Z1の意味はz変換のz^(-1)を示す
			double uZ2;	//			状態変数2
			double yZ1;	//			状態変数3
			double yZ2;	//			状態変数4
		
		public:
			NotchFilter(double AngFreq, double Sharp, double SmplTime);
			// コンストラクタ  AngFreq；[rad/s] 遮断中心周波数，Sharp；鋭さ，SmplTime；[s] 制御周期
			~NotchFilter();						// デストラクタ
			double GetSignal(double u);			// 出力信号の取得 u；入力信号
			void SetCuttoff(double AngFreq);	// 遮断中心周波数の再設定 AngFreq；[rad/s] 帯域
			void SetSharpness(double Sharp);	// 鋭さの再設定 Sharp；鋭さ
			void SetSmplTime(double SmplTime);	// 制御周期の再設定 SmplTime；[s] 制御周期
			void ClearStateVars(void);			// すべての状態変数のリセット
	};
}

#endif



