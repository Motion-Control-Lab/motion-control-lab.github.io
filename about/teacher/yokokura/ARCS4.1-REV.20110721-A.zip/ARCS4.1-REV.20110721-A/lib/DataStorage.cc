// データ格納/ファイル出力クラス
// 2011/03/14 Yuki YOKOKURA
//
// データを一時的に格納し，CSV/TAB区切りDATファイルとして出力します。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "DataStorage.hh"

using namespace ARCS;

DataStorage::DataStorage(const unsigned int NumOfVar, const unsigned long SmplTime, const double SaveTime)
	// コンストラクタ NumOfVar；変数の数，SmplTime；[ns] 制御周期，SaveTime；[s] 保存時間
	: N(NumOfVar),							// 変数の数
	  Ts(SmplTime),							// 制御周期
	  Tend(SaveTime),						// 保存する時間
	  tlen(((unsigned long)(Tend*1e9))/Ts),	// 保存する要素数
	  Data(0),								// データ格納用変数
	  count(0)								// 要素数カウンタ
{
	// データ格納領域の確保(二次元動的配列を連続したメモリ領域に確保)
	Data = new double*[N];
	Data[0] = new double[N*tlen];
	for(unsigned int i=1;i<N;i++)Data[i]=Data[0]+i*tlen;
}

DataStorage::~DataStorage(){
	// デストラクタ
	
	// データ格納領域の解放
	delete[] Data[0];
	delete[] Data;
}

void DataStorage::PutData(double* Value, unsigned int NumOfVar){
	// データの格納 Value；データ値，NumOfVar；変数の数
	
	// データの格納
	for(unsigned int k=0;k<NumOfVar;k++){
		if(k<N && count<tlen)Data[k][count]=Value[k];	// データ格納用変数の要素数未満のときだけデータを保持
	}
	
	// 要素数カウンタを進める
	count++;
}

bool DataStorage::SaveDataFile(const char* const FileName, const SaveType FileType){
	// CSV/DATファイルの保存 FileName；ファイル名，FileType；ファイル形式，戻り値；true=完了，false=失敗
	
	// ファイルストリーム
	std::ofstream fout(FileName, std::ios::out | std::ios::trunc);
	
	// エラーチェック
	if(fout.bad()==true)return false;	// 致命的なエラーの場合は終了
	if(fout.fail()==true)return false;	// ファイル開くのに失敗した場合は終了
	
	// 書式設定
	fout.setf(std::ios::scientific);	// 指数表示
	fout.width(15);						// 総桁数
	fout.precision(14);					// 小数点桁数
	
	// 実験データの書き出し
	unsigned int i;
	unsigned long j;
	for(j=0;j<tlen;j++){		// 時間分だけ回す
		for(i=0;i<N;i++){		// 変数の数だけ回す
			fout<<Data[i][j];	// 数値の書き出し
			if(i<N-1){
				if(FileType==STRG_FORMAT_CSV)fout<<',';		// CSVの場合はコンマで区切る
				if(FileType==STRG_FORMAT_DAT)fout<<'\t';	// DATの場合はタブで区切る
			}
		}
		fout<<std::endl;		// 改行
	}
	
	return true;
}

void DataStorage::ClearCounter(void){
	// 要素数カウンタをクリア
	count=0;
}

