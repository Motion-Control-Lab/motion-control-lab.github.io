// RTAI実時間スレッド生成・破棄クラス
// 2011/02/14 Yuki YOKOKURA
//
// RTAI実時間スレッドを生成・破棄する
// 実際に計測された制御周期や計算消費時間も提供する
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "RTAIthread.hh"

using namespace ARCS;

RTAIthread::RTAIthread(const char *Name, const unsigned long Time, const int Prio, void (* const RTfunc)(void*), void* const Arg)
	// コンストラクタ
	// Name；スレッド名，Time；制御周期，Prio；優先順位，RTfunc；制御用実行関数
	: StateFlag(RTID_STOP),	// 動作状態フラグを「停止状態」に設定
	  TaskName(Name),		// 実時間スレッド名の格納
	  Ts(Time),				// 制御周期の格納
	  Priority(Prio),		// 実時間スレッド優先順位の格納
	  pRTfunc(RTfunc),		// 制御用実行関数への関数ポインタを格納
	  pArg(Arg),			// 関数ポインタの引数の格納
	  RealTimeThread_ID(0),
	  NowTime(0),
	  PeriodicTime(0),		// 周期時間の初期化
	  ComputationTime(0)	// 消費時間の初期化
{
	RealTimeThread_ID = rt_thread_create( (void*)RealTimeThread, this, STACK_SIZE);	// 実時間スレッドを生成
}

RTAIthread::~RTAIthread(){
	// デストラクタ
	rt_thread_join(RealTimeThread_ID);	// 実時間スレッド 終了
}

void RTAIthread::RealTimeThread(RTAIthread *pParam){
	// RTAI 実時間スレッド
	RT_TASK *handler;		// ハンドラ
	RTIME period;			// 制御周期カウント値
	long time_sta=0;		// 計算開始時刻
	long time_sta_prev=0;	// 前回の計算開始時刻
	
	// ハンドラの初期化
	if (!(handler = rt_task_init(nam2num(pParam->TaskName), pParam->Priority, STACK_SIZE, 0))){
		pParam->StateFlag=RTID_ERROR;	// 動作状態フラグを「エラー検出」に設定
		return;							// 初期化ができなければ終了
	}
	
	period = nano2count(pParam->Ts);								// 制御周期をカウント値に変換
	rt_task_make_periodic(handler, rt_get_time() + period, period);	// 周期モードでアクティブ状態に移行
	rt_make_hard_real_time();										// ハードリアルタイムに設定
	
	pParam->NowTime=0;					// 時刻(=制御ループカウント)を0に設定
	pParam->StateFlag=RTID_RUN;			// 動作状態フラグを「動作中」に設定
	while(pParam->StateFlag!=RTID_STOP){// 動作状態フラグが「停止」に設定されるまでループ
		// ここからリアルタイム空間
		time_sta=(long)rt_get_time_ns();				// 計算開始時刻を記録
		pParam->PeriodicTime=time_sta-time_sta_prev;	// 現在の計算開始時刻から前回の計算開始時刻を減算して実際の周期時間を計算
		
		pParam->pRTfunc(pParam->pArg);		// 制御用関数の実行(関数ポインタにより、ここで実際の制御関数が呼ばれる)
		
		pParam->NowTime++;			// 時刻(=制御ループカウント)の計算
		time_sta_prev=time_sta;		// 次回用に今回の計算開始時刻を退避格納
		pParam->ComputationTime=(long)rt_get_time_ns()-time_sta;	// 計算終了時刻から計算開始時刻を減算して消費した計算時間を計算
		
		rt_task_wait_period();		// 次の周期まで待機
		// リアルタイム空間ここまで
	}
	
	rt_make_soft_real_time();		// ソフトリアルタイムに設定
	rt_task_delete(handler);		// ハンドラの削除
	pParam->StateFlag=RTID_EXCMPL;// 動作状態フラグを「終了動作完了」に設定

	return;
}

void RTAIthread::SendState(const int State){
	// 動作状態を書き込む
	// State；所望の動作状態
	StateFlag=State;
	return;
}

int RTAIthread::ReadState(void){
	// 動作状態を読み出す
	// 戻り値；現在の動作状態
	return StateFlag;
}

unsigned long RTAIthread::GetTime(void){
	// 時刻を取得する関数
	return NowTime;
}


long RTAIthread::GetSmplTime(void){
	// 計測された実際のサンプリング時間を取得する関数
	return PeriodicTime;
}

long RTAIthread::GetCompTime(void){
	// 計測された消費時間を取得する関数
	return ComputationTime;
}


