// Quarry行列 ＆ 逆Quarry行列
// 2011/02/14 Yuki YOKOKURA
//
// Quarry行列 (今のところ 2次，3次，5次 まで実装済み。n次自動生成はそのうち。)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef QUARRY
#define QUARRY

void Q2(double X, double Y, double *P, double *Q);								// 2次 Quarry行列
void Q2inv(double X, double Y, double *P, double *Q);							// 2次 逆Quarry行列
void Q3(double J1, double J2, double J3, double *M1, double *M2, double *M3);	// 3次 Quarry行列
void Q3inv(double M1, double M2, double M3, double *J1, double *J2, double *J3);// 3次 逆Quarry行列
void Q5(double J[5], double M[5]);												// 5次 Quarry行列
void Q5inv(double M[5], double J[5]);											// 5次 逆Qurry行列

#endif

