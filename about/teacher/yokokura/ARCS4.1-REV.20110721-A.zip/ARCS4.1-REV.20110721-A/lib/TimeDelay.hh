// 遅延器クラス
// 2011/02/16 Yuki YOKOKURA
//
// 遅延器 G(s)=e^(-s*T*n) -> G(z)=z^(-n)
// (但し T は制御周期で，制御周期単位でしか遅延時間を設定できないことに注意)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef TIMEDELAY
#define TIMEDELAY

namespace ARCS {	// ARCS名前空間
	class TimeDelay {
		private:
			TimeDelay(const TimeDelay&);					// コピーコンストラクタ使用禁止
			const TimeDelay& operator=(const TimeDelay&);	// 代入演算子使用禁止
			long dmem_max;	// 最大遅延時間
			long num;		// 遅延時間
			long Wcount;	// 書き込みカウンタ
			long Rcount;	// 読み出しカウンタ
			double* dmem;	// 遅延メモリ
			
		public:
			TimeDelay(const long MaxDelay);			// コンストラクタ MaxDelay；最大遅延時間
			~TimeDelay();							// デストラクタ
			double GetSignal(const double u);		// 出力信号の取得 u；入力信号
			void SetDelayTime(const long DelayTime);//遅延時間の設定 DelayTime；遅延時間 (最大遅延時間を越えないこと)
			void ClearDelayMemory(void);			// 遅延メモリのゼロクリア
	};
}

#endif



