// 統計処理
// 2011/02/14 Yuki YOKOKURA
//
// 平均，分散，標準偏差，共分散，相関係数の計算
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef STATISTICS
#define STATISTICS

#include <math.h>

double Average(const double *u, unsigned long N);							// 信号uの平均を計算する
double Variance(const double *u, unsigned long N);							// 信号uの分散を求める
double StandardDev(const double *u, unsigned long N);						// 信号uの標準偏差を求める
double Covariance(const double *u1, const double *u2, unsigned long N);		// 信号u1と信号u2の間の共分散を計算する
double Correlation(const double *u1, const double *u2, unsigned long N);	// 信号u1と信号u2の間の相関係数を求める

#endif

