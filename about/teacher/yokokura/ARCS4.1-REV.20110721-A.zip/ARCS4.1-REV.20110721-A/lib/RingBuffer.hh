// リングバッファクラス
// 2011/02/14 Yuki YOKOKURA
//
// リングバッファ
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef RINGBUFFER
#define RINGBUFFER

namespace ARCS {	// ARCS名前空間
	class RingBuffer {
		private:
			RingBuffer(const RingBuffer&);					// コピーコンストラクタ使用禁止
			const RingBuffer& operator=(const RingBuffer&);	// 代入演算子使用禁止
			unsigned long N;	// リングバッファの大きさ
			unsigned long i;	// リングバッファカウンタ
			double* Buffer;	// リングバッファ
		
		public:
			RingBuffer(unsigned long Length);	// コンストラクタ Length；リングバッファの大きさ
			~RingBuffer();						// デストラクタ
			void PutValue(double u);			// 値をバッファに格納(同時にバッファのカウンタが増加) u；入力値
			double GetValue(void);				// バッファから最後尾の値を取り出す 戻り値；出力値
			double* GetPointer(void);			// バッファへのポインタを返す
			void SetCounter(unsigned long j);	// カウンタを任意値に設定 j；任意のカウント値
			void ResetCounter(void);			// カウンタリセット
			void ClearBuffer(void);				// バッファのゼロクリア
	};
}

#endif



