// Quarry行列 ＆ 逆Quarry行列
// 2011/02/14 Yuki YOKOKURA
//
// Quarry行列 (今のところ 2次，3次，5次 まで実装済み。n次自動生成はそのうち。)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "Quarry.hh"

void Q2(double X, double Y, double *P, double *Q){
	// 2次 Quarry行列
	*P=(X+Y)/2.0;
	*Q=(X-Y)/2.0;
	
	return;
}

void Q2inv(double X, double Y, double *P, double *Q){
	// 2次 逆Quarry行列
	*P=X+Y;
	*Q=X-Y;
	
	return;
}

void Q3(double J1, double J2, double J3, double *M1, double *M2, double *M3){
	// 3次 Quarry行列
	*M1=(     J1 +J2 +J3 )/3.0;
	*M2=(         J2 -J3 )/3.0;
	*M3=( 2.0*J1 -J2 -J3 )/3.0;
	
	return;
}

void Q3inv(double M1, double M2, double M3, double *J1, double *J2, double *J3){
	// 3次 逆Quarry行列
	*J1= M1             +M3;
	*J2= M1 +1.5*M2 -0.5*M3;
	*J3= M1 -1.5*M2 -0.5*M3;
	
	return;
}

void Q5(double J[5], double M[5]){
	// 5次 Quarry行列
	M[0]=(     J[0] + J[1] + J[2] + J[3] + J[4] )/5.0;
	M[1]=(                          J[3] - J[4] )/5.0;
	M[2]=(               2.0*J[2] - J[3] - J[4] )/5.0;
	M[3]=(        3.0*J[1] - J[2] - J[3] - J[4] )/5.0;
	M[4]=( 4.0*J[0] - J[1] - J[2] - J[3] - J[4] )/5.0;
	
	return;
}

void Q5inv(double M[5], double J[5]){
	// 5次 逆Qurry行列
	J[0]=( 12.0*M[0]                                +12.0*M[4] )/12.0;
	J[1]=( 12.0*M[0]                      +15.0*M[3] -3.0*M[4] )/12.0;
	J[2]=( 12.0*M[0]            +20.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	J[3]=( 12.0*M[0] +30.0*M[1] -10.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	J[4]=( 12.0*M[0] -30.0*M[1] -10.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	
	return;
}


