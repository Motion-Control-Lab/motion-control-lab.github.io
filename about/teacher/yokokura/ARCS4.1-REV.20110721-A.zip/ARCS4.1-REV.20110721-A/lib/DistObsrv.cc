// 外乱オブザーバクラス
// 2011/02/18 Yuki YOKOKURA
//
// 1次形 外乱オブザーバ
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "DistObsrv.hh"

using namespace ARCS;

DistObsrv::DistObsrv(double Bandwidth, double Mass, double TrqConst, double SmplTime)
	// コンストラクタ
	// gdis；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
	// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
	: gdis(Bandwidth),	// [rad/s]			帯域
	  Mn(Mass),			// [kg]				慣性の格納
	  Kfn(TrqConst),	// [N/A] or [Nm/A]	推力orトルク定数の格納
	  Ts(SmplTime),		// [s]				制御周期の格納
	  Bp(0), C(0)
{
	
}

DistObsrv::~DistObsrv(){
	// デストラクタ
}

double DistObsrv::GetForce(double Iref, double XDres){
	// 推定外乱の取得 Iref；[A] 電流参照値，XDres；[m/s] or [rad/s] 速度応答値
	
	// 非公開ソースコード
	
	return 0;
}

void DistObsrv::SetBandwidth(double Bandwidth){
	// 帯域の再設定 gdis；[rad/s] 帯域
	gdis=Bandwidth;		// [rad/s] 帯域
}

void DistObsrv::SetInertia(double Mass){
	// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
	Mn	= Mass;			// [kg] 慣性の格納
}

void DistObsrv::SetTrqConst(double TrqConst){
	// 推力 or トルク定数の再設定 TrqConst；[N/A] or [Nm/A] 推力 or トルク定数
	Kfn	= TrqConst;		// [N/A] or [Nm/A] 推力orトルク定数の格納
}

void DistObsrv::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts	= SmplTime;		// [s] 制御周期の格納
}

void DistObsrv::ClearStateVars(void){
	// すべての状態変数のリセット
	Bp = 0;	// 	状態変数1
	C  = 0;	//	状態変数2
}



