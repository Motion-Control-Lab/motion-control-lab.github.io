// RTAI実時間スレッド生成・破棄クラス
// 2011/02/14 Yuki YOKOKURA
//
// RTAI実時間スレッドを生成・破棄する
// 実際に計測された制御周期や計算消費時間も提供する
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef RTAITHREADING
#define RTAITHREADING

#include <stdio.h>
#include <rtai_lxrt.h>
#include <sys/io.h>


namespace ARCS {	// ARCS名前空間
	// 動作状態の定義
	enum ThreadState {
		RTID_ERROR,	// エラー検出
		RTID_STOP,	// 停止状態
		RTID_RUN,	// 動作中
		RTID_EXCMPL	// 終了動作完了
	};
	
	class RTAIthread {
		// RTAI実時間スレッド生成クラス
		private:
			RTAIthread(const RTAIthread&);					// コピーコンストラクタ使用禁止
			const RTAIthread& operator=(const RTAIthread&);	// 代入演算子使用禁止
			static const int STACK_SIZE = 4096;	// スレッドスタックサイズ
			volatile int StateFlag;		// 動作状態フラグ
			const char *TaskName;		// 実時間スレッド名(6文字まで)
			const unsigned long Ts;		// 制御周期
			const int Priority;			// 実時間スレッド優先順位
			void (* const pRTfunc)(void*);	// 制御用実行関数へのポインタ
			void* const pArg;			// 関数ポインタの引数
			long RealTimeThread_ID;		// 実時間スレッド識別子
			unsigned long NowTime;		// 時刻 ( 稼働できる時間 = Ts*2^(sizeof(unsigned long)*8) = 100e-6*2^32 = 約119時間(例) ) 稼働時間を伸ばしたければ「unsigned long long」にする
			long PeriodicTime;			// 計測された実際の周期時間
			long ComputationTime;		// 計算によって消費された時間 (つまり ComputationTime < PeriodicTime でなければならない)
			static void RealTimeThread(RTAIthread *pParam);	// 実時間スレッド
			
		public:
			// コンストラクタ Name；スレッド名，Time；制御周期，Prio；優先順位，RTfunc；制御用実行関数(関数ポインタ)
			RTAIthread(const char *Name, const unsigned long Time, const int Prio, void (* const RTfunc)(void*), void* const Arg);
			~RTAIthread();				// デストラクタ
			void SendState(const int State);	// 動作状態を書き込む State；所望の動作状態
			int  ReadState(void);		// 動作状態を読み出す 戻り値；現在の動作状態
			unsigned long GetTime(void);// 時刻を取得する関数
			long GetSmplTime(void);		// 計測された実際のサンプリング時間を取得する関数
			long GetCompTime(void);		// 計測された消費時間を取得する関数
	};
}

#endif

