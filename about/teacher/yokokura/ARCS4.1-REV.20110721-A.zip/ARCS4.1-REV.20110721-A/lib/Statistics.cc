// 統計処理
// 2011/02/16 Yuki YOKOKURA
//
// 平均，分散，標準偏差，共分散，相関係数の計算
//
// 以下のコードが吐き出す値は未チェック。怪しいと思ったら要確認(2011/02/16)
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "Statistics.hh"

double Average(const double *u, unsigned long N){
	// 信号uの平均を計算する
	double ubar=0;
	unsigned long i;
	
	// 平均値を計算して返す
	for(i=0;i<N;i++)ubar=ubar+u[i];
	return ubar/(double)N;
}

double Variance(const double *u, unsigned long N){
	// 信号uの分散を求める
	double Ave, buff=0, y=0;
	unsigned long i;
	
	// uの平均を計算
	Ave=Average(u,N);
	
	// uから平均値を減算して標準偏差を計算して返す
	for(i=0;i<N;i++){
		buff=u[i]-Ave;
		y = y + buff*buff;
	}
	return y/(double)N;
}

double StandardDev(const double *u, unsigned long N){
	// 信号uの標準偏差を求める
	return sqrt(Variance(u,N));
}

double Covariance(const double *u1, const double *u2, unsigned long N){
	// 信号u1と信号u2の間の共分散を計算する
	double Ave1=0,Ave2=0,buff1=0,buff2=0,y=0;
	unsigned long i;
	
	// u1とu2の平均を計算
	Ave1=Average(u1,N);
	Ave2=Average(u2,N);
	
	// u1とu2から平均値を減算して共分散を計算して返す
	for(i=0;i<N;i++){
		buff1=u1[i]-Ave1;
		buff2=u2[i]-Ave2;
		y = y + buff1*buff2;
	}
	return y/(double)N;
}

double Correlation(const double *u1, const double *u2, unsigned long N){
	// 信号u1と信号u2の間の相関係数を求める
	double Ave1=0,Ave2=0,Cov=0,Std1=0,Std2=0,Corr=0;
	double buff1=0, buff2=0;
	unsigned long i=0;
	
	// u1とu2の平均を計算
	Ave1=Average(u1,N);
	Ave2=Average(u2,N);
	
	// u1とu2から平均値を減算して共分散と標準偏差を計算
	// (StandardDev関数とCovariance関数を使わないのは計算量を削減するため)
	for(i=0;i<N;i++){
		buff1=u1[i]-Ave1;
		buff2=u2[i]-Ave2;
		Cov  = Cov  + buff1*buff2;	// u1とu2共分散
		Std1 = Std1 + buff1*buff1;	// u1の標準偏差
		Std2 = Std2 + buff2*buff2;	// u2の標準偏差
	}
	
	// 最終的に相関係数を計算
	Corr=Cov/(sqrt(Std1)*sqrt(Std2));
	
	return Corr;
}

