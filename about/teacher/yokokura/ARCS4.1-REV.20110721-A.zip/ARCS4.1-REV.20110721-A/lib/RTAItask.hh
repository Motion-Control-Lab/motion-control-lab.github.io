// RTAIタスク＆実時間マルチスレッド生成・破棄クラス
// 2011/02/14 Yuki YOKOKURA
//
// RTAIタスクと複数個の実時間スレッドを生成・破棄する
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef RTAITASK
#define RTAITASK

#include <rtai_lxrt.h>
#include <string.h>
#include "RTAIthread.hh"


typedef void (**FuncPtrs)(void*);	// 関数ポインタ配列キャスト用

namespace ARCS {	// ARCS名前空間
	// 動作状態の定義
	enum TaskState {
		RTID_TASK_NORMAL,	// 正常
		RTID_TASK_ERR,		// タスク内エラー検出
		RTID_THRD_ERR		// スレッド内エラー検出
	};
	
	class RTAItask {
		private:
			RTAItask(const RTAItask&);					// コピーコンストラクタ使用禁止
			const RTAItask& operator=(const RTAItask&);	// 代入演算子使用禁止
			
			static const unsigned int	MAX_THREAD			= 128;	// スレッド最大数 (動的追従はあとで)
			static const int			STACK_SIZE			= 4096;	// RTAIスレッドスタックサイズ
			static const unsigned long	THREAD_EXIT_WAIT	= 50000;// [us] スレッド終了処理待機時間
			
			const unsigned int NumOfThread;			// 動作させるスレッドの数
			const unsigned long MinPeriodicTime;	// [ns] 一番速いスレッドの制御周期
			volatile int StateFlag;					// 動作状態フラグ
			RT_TASK *RTtaskID;						// 実時間タスク識別子
			RTAIthread* pRTthread[MAX_THREAD];		// 実時間スレッド 0 ～ MAX_THREAD へのポインタ
			
		public:
			// コンストラクタ
			RTAItask(
				const unsigned int ThreadNum,			// 動作させるスレッドの数
				void (** const PeriodicFuncs)(void*),	// 制御用周期実行関数群への関数ポインタ
				void* const FuncArgs,					// 関数ポインタ引数
				const unsigned long *PeriodicTime		// 制御周期
			);
			~RTAItask();					// デストラクタ
			void Start(void);				// 実時間スレッドを開始させる関数
			void Stop(void);				// 実時間スレッドを終了させる関数
			void SendState(const int State);// 動作状態を書き込む State；所望の動作状態
			int  ReadState(void);			// 動作状態を読み出す 戻り値；現在の動作状態
			// 開始からの経過時間と計算に要した消費時間を取得する関数
			void GetTimeValue(volatile double *Time, volatile long *PeriodicTime, volatile long *ComputationTime);
	};
}

#endif

