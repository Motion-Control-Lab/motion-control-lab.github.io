// リングバッファクラス
// 2011/02/14 Yuki YOKOKURA
//
// リングバッファ
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "RingBuffer.hh"

using namespace ARCS;

RingBuffer::RingBuffer(unsigned long Length)
	// コンストラクタ Length；リングバッファの大きさ
	: N(Length),	// バッファサイズ格納
	  i(0),			// バッファカウンタクリア
	  Buffer(0)
{
	Buffer=new double [N];	// バッファ生成
	ClearBuffer();			// バッファクリア
}

RingBuffer::~RingBuffer(){
	// デストラクタ
	delete [] Buffer;	// バッファ消去
}

void RingBuffer::PutValue(double u){
	// 値をバッファに格納(同時にバッファのカウンタが増加) u；入力値
	i++;			// リングバッファカウンタ
	if(N<=i)i=0;	// カウンタリセット
	Buffer[i]=u;	// バッファに入力値を格納
}

double RingBuffer::GetValue(void){
	// バッファから最後尾の値を取り出す 戻り値；出力値
	unsigned long j;
	if(i==N-1){		// バッファカウンタがリングの終端に達していたら，
		j=0;		// リングの先端へ
	}else{
		j=i+1;		// それ以外は最後尾へ
	}
	return Buffer[j];
}

double* RingBuffer::GetPointer(void){
	// バッファへのポインタを返す(この関数は本来あるべきではないが，あると大変便利なので用意しておく)
	return Buffer;
}

void RingBuffer::SetCounter(unsigned long j){
	// カウンタを任意値に設定 j；任意のカウント値
	i=j;
}

void RingBuffer::ResetCounter(void){
	// カウンタリセット
	i=0;
}

void RingBuffer::ClearBuffer(void){
	// バッファのゼロクリア
	for(unsigned long j=0;j<N;j++)Buffer[j]=0;
}



