// X-Tグラフ描画クラス
// 2011/02/07 Yuki YOKOKURA
//
// 画面上にグラフの描画を行います。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef GRAPHPLOT2D
#define GRAPHPLOT2D

#include <string>
#include <curses.h>
#include "FrameGraphics.hh"

class GraphPlot2D {
	// ２次元グラフ描画クラス
	private:
		GraphPlot2D(const GraphPlot2D&);					// コピーコンストラクタ使用禁止
		const GraphPlot2D& operator=(const GraphPlot2D&);	// 代入演算子使用禁止
		FrameGraphics *pFG;			// フレームグラフィックスクラスへのポインタ
		const char *Name;			// 縦軸の名前
		int Xcur, Ycur;				// グラフ左上のカーソル座標
		int Hcur, Wcur;				// グラフの幅と高さ(カーソル座標)
		int X, Y;					// グラフ左上の座標(ピクセル)
		int H, W;					// グラフの高さと幅(ピクセル)
		int Ymax, Ymid, Ymin;		// 縦軸の最大値，縦軸の真ん中の値，縦軸の最小値
		int YmaxLab, YminLab;		// 縦軸の最大値のラベル，縦軸の最小値のラベル
		int NumOfVar;				// 変数の大きさ
		int x1[8],y1[8],x2[8],y2[8];// グラフ描画用 座標格納変数
		int VerMax;					// 縦軸最大値ラベルのカーソル縦位置
		int VerMid;					// 縦軸中央値ラベルのカーソル縦位置
		int VerMin;					// 縦軸最小値ラベルのカーソル縦位置
		int HorMax;					// 横軸最大値ラベルのカーソル横位置
		int HorMid;					// 横軸中央値ラベルのカーソル横位置
		int HorMin;					// 横軸最小値ラベルのカーソル横位置
		short LineColor[8];			// グラフの線の色の設定用
		double Ax;					// RealXTOX用の換算係数
		double Ay,By;				// RealYToY用の換算係数
		int Hlaboffset;				// 横軸ラベルオフセット
		void DrawAxis(int Hoffset);	// 縦軸と横軸の描画を行う関数
		int Round(double x);		// 四捨五入をする関数
		int RealXToX(double u);		// 横軸の実数値から画面座標(ピクセル)に変換する関数
		int RealYToY(double u);		// 縦軸の実数値から画面座標(ピクセル)に変換する関数
		int YLimitter(int y);		// 縦軸プロットリミッタ (画面座標) グラフ領域をはみ出ないようにするための関数
		
	public:
		GraphPlot2D();			// コンストラクタ
		~GraphPlot2D();			// デストラクタ
		// グラフ軸の設定を行う関数 FG フレームグラフィックスクラスへのポインタ，AxisName 表示名，
		// PositionX グラフの横位置(カーソル座標)，PositionY グラフの縦位置(カーソル座標)
		// Height 高さ(カーソル座標)，Width 幅(カーソル座標)，縦軸最大値，縦軸最小値，プロットする変数の数
		void SetAxis(FrameGraphics &FG,const char *AxisName, int PositionX, int PositionY, int Height, int Width, int YmaxLabel, int YminLabel, int NumOfVariables);
		// 波形の描画を行う関数 t；時刻，Var；プロットする変数
		void DrawWave(volatile double t, double Var[8]);	
		// 凡例を描画する関数 N0～7；変数名
		void Legend(const std::string VarName[8]);
};


#endif

