// フレームバッファグラフィックスクラス
// 2011/02/07 Yuki YOKOKURA
//
// 画面上に図等の描画を行います。ただし，/dev/fb* が必要。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "FrameGraphics.hh"

FrameGraphics::FrameGraphics(const char* device)
	// コンストラクタ
	// フレームバッファを開いてメモリにマップする
	: FBfd(0), FBptr(0), finfo(), vinfo(), width(0), height(0), depth(0), size(0), length(0)
{
	// フレームバッファデバイスを開く
	FBfd = open(device, O_RDWR, 0);
	if(!FBfd){
		// 開けない時は終了
		printf("[FAILED] CANNOT OPEN %s !",device);
		return;
	}
	
	// 固定画面情報の取得
	ioctl(FBfd, FBIOGET_FSCREENINFO, &finfo);
	
	// 変動画面情報の取得
	ioctl(FBfd, FBIOGET_VSCREENINFO, &vinfo);
	width = vinfo.xres;
	height = vinfo.yres;
	depth = vinfo.bits_per_pixel;
	
	// 画面の大きさを計算 [bytes]
	size = width*height*sizeof(short);
	
	// フレームバッファの長さを計算
	length=size/sizeof(short);
	
	// フレームバッファをメモリにマップ
	FBptr = (short*)mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_SHARED, FBfd, 0);
	
}

FrameGraphics::~FrameGraphics(void){
	// デストラクタ
	// フレームバッファを閉じる
	munmap(FBptr, size);
	close(FBfd);
}

void FrameGraphics::ShowParam(void){
	// 画面情報の表示
	printf("WIDTH  = %d px \n",width);		// 画面の幅
	printf("HEIGHT = %d px \n",height);		// 画面の高さ
	printf("SIZE   = %d bytes \n",size);	// 画面サイズをバイト数で表示
	printf("DEPTH  = %d bits \n \n",depth);	// 色深度をビット数で表示
	return;
}

void FrameGraphics::DrawPoint(int x, int y, short color){
	// フレームバッファに点(x,y)を描画する
	// color：色
	int i=0;
	i=width*(y-1)+x;		// 座標からフレームバッファの要素番号を計算
	
	if(i<0)i=0;				// 要素番号リミッタ
	if(length<i)i=length-1;	// 要素番号リミッタ
	
	FBptr[i]=color;			// フレームバッファへ書き込み
	
	return;
}

void FrameGraphics::DrawLine(int x1, int y1, int x2, int y2, short color){
	// フレームバッファに直線(x1,y1)ー(x2,y2)を引く関数
	// color：色
	double a,b;
	int y,x,xsta,xend,ysta,yend;
	
	
	// 零割対策
	if(x2-x1!=0){
		a=(double)(y2-y1)/(double)(x2-x1);	// 直線の傾きを求める
		b=(double)y2-a*(double)x2;			// 直線の切片を求める
	}else{
		// 傾きが∞の時は，
		if(y1<y2){
			// y1→y2で増加する場合
			ysta=y1;
			yend=y2;
		}else{
			// y2→y1で増加する場合
			ysta=y2;
			yend=y1;
		}
		for(y=ysta;y<=yend;y++)DrawPoint(x1,y,color);
		return;
	}
	
	// 直線を綺麗に引くために，傾きによって x から y を計算するのか y から x を計算するのかを変える
	if(-1<a && a<1){
		// 傾きが±45度以内の場合はxからyを計算する
		if(x1<x2){
			// x1→x2で増加する場合
			xsta=x1;
			xend=x2;
		}else{
			// x2→x1で増加する場合
			xsta=x2;
			xend=x1;
		}
		for(x=xsta;x<=xend;x++){
			y=a*(double)x + b;
			DrawPoint(x,y,color);
		}
	}else{
		// 傾きが±45度以上の場合はyからxを計算する
		if(y1<y2){
			// y1→y2で増加する場合
			ysta=y1;
			yend=y2;
		}else{
			// y2→y1で増加する場合
			ysta=y2;
			yend=y1;
		}
		for(y=ysta;y<=yend;y++){
			x=((double)y-b)/a;
			DrawPoint(x,y,color);
		}
	}
	
	return;
}

void FrameGraphics::DrawRect(int x, int y, int w, int h, short color){
	// 長方形の描画をする（色は塗らない）
	// x, y；長方形左上の座標，w；長方形の幅，h；長方形の高さ，color；色
	DrawLine(x  , y  , x+w, y  , color);
	DrawLine(x+w, y  , x+w, y+h, color);
	DrawLine(x+w, y+h, x  , y+h, color);
	DrawLine(x  , y+h, x  , y  , color);
	return;
}

void FrameGraphics::DrawRectFill(int x, int y, int w, int h, short color){
	// 長方形の範囲内に色を塗る
	// x, y；長方形左上の座標，w；長方形の幅，h；長方形の高さ，color；色
	int i,j;
	
	for(j=y;j<=y+h;j++){
		for(i=x;i<=x+w;i++){
			DrawPoint(i,j,color);
		}
	}
	
	return;
}

void FrameGraphics::ClearScreen(void){
	// 全画面を真っ黒にする
	memset(FBptr,FG_COLOR_BLACK,length-1);
	return;
}

void FrameGraphics::ClearRect(int x, int y, int w, int h){
	// 長方形の範囲内を消去
	// x, y；長方形左上の座標，w；長方形の幅，h；長方形の高さ
	
	DrawRectFill(x,y,w,h,FG_COLOR_BLACK);
	
	return;
}

int FrameGraphics::GetWidth(void){
	return width;
}

int FrameGraphics::GetHeight(void){
	return height;
}

