// X-Tグラフ描画クラス
// 2011/02/07 Yuki YOKOKURA
//
// 画面上にグラフの描画を行います。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#include "GraphPlot2D.hh"

GraphPlot2D::GraphPlot2D()
	// コンストラクタ
	: pFG(0), Name(""), Xcur(0), Ycur(0), Hcur(0), Wcur(0), X(0), Y(0), H(0), W(0),
	  Ymax(0), Ymid(0), Ymin(0), YmaxLab(0), YminLab(0), NumOfVar(0),
	  VerMax(0), VerMid(0), VerMin(0), HorMax(0), HorMid(0), HorMin(0), Ax(0), Ay(0), By(0), Hlaboffset(0)
{
	// グラフの線の色の定義
	LineColor[0]=FG_COLOR_RED;
	LineColor[1]=FG_COLOR_GREEN;
	LineColor[2]=FG_COLOR_BLUE;
	LineColor[3]=FG_COLOR_CYAN;
	LineColor[4]=FG_COLOR_MAGENTA;
	LineColor[5]=FG_COLOR_YELLOW;
	LineColor[6]=FG_COLOR_WHITE;
	LineColor[7]=FG_COLOR_GRAY50;
	
}

GraphPlot2D::~GraphPlot2D(){
	// デストラクタ
}

void GraphPlot2D::SetAxis(FrameGraphics &FG, const char *AxisName, int PositionX, int PositionY, int Height, int Width, int YmaxLabel, int YminLabel, int NumOfVariables){
	// 2次元グラフ設定関数
	// FG フレームグラフィックスクラスへのポインタ，AxisName 表示名，
	// PositionX グラフの横位置(カーソル座標)，PositionY グラフの縦位置(カーソル座標)
	// Height 高さ(カーソル座標)，Width 幅(カーソル座標)，縦軸最大値，縦軸最小値，プロットする変数の数
	
	int i;	// プロットする変数の数カウンタ
	
	Name=AxisName;				// グラフの名前を設定
	Xcur=PositionX;				// グラフの横位置を設定
	Ycur=PositionY;				// グラフの縦位置を設定
	Hcur=Height;				// グラフの高さを設定
	Wcur=Width;					// グラフの幅を設定
	X=(PositionX+3)*8;			// グラフの左上の画面座標を計算 [px] (1文字あたり 8px × 16px として計算)
	Y=(PositionY+1)*16;			// グラフの左上の画面座標を計算 [px] (1文字あたり 8px × 16px として計算)
	H=Height*16;				// グラフの高さを計算 [px] (1文字あたり 8px × 16px として計算)
	W=Width*8;					// グラフの幅を計算 [px]   (1文字あたり 8px × 16px として計算)
	
	VerMax = Ycur+1;				// 縦軸最大値ラベルのカーソル縦位置
	VerMid = Ycur+Round(Hcur/2)+1;	// 縦軸中央値ラベルのカーソル縦位置
	VerMin = Ycur+Hcur;				// 縦軸最小値ラベルのカーソル縦位置
	HorMax = Xcur+Wcur+2;				// 横軸最大値ラベルのカーソル横位置
	HorMid = Xcur+Round(Wcur/2);	// 横軸中央値ラベルのカーソル横位置
	HorMin = Xcur+3;				// 横軸最小値ラベルのカーソル横位置
	
	Ymax=VerMax*16+8;	// 縦軸の最大値の座標を計算 (1文字あたり 8px × 16px として計算)
	Ymid=VerMid*16+8;	// 縦軸の中央値の座標を計算 (1文字あたり 8px × 16px として計算)
	Ymin=VerMin*16+8;	// 縦軸の最小値の座標を計算 (1文字あたり 8px × 16px として計算)
	YmaxLab=YmaxLabel;			// 縦軸の最大値を設定
	YminLab=YminLabel;			// 縦軸の最小値を設定
	
	NumOfVar=NumOfVariables;	// プロットする変数の数を設定
	for(i=0;i<NumOfVar;i++){	// プロットする変数数だけ回す
		x1[i]=X;y1[i]=Ymid;x2[i]=X;y2[i]=Ymid;	// 線描画開始位置と終了位置をグラフの原点に初期化
	}
	
	pFG=&FG;					// フレームグラフィックスへのポインタを格納
	
	// RealXToX，RealYToY用の換算係数の計算(実数値から画面座標への変換係数)
	Ax=(double)W/(20.0-0.0);
	Ay=(double)(Ymax-Ymin)/((double)YmaxLab-(double)YminLab);
	By=-Ay*(YmaxLab+YminLab)/2.0+(double)Y+(double)H/2.0;
	
	DrawAxis(0);					// グラフの軸を描画
}

void GraphPlot2D::DrawAxis(int Hoffset){
	// 2次元グラフXY軸描画関数
	// Hoffset；横軸ラベルオフセット値
	
	mvprintw(Ycur,Xcur,"%s",Name);						// グラフの名前を描画
	
	// 縦軸ラベルの描画
	mvprintw(VerMax,Xcur,"%3d",YmaxLab);				// 縦軸の最大値を描画
	mvprintw(VerMid,Xcur,"%3d",(YmaxLab+YminLab)/2);	// 縦軸の中央値を描画
	mvprintw(VerMin,Xcur,"%3d",YminLab);				// 縦軸の最小値を描画
	
	// 横軸ラベルの描画
	mvprintw(Ycur+Hcur+1,HorMin,"%d",Hoffset);
	mvprintw(Ycur+Hcur+1,HorMid+2,"%d",Hoffset+10);
	mvprintw(Ycur+Hcur+1,HorMax-1,"%d",Hoffset+20);
	mvprintw(Ycur+Hcur+2,HorMid-1,"TIME [s]");
	refresh();											// 画面を更新
	
	// グラフの枠を描画
	pFG->DrawRect(X,Y,W,H,FG_COLOR_WHITE);
	
	// グラフの目盛線を描画
	pFG->DrawLine(X+1,Ymax,X+W-1,Ymax,FG_COLOR_GRAY25);			// 縦軸最大値の目盛りを描画
	pFG->DrawLine(X+1,Ymid,X+W-1,Ymid,FG_COLOR_GRAY25);			// 縦軸中央値の目盛りを描画
	pFG->DrawLine(X+1,Ymin,X+W-1,Ymin,FG_COLOR_GRAY25);			// 縦軸最小値の目盛りを描画
	pFG->DrawLine(X+W/2,Y+H-1,X+W/2,Y+1,FG_COLOR_GRAY25);		// 横軸中央値の目盛りを描画
	pFG->DrawLine(X+W/4,Y+H-1,X+W/4,Y+1,FG_COLOR_GRAY25);		// 横軸1/4の目盛りを描画
	pFG->DrawLine(X+W/4*3,Y+H-1,X+W/4*3,Y+1,FG_COLOR_GRAY25);	// 横軸3/4の目盛りを描画
	
}

int GraphPlot2D::Round(double x){
	// 四捨五入
	int a;
	x += 0.5;
	a = x;
	return a;
}

void GraphPlot2D::DrawWave(volatile double t, double Var[8]){
	// 波形の描画を行う関数
	// t；時刻，Var；プロットする変数
	
	int i;							// プロットする変数の数カウンタ
	
	t-=Hlaboffset;					// 時刻を0～20秒の範囲にする(20秒経過したら0秒に戻す)
	if(20<t){
		// 時刻20秒を超えたら，
		pFG->ClearRect(X,Y,W,H);	// グラフ領域を真っ黒にする
		DrawAxis(Hlaboffset+=20);	// グラフ軸の描画(横軸ラベルは20秒毎に増加するように設定)
		for(i=0;i<NumOfVar;i++){	// プロットする変数の数だけ回す
			x2[i]=X+1;				// 線描画開始位置をグラフの原点に初期化
		}
		// ここのif文は何をやっているかというと，プロット画面が右端まで行ったらグラフをリセットしている
	}else{
		for(i=0;i<NumOfVar;i++){				// プロットする変数の数だけ回す
			x1[i]=x2[i];						// 前回の直線の終点を今回の直線の始点にする
			y1[i]=y2[i];						// 前回の直線の終点を今回の直線の始点にする
			x2[i]=RealXToX(t);					// 時刻を画面座標に変換して直線の終点とする
			y2[i]=YLimitter(RealYToY(Var[i]));	// 入力変数値を画面座標に変換して直線の終点とする
			pFG->DrawLine(x1[i],y1[i],x2[i],y2[i],LineColor[i]);	// 直線の描画
		}
	}
}

int GraphPlot2D::RealXToX(double u){
	// 横軸の実数値から画面座標(ピクセル)に変換する関数
	return Ax*(double)u+(double)X;
}

int GraphPlot2D::RealYToY(double u){
	// 縦軸の実数値から画面座標(ピクセル)に変換する関数
	return Ay*(double)u+By;
}

int GraphPlot2D::YLimitter(int y){
	// 縦軸プロットリミッタ (画面座標)
	// グラフ領域をはみ出ないようにするための関数
	if(y<Y)y=Y;			// グラフの上側を超えるようなら制限
	if((Y+H)<y)y=(Y+H);	// グラフの下側を超えるようなら制限
	
	return y;
}

void GraphPlot2D::Legend(const std::string VarName[8]){
	// 凡例を描画する関数
	// Name0～7；変数名
	int i;
	
	for(i=0;i<NumOfVar;i++){
		mvprintw(Ycur,Xcur+24+13*i,"%s",VarName[i].c_str());	// 変数名を表示
	}
	move(Xcur,Ycur);					// グラフ原点位置にカーソルを戻す
	refresh();							// 画面更新
	
	// 凡例の線を描画
	for(i=0;i<NumOfVar;i++){
		pFG->DrawRectFill(X+8*(18+13*i),Y-9,18,1,LineColor[i]);
	}
	pFG->DrawRect(X,Y,W,H,FG_COLOR_WHITE);	// グラフの枠が欠けてしまうので再描画

}

