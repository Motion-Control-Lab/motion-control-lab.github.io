// 外乱オブザーバクラス
// 2011/02/18 Yuki YOKOKURA
//
// 1次形 外乱オブザーバ
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef DISTOBSRV
#define DISTOBSRV

namespace ARCS {	// ARCS名前空間
	class DistObsrv {
		private:
			double gdis;	// [rad/s]			帯域
			double Mn;		// [kg] or [kgm^2]	慣性
			double Kfn;		// [N/A] or [Nm/A]	推力 or トルク定数
			double Ts;		// [s]				制御周期
			double Bp;		// 					状態変数1
			double C;		// 					状態変数2
		
		public:
			DistObsrv(double Bandwidth, double Mass, double TrqConst, double SmplTime);
			// コンストラクタ
			// Bandwidth；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
			// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
			~DistObsrv();								// デストラクタ
			double GetForce(double Iref, double XDres);	// 推定外乱の取得 Iref；[A] 電流参照値，XDres；[m/s] or [rad/s] 速度応答値
			void SetBandwidth(double Bandwidth);		// 帯域の再設定 gdis；[rad/s] 帯域
			void SetInertia(double Mass);				// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
			void SetTrqConst(double TrqConst);			// 推力 or トルク定数の再設定 TrqConst；[N/A] or [Nm/A] 推力 or トルク定数
			void SetSmplTime(double SmplTime);			// 制御周期の再設定 SmplTime；[s] 制御周期
			void ClearStateVars(void);					// すべての状態変数のリセット
	};
}

#endif



