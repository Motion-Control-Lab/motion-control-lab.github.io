// 外乱オブザーバクラス
// 2011/02/09 Yuki YOKOKURA
//
// 2次形 外乱オブザーバ
//
// 詳細は以下の論文を参照のこと。
// K. Ohnishi, M. Shibata, and T. Murakami : "Motion Control for Advanced Mechatronics"
// IEEE/ASME Trans. on Mechatronics, Vol. 1, No. 1, Mar. 1996.
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef DISTOBSRV2
#define DISTOBSRV2

namespace ARCS {	// ARCS名前空間
	class DistObsrv2 {
		private:
			double k1;		// 帯域を決める係数 k1
			double k2;		// 帯域を決める係数 k2
			double Mn;		// [kg] or [kgm^2]	慣性
			double Kfn;		// [N/A] or [Nm/A]	推力 or トルク定数
			double Ts;		// [s]				制御周期
			double z1Z1;	// 					状態変数1
			double z2Z1;	//					状態変数2
			double IrefZ1;	// [A]				状態変数 電流参照値
			double XresZ1;	// [m] or [rad]		状態変数 位置応答値
		
		public:
			DistObsrv2(double gdis, double Mass, double TrqConst, double SmplTime);
			// コンストラクタ
			// gdis；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
			// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
			~DistObsrv2();								// デストラクタ
			double GetForce(double Iref, double Xres);	// 推定外乱の取得 Iref；[A] 電流参照値，Xres；[m] or [rad] 位置応答値
			void SetBandwidth(double gdis);				// 帯域の再設定 gdis；[rad/s] 帯域
			void SetInertia(double Mass);				// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
			void SetTrqConst(double TrqConst);			// 推力 or トルク定数の再設定 TrqConst；[N/A] or [Nm/A] 推力 or トルク定数
			void SetSmplTime(double SmplTime);			// 制御周期の再設定 SmplTime；[s] 制御周期
			void ClearStateVars(void);					// すべての状態変数のリセット
	};
}

#endif



