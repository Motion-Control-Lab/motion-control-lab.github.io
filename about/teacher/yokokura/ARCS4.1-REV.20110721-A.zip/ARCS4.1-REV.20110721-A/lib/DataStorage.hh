// データ格納/ファイル出力クラス
// 2011/02/20 Yuki YOKOKURA
//
// データを一時的に格納し，CSV/TAB区切りDATファイルとして出力します。
//
// Copyright (C) 2011 Yuki YOKOKURA
// This program is free software;
// you can redistribute it and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 3 of the License, or any later version.
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
// Besides, you can negotiate about other options of licenses instead of GPL.
// If you would like to get other licenses, please contact us<yuki@katsura.sd.keio.ac.jp>.

#ifndef DATASTORAGE
#define DATASTORAGE

#include <fstream>

namespace ARCS {	// ARCS名前空間
	enum SaveType {
		STRG_FORMAT_CSV,	// CSVファイルとして保存
		STRG_FORMAT_DAT,	// DAT(タブ区切り)ファイルとして保存
	};
	
	class DataStorage {
		private:
			DataStorage(const DataStorage&);					// コピーコンストラクタ使用禁止
			const DataStorage& operator=(const DataStorage&);	// 代入演算子使用禁止
			const unsigned int N;		// 		格納する変数の数
			const unsigned long Ts;		// [ns]	サンプリング時間
			const double Tend;			// [s]	保存する時間
			const unsigned long tlen;	//		保存する要素数
			double** Data;				//		データ格納用変数
			unsigned long count;		//		要素数カウンタ
		
		public:
			DataStorage(const unsigned int NumOfVar, const unsigned long SmplTime, const double SaveTime);
			// コンストラクタ NumOfVar；変数の数，SmplTime；[ns] 制御周期，SaveTime；[s] 保存時間
			~DataStorage();						// デストラクタ
			void PutData(double* Value, unsigned int NumOfVar);	// データの格納 Value；データ値，NumOfVar；変数の数
			bool SaveDataFile(const char* const FileName, const SaveType FileType);
			// CSV/DATファイルの保存 FileName；ファイル名，FileType；ファイル形式，戻り値；true=完了，false=失敗
			void ClearCounter(void);			// 要素数カウンタをクリア
	};
}

#endif



