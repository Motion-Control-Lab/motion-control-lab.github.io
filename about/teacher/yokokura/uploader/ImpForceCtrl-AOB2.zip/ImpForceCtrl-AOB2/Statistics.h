//
// 統計処理ヘッダファイル
//
// 2010/04/02 Rev.A Coded by Yuki YOKOKURA

double Covariance(double *u1, double *u2, unsigned int N){
	// 信号u1と信号u2の間の共分散を計算する
	double Ave1=0,Ave2=0,y=0;
	unsigned int i=0;
	
	// u1とu2の平均を計算
	for(i=0;i<N;i++){
		Ave1=Ave1+u1[i];
		Ave2=Ave2+u2[i];
	}
	Ave1=Ave1/(double)N;
	Ave2=Ave2/(double)N;
	
	// u1とu2から平均値を減算して共分散を計算
	for(i=0;i<N;i++){
		u1[i]=u1[i]-Ave1;
		u2[i]=u2[i]-Ave2;
		y = y + u1[i]*u2[i];
	}
	y=y/N;
	
	return y;
}

double Correlation(double *u1, double *u2, unsigned int N){
	// 信号u1と信号u2の間の相関係数を求める
	double Ave1=0,Ave2=0,Cov=0,Std1=0,Std2=0,Corr=0;
	unsigned int i=0;
	
	// u1とu2の平均を計算
	for(i=0;i<N;i++){
		Ave1=Ave1+u1[i];
		Ave2=Ave2+u2[i];
	}
	Ave1=Ave1/(double)N;
	Ave2=Ave2/(double)N;
	
	// u1とu2から平均値を減算して共分散と標準偏差を計算
	for(i=0;i<N;i++){
		u1[i]=u1[i]-Ave1;
		u2[i]=u2[i]-Ave2;
		Cov  = Cov  + u1[i]*u2[i];	// u1とu2共分散
		Std1 = Std1 + u1[i]*u1[i];	// u1の標準偏差
		Std2 = Std2 + u2[i]*u2[i];	// u2の標準偏差
	}
	
	// 最終的に相関係数を計算
	Corr=Cov/(sqrt(Std1)*sqrt(Std2));
	
	return Corr;
}


