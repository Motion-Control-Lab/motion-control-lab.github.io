//
// 微分積分関数
// 2010/08/19 Rev.D  Coded by Yuki YOKOKURA
//

double Integral(double u, double Ts){
	// 積分器 G(s)=1/s (双一次変換)
	double y=0;
	static double uZ1=0, yZ1=0;
	
	y=Ts/2.0*(u+uZ1)+yZ1;
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

double Integral2nd1(double u, double Ts){
	// 2次 積分器 G(s)=1/s^2 (双一次変換)
	double y;
	static double uZ1=0,uZ2=0,yZ1=0,yZ2=0;
	
	y=(Ts*Ts)/4.0* ( u + 2.0*uZ1 + uZ2) + 2.0*yZ1 - yZ2;

	uZ2=uZ1;
	uZ1=u;
	yZ2=yZ1;
	yZ1=y;

	return y;
}

double Pos2Spd1(double Pres, double Ts, double gpd){
	// 位置-速度変換 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Pos2Spd2(double Pres, double Ts, double gpd){
	// 位置-速度変換 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Derivative1(double Pres, double Ts, double gpd){
	// 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Derivative2(double Pres, double Ts, double gpd){
	// 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Derivative3(double Pres, double Ts, double gpd){
	// 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Derivative4(double Pres, double Ts, double gpd){
	// 擬似微分器 G(s)=(s*gpd)/(s+gpd) (双一次変換)
	double Vres;
	static double PresZ1=0,VresZ1=0;
	
	Vres=( 2.0*gpd*(Pres-PresZ1) + (2.0-Ts*gpd)*VresZ1 )/(2.0+Ts*gpd);
	
	PresZ1=Pres;
	VresZ1=Vres;
	
	return Vres;
}

double Derivative2ord(double u, double Ts, double w, double Q){
	// 2次擬似微分器 G(s)=s^2*w^2/(s^2 + w/Q*s + w^2) (双一次変換)
	// u；入力，Ts；制御周期 [s]，w；カットオフ周波数 [rad/s]，Q；鋭さ
	double y;
	static double yZ1=0, yZ2=0, yZ3=0;
	static double uZ1=0, uZ2=0, uZ3=0;
	
	y = 4.0*Q*Ts*w*w*(uZ3-uZ2-uZ1+u)
	   -4.0*Q*Ts*(yZ3-yZ2-yZ1)
	   -2.0*w*Ts*Ts*(-yZ3-yZ2+yZ1)
	   -Q*Ts*Ts*Ts*w*w*(yZ3+3.0*yZ2+3.0*yZ1);
	y = y * 1.0/(4.0*Q*Ts + 2.0*w*Ts*Ts + Q*Ts*Ts*Ts*w*w);
	
	uZ3=uZ2;
	uZ2=uZ1;
	uZ1=u;
	yZ3=yZ2;
	yZ2=yZ1;
	yZ1=y;
	
	return y;
}


