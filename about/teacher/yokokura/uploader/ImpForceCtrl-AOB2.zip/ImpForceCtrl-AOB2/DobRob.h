//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//
//    �O���I�u�U�[�o ���͐���I�u�U�[�o �w�b�_�t�@�C��
//
//      Rev.D  2007/10/12 Yuki YOKOKURA  Ohlab. NUT
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

double DOB2order1(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` �O���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}

double DOB2order2(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` �O���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;

	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;

	Tdis=Jn*-(k1*Pres+z1);

	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}

double DOB2order3(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` �O���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;

	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;

	Tdis=Jn*-(k1*Pres+z1);

	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}

double DOB2order4(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` �O���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}
double DOB2order5(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` �O���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}

double ROB2order1(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` ���͐���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}

double ROB2order2(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` ���͐���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}


double ROB2order3(double Tref,double Pres, double Jn, double Ts, double k1, double k2){
	// 2���` ���͐���I�u�U�[�o
	double z1,z2,Tdis;
	static double z1Z1=0, z2Z1=0, PresZ1=0, TrefZ1=0;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*PresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*PresZ1 +TrefZ1/Jn ) +z2Z1;
	
	Tdis=Jn*( -k1*Pres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	PresZ1=Pres;
	TrefZ1=Tref;
	
	return Tdis;
}


double DOB1st(double Tref, double Vres,double Jn,double Ts,double g){
	// 1���` �O���I�u�U�[�o
	double A=0,B=0,Tdis=0,D=0;
	static double Bp=0,C=0;

	D=g*Jn*Vres;
	A=Tref+D;
	B=g*(A-C);
	C=C+(B+Bp)*Ts/2.0;
		Bp=B;
	Tdis=C-D;

	return Tdis;
}

double ROB1st(double Tref, double Vres,double Jn,double Ts,double g){
	// 1���` ���͐���I�u�U�[�o
	double A=0,B=0,Tdis=0,D=0;
	static double Bp=0,C=0;

	D=g*Jn*Vres;
	A=Tref+D;
	B=g*(A-C);
	C=C+(B+Bp)*Ts/2.0;
		Bp=B;
	Tdis=C-D;

	return Tdis;
}

