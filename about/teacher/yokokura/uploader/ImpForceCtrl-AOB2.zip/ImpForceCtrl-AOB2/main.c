//
// RTAIスレッド生成(マルチスレッドに対応済み)
// 2010/08/19 Rev.A  Coded by Yuki YOKOKURA
//

#include <stdio.h>
#include <rtai_lxrt.h>
#include <sys/io.h>

#include "RCS.h"		// Robot Control System
#include "Control.h"	// 制御用関数の読み込み

static volatile int FlagSignal=0;	// スレッド間フラグ信号

// 各スレッドの制御周期は以下の部分で設定(但しスレッド優先順位の関係から，Ts1 < Ts2 となるようにせよ)
//             s  m  u  n
#define Ts1        100000		// [ns] 実時間スレッド1 制御周期
#define Ts2     100000000		// [ns] 実時間スレッド2 制御周期

static void *RealTimeThread1(void){
	// RTAI 実時間スレッド 1
	RT_TASK *handler;	// ハンドラ
	RTIME period;		// 制御周期カウント値
	
	unsigned long long int counter=0;	// 制御カウンタ
	
	IFinitialize();		// Interface 初期化

	// ハンドラの初期化
	if (!(handler = rt_task_init(nam2num("RTAI1"), 0, 4096, 0))){
		CleanupScreen();
		CommandScreen(RCS_MESSAGE, "CANNOT INITIALIZE RTAI1 TASK [ main.c  LINE: 30 ]");
		exit(1);
	}
	
 	period = nano2count(Ts1);	// 制御周期をカウント値に変換
	rt_task_make_periodic(handler, rt_get_time() + period, period);
	rt_make_hard_real_time();	// ハードリアルタイムに設定
	
	while (!FlagSignal){		// 何かキーが押されたことを受信するまでループ
		// リアルタイムループ
		
		ControlFunction1(counter);	// 制御用関数
		
		counter++;					// 制御カウンタを増加
		rt_task_wait_period();		// 次の周期まで待機
	}
	
	rt_make_soft_real_time();	// ソフトリアルタイムに設定
	rt_task_delete(handler);	// ハンドラの削除
	
	IFcleanup();				// Interface 掃除
	
	FlagSignal++;				// 実時間スレッド1 が抜けたことを知らせる
	
	return 0;
}

static void *RealTimeThread2(void){
	// RTAI 実時間スレッド 2
	RT_TASK *handler;	// ハンドラ
	RTIME period;		// 制御周期カウント値
	
	unsigned long long int counter=0;	// 制御カウンタ
	
	// ハンドラの初期化
	if (!(handler = rt_task_init(nam2num("RTAI2"), 1, 32767, 0))){
		CleanupScreen();
		CommandScreen(RCS_MESSAGE, "CANNOT INITIALIZE RTAI2 TASK [ main.c  LINE: 65 ]");
		exit(1);
	}
	
 	period = nano2count(Ts2);	// 制御周期をカウント値に変換
	rt_task_make_periodic(handler, rt_get_time() + period, period);
	rt_make_hard_real_time();	// ハードリアルタイムに設定
	
	while (!FlagSignal){		// 何かキーが押されたことを受信するまでループ
		// リアルタイムループ
		
		ControlFunction2(counter);	// 制御用関数
		
		counter++;					// 制御カウンタを増加
		rt_task_wait_period();		// 次の周期まで待機
	}
	
	rt_make_soft_real_time();	// ソフトリアルタイムに設定
	rt_task_delete(handler);	// ハンドラの削除
	
	FlagSignal++;				// 実時間スレッド2 が抜けたことを知らせる
	
	return 0;
}

int main(void) {
	RT_TASK *RealTimeTask;		// 実時間タスク
	int RealTimeThread1_ID;		// 実時間スレッド 1 識別子
	int RealTimeThread2_ID;		// 実時間スレッド 2 識別子
	
	InitialScreen();			// RCS 画面初期化
	PrintScreen();				// RCS 初期画面表示
	
	// RCS 入力部初期画面表示
	if(CommandScreen(RCS_INIT, NULL)==2)return 0;	// "DISCARD & EXIT [2]" が選択されたら全終了
	CommandScreen(RCS_START, NULL);					// RCS 制御開始画面
	
	// 実時間タスクの初期化
	rt_allow_nonroot_hrt();		// root以外での動作を許可
	if (!(RealTimeTask = rt_task_init(nam2num("MAIN"), 2, 4096, 0))){
		CommandScreen(RCS_MESSAGE, "CANNOT INITIALIZE MAIN TASK [ main.c  LINE: 104 ]");
		exit(1);
	}
	
	rt_task_use_fpu(RealTimeTask,1);	// 浮動小数点設定

	RealTimeThread1_ID = rt_thread_create(RealTimeThread1, NULL, 10000);	// 実時間スレッド 1 を生成
	RealTimeThread2_ID = rt_thread_create(RealTimeThread2, NULL, 10000);	// 実時間スレッド 2 を生成

	rt_set_oneshot_mode();				// 単発モードに設定
	start_rt_timer(0);					// リアルタイムタイマを開始
	while(!kbhit()){
		// 何かキーが押されるまでループ
		PrintVal();			// 各値の表示
		usleep(100000);		// 0.1秒程度待機
	}
	getchar();							// キー入力の都合上必要な"getchar"
	FlagSignal=1;						// 何かキーが押されたことを各実時間スレッドに伝達
	while(FlagSignal<3)usleep(100000);	// すべての実時間スレッドが抜けるまで待機
	stop_rt_timer();					// リアルタイムタイマを停止

	rt_thread_join(RealTimeThread1_ID);	// 実時間スレッド1 終了
	rt_thread_join(RealTimeThread2_ID);	// 実時間スレッド2 終了
	rt_task_delete(RealTimeTask);		// 実時間タスクを消去
	
	CommandScreen(RCS_STOP, NULL);		// RCS 制御終了画面
	return 0;							// 全終了
}



