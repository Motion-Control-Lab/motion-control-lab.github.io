//
// Robot-01用 Interfaceヘッダファイル
// 2010/08/19 Rev.B     Coded by Yuki YOKOKURA
//
// IFボードの構成に従って書き換える必要があるので注意！
//

#include "ByteOp.h"
#include "PCI-3340.h"
#include "PCI-6205.h"
#include "PCI-3133.h"

// Interface社 の "vender ID" は 0x1147
// "scanpci -v" 実行結果の "BASEn Addr" の値を入力せよ
// 同一型番ボードを複数枚使用する場合は、各個ごとに基本アドレスが必要
#define BASE0_3340_1	0x00003000	// PCI-3340 基本アドレス0 "device ID"=0x0D0C
#define BASE0_6205_1	0x00003080	// PCI-6205 基本アドレス0 "device ID"=0x183D
#define BASE1_6205_1	0x00003060	// PCI-6205 基本アドレス1
#define BASE2_6205_1	0x00003040	// PCI-6205 基本アドレス2
#define BASE3_6205_1	0x00003020	// PCI-6205 基本アドレス3
#define BASE0_3133_1	0x000030B0	// PCI-3133 基本アドレス0 "device ID"=0x0C3D


double CurrentLimitter(double Iref){
	// 電流リミッタ
	if(Imax<Iref)Iref=Imax;
	if(Iref<-Imax)Iref=-Imax;
	return Iref;
}


double Current2Volt(double Iref){
	// 電流指令値[A]からDAC出力電圧[V]に変換
	// サーボアンプの設定に従い定数を変更せよ
	// サーボアンプの設定：3V/0.72A
	return (Iref*3.0/0.7275);
}


unsigned short Volt2DacData(double Vdac){
	// DAC出力電圧[V]からDACの実際の整数値に変換する
	// DACの仕様に従い定数を変更せよ
	// DACの設定：±10V 16bit (+10V=65525 0V=32767 -10V=0)
	return (unsigned short)( Vdac/(20.0/65535.0) + 32767.0 );
}


double EncData2Position(unsigned long EncData){
	// エンコーダカウンタ値から位置[m]へ変換する
	// エンコーダ分解能 0.1μm  (4逓倍はボード側の設定を参照)
	return (double)((long)(EncData-0x7FFFFF)*0.1e-6);
}


void CurrentCmd(double Iref[8]){
	// 電流指令値[A]をDACから出力する
	unsigned short DACdata[8]={0x8000};
	
	DACdata[0]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[0])));
	DACdata[1]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[1])));
	DACdata[2]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[2])));
	DACdata[3]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[3])));
	DACdata[4]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[4])));
	DACdata[5]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[5])));
	DACdata[6]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[6])));
	DACdata[7]=Volt2DacData(Current2Volt(CurrentLimitter(-Iref[7])));
	
	DACout(BASE0_3340_1,DACdata);
	
	return;
}


void PositionRes(double Xres[8]){
	// エンコーダカウンタから位置応答値[m]を取得する
	
	unsigned long ENCdata[8]={0x000000};
	
	ENCin(BASE0_6205_1,BASE1_6205_1,BASE2_6205_1,BASE3_6205_1,ENCdata);
	
	Xres[0]=EncData2Position(ENCdata[0]);
	Xres[1]=EncData2Position(ENCdata[1]);
	Xres[2]=EncData2Position(ENCdata[2]);
	Xres[3]=EncData2Position(ENCdata[3]);
	Xres[4]=EncData2Position(ENCdata[4]);
	Xres[5]=EncData2Position(ENCdata[5]);
	Xres[6]=EncData2Position(ENCdata[6]);
	Xres[7]=EncData2Position(ENCdata[7]);

	return;
}


void IFinitialize(void){
	// Interface初期化
	DACsettings(BASE0_3340_1);	// DACボード設定
	DACzero(BASE0_3340_1);		// DAC出力を 0 [V] にする
	ENCsettings(BASE0_6205_1,BASE1_6205_1,BASE2_6205_1,BASE3_6205_1);	// エンコーダカウンタ設定
	ENCzero(BASE0_6205_1,BASE1_6205_1,BASE2_6205_1,BASE3_6205_1);		// エンコーダカウンタを零にする
	ADC3133settings(BASE0_3133_1);	// PCI-3133の設定
	return;
}


void IFcleanup(void){
	// Interdace終了
	DACzero(BASE0_3340_1);		// DAC出力を 0 [V] にする
}

double AdcData2Volt(unsigned short Data){
	// PCI-3133のデータを変換
	// AD変換が完了している場合，最上位ビットが1となっているので
	// 0x8000だけ余分に引いている。
	
	return (double)(Data-0x8000)*10.0/4096.0-5.0;
}

double Volt2Acceleration(double Vadc){
	// ADコンバータからの取得電圧[V]を加速度[m/s^2]に変換
	// 1.019mV/(m/s^2)
	return Vadc*10.0;
}

void AccelerationRes(double XDDres[8]){
	// 加速度センサから加速度応答値[m/s^2]を取得する
	
	unsigned short ADCdata[8]={0x000000};
	
	ADCin3133(BASE0_3133_1,ADCdata);
	
	XDDres[0]=Volt2Acceleration(AdcData2Volt(ADCdata[0]));
	
	return;
}

