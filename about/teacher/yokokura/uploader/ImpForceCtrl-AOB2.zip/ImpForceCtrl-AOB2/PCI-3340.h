//
// PCI-3340用 ヘッダファイル
// 2009/04/23 Rev.A  Yuki YOKOKURA
//


void DACsettings(unsigned int BASE0){
	// DACの設定を行う関数
	
	iopl(3);	// I/O全アドレス空間にアクセス許可
	//------- DAC 設定
	// DAC チャネル 1
	outb(0x00,BASE0+0x07);	// CH1 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 2
	outb(0x01,BASE0+0x07);	// CH2 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 3
	outb(0x02,BASE0+0x07);	// CH3 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 4
	outb(0x03,BASE0+0x07);	// CH4 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 5
	outb(0x04,BASE0+0x07);	// CH5 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 6
	outb(0x05,BASE0+0x07);	// CH6 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 7
	outb(0x06,BASE0+0x07);	// CH7 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	// DAC チャネル 8
	outb(0x07,BASE0+0x07);	// CH8 設定
	outb(0x03,BASE0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);			// 設定後に必要な100μsの待機
	
	outb(0x03,BASE0+0x05);	// 全チャネル同時出力設定
	
	return;
}


void DACout(unsigned int BASE0, unsigned short DACdata[8]){
	// DACから指定した電圧を出力する関数
	
	//------- DAC 出力
	// DAC チャネル 1
	outb(0x00,BASE0+0x02);					// CH1 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[0]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[0]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 2
	outb(0x01,BASE0+0x02);					// CH2 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[1]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[1]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 3
	outb(0x02,BASE0+0x02);					// CH3 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[2]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[2]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 4
	outb(0x03,BASE0+0x02);					// CH4 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[3]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[3]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 5
	outb(0x04,BASE0+0x02);					// CH5 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[4]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[4]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 6
	outb(0x05,BASE0+0x02);					// CH6 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[5]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[5]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 7
	outb(0x06,BASE0+0x02);					// CH7 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[6]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[6]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 8
	outb(0x07,BASE0+0x02);					// CH8 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[7]),BASE0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[7]),BASE0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	
	outb(0x01,BASE0+0x05);	// 全チャネル同時出力実行
	
	return;
}


void DACzero(unsigned int BASE0){
	// DACの出力電圧を 0[V] にする関数
	
	unsigned short DACdata[8]={0};
	
	DACdata[0]=0x8000;
	DACdata[1]=0x8000;
	DACdata[2]=0x8000;
	DACdata[3]=0x8000;
	DACdata[4]=0x8000;
	DACdata[5]=0x8000;
	DACdata[6]=0x8000;
	DACdata[7]=0x8000;
	
	DACout(BASE0,DACdata);
	
	return;
}


