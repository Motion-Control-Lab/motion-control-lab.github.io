//
// 加速度オブザーバ関数
// 2010/08/21 Rev.A  Coded by Yuki YOKOKURA
//

double AOB(double XDDref, double Fdis, double Mn, double Ts, double gdis, double gacc){
	// 加速度オブザーバ
	// XDDref；加速度参照値，Fdis；外乱力，Mn；公称慣性，Ts；制御周期
	// gdis；外乱オブザーバの帯域，gacc；加速度オブザーバの帯域
	static double XDDrefZ1=0;
	static double FdisZ1=0;
	static double XDDresZ1=0;
	double XDDres;
	
	XDDres = ( (2.0-gacc*Ts)*XDDresZ1 + gacc*Ts*(XDDref+XDDrefZ1) - (2.0*gacc)/(gdis*Mn)*(Fdis-FdisZ1) )/(2.0+gacc*Ts);
	
	XDDrefZ1 = XDDref;
	FdisZ1 = Fdis;
	XDDresZ1 = XDDres;
	
	return XDDres;
}


