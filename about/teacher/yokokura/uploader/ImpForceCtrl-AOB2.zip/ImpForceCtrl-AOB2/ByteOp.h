
unsigned short IIbyteLo(unsigned short in){
	// 2byteデータの下位1byteを抽出して出力
	return 0x00FF & in;
}

unsigned short IIbyteHi(unsigned short in){
	// 2byteデータの上位1byteを抽出して出力
	return 0x00FF & (in >> 8);
}

unsigned long IIIbyteCat(unsigned short High, unsigned short Middle, unsigned short Low){
	// 上位、中位、下位に分かれている各々1バイトのデータを、3バイトのデータに結合する
	// 例： 0xAB, 0xCD, 0xEF → 0xABCDEF
	unsigned long Hbuff=0, Mbuff=0, Lbuff=0, buff=0;
	Hbuff=(unsigned long)High   & 0x000000FF;
	Mbuff=(unsigned long)Middle & 0x000000FF;
	Lbuff=(unsigned long)Low    & 0x000000FF;
	
	// Hbuffを8bit左シフトしてMbuffとORを取り、その結果をさらに8bit左シフトしLbuffとORを取る
	buff = Hbuff << 8;
	buff = buff | Mbuff;
	buff = buff << 8;
	buff = buff | Lbuff;
	return buff;
}

unsigned long IIbyteCat(unsigned short High,  unsigned short Low){
	// 上位、下位に分かれている各々1バイトのデータを、2バイトのデータに結合する
	// 例： 0xAB, 0xCD → 0xABCD
	unsigned short buff=0;
	// Highを8bit左シフトしてLowとORを取る
	buff = High << 8;
	buff = buff | Low;
	return buff;
}



