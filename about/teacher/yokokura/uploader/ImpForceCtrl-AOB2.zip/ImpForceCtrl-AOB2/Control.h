//
// 制御用周期実行関数
// 2010/08/19 Rev.D  Coded by Yuki YOKOKURA
//

#include <math.h>			// 数学ライブラリ
#include "Interface.h"		// インターフェース関連
#include "Calculus.h"		// 微分積分
#include "DobRob.h"			// 外乱オブザーバ及び反力推定オブザーバ
#include "Regulators.h"		// 制御器関連
#include "Filters.h"
#include "AccObsrv.h"
//#include "Quarry.h"			// Quarry行列
//#include "Buffer.h"			// バッファ関連
//#include "Statistics.h"		// 統計処理関連

void ControlFunction1(unsigned long long int counter){
	// 制御用周期実行関数
	// この関数は制御周期 Ts[s] ごとに実行される
	// 制御用のコードは主にここに記述する
	// 制御に使用する変数は static 変数にすること
	// 予め宣言されている変数 counter は制御開始を零として制御周期毎に1増加する
	
	// 制御用定数宣言
	//const double pi		= 3.14159265358979;	// 円周率
	const double Ts		= 100e-6;		// [s]		制御周期
	const double Kfn	= 3.33;			// [N/A]	推力定数 公称値
	const double Mn		= 0.245;		// [kg]		質量 公称値
	const double Kfp	= 1.5;			//			力制御器 比例ゲイン
	const double gacc	= 1000;			// [rad/s]	加速度オブザーバの帯域
	const double gdis	= 1000;			// [rad/s]	外乱オブザーバの帯域
	const double k1dis	= gdis*gdis;	// 			2次外乱オブザーバ用係数(重根の場合)
	const double k2dis	= 2.0*gdis;		// 			2次外乱オブザーバ用係数(重根の場合)
	const double alpha	= 1;
	const double beta	= 80;
	
	// 制御用変数宣言
	double t=Ts*(double)counter;	// [s]		時刻の生成
	static double Var[11]={0};		// 			測定データ格納用変数
	static double Xres[8]={0};		// [m]		位置応答値
	static double Iref[8]={0};		// [A]		
	static double IrefM=0;			// [A]		電流指令値
	static double FdisM=0;			// [N]		推定外乱
	static double XresM=0;			// [m]		位置応答値
	static double XDresM=0;			// [m/s]	速度応答値
	static double XDDresM=0;		// [m/s^2]	加速度応答値
	static double XDDrefM=0;		// [m/s^2]	加速度参照値
	static double FcmdM=0;
	
	//------- 制御コードここから -------
	PositionRes(Xres);			// [m]		位置応答値を取得
	
	XresM	= Xres[0];										// 位置を取得
	XDresM	= HPF(Derivative1(XresM,Ts,30000),Ts,gacc);		// 速度を算出
	XDDresM	= AOB(XDDrefM,FdisM,Mn,Ts,gdis,gacc);			// 加速度オブザーバから加速度を算出
	
	FcmdM=0;
	//FcmdM=1e-3*sin(2.0*pi*4.0*t);
	
	FdisM=DOB2order1(IrefM*Kfn,XresM,Mn,Ts,k1dis,k2dis);		// 外乱オブザーバ
	XDDrefM=(FcmdM-FdisM)*Kfp + Limitter(alpha*XDDresM,7) - beta*XDresM;	// 加速度参照値
	//XDDrefM=PDcon1(FcmdM-FdisM,1,0.03,Ts,1000) + XDDresMo;	// 加速度参照値
	IrefM=XDDrefM*Mn/Kfn + FdisM/Kfn;
	
	Iref[0]=IrefM;
	
	CurrentCmd(Iref);	// [A] 電流指令値を出力
	//------- 制御コードここまで -------
	
	// 表示させる値を表示用メモリに格納
	IndicatorMem.counter=counter;					// 制御カウント値の格納
	IndicatorMem.time=t;							// 時刻の格納
	memcpy(IndicatorMem.Iref,Iref,sizeof(Iref));	// 電流指令値の格納
	memcpy(IndicatorMem.Xres,Xres,sizeof(Xres));	// 位置応答値の格納
	
	// 保存したい値をメモリに格納(10変数まで対応)
	Var[0]=XresM;
	Var[1]=XDDresM;
	Var[2]=FcmdM;
	Var[3]=FdisM;
	Var[4]=0;
	Var[5]=0;
	Var[6]=0;
	Var[7]=0;
	Var[8]=0;
	Var[9]=0;
	DataStore(1,t,Var);		// 各々の変数値を格納
	
	return;
}

void ControlFunction2(unsigned long long int counter){
	// 制御用周期実行関数 2
	// この関数は制御周期 Ts2 ごとに実行される (main.c にて設定)
	// 制御用のコードは主にここに記述する
	// 制御に使用する変数は static 変数にすること
	// 予め宣言されている変数 counter は制御開始を零として制御周期毎に1増加する
	
	// 制御用定数宣言
	//const double Ts		= 100e-3;		// [s]		制御周期
	
	return;
}

void DataStore(int FileInOut, double t, double Var[11]){
	// 測定データをメモリに格納し、格納した値をCSVファイルとして書き出す関数
	
	// 測定データ格納用配列 (保存したい内容によって書き換える)
	static double time[Ndat]={0}, Var1[Ndat]={0}, Var2[Ndat]={0}, Var3[Ndat]={0}, Var4[Ndat]={0};
	static double Var5[Ndat]={0}, Var6[Ndat]={0}, Var7[Ndat]={0}, Var8[Ndat]={0}, Var9[Ndat]={0}, Var10[Ndat]={0};
	static unsigned long i=0;	// 配列指定用カウンタ
	
	// FileInOutの値によって機能が変わる (1=値を格納 0=値を書き出す)
	if(FileInOut==1){
		// 各々の測定データの値を配列に格納 (保存したい内容によって書き換える)
		if(i<Ndat){		// 配列の要素数以上を指定しないように制限
			time[i]=t;
			Var1[i]=Var[0];
			Var2[i]=Var[1];
			Var3[i]=Var[2];
			Var4[i]=Var[3];
			Var5[i]=Var[4];
			Var6[i]=Var[5];
			Var7[i]=Var[6];
			Var8[i]=Var[7];
			Var9[i]=Var[8];
			Var10[i]=Var[9];
			i++;		// カウント
		}
	}else{
		// 格納された値をCSVファイルに書き出す
		FILE *fp;					// ファイルポインタ
		fp=fopen("DATA.csv","w");	// CSVファイルを上書きで書き出す
		for(i=0;i<Ndat;i++){		// 配列指定用カウンタの最終値になるまで繰り返す
			// メモリに保持されたデータをファイルに書き出す (保存したい内容によって書き換える)
			fprintf(fp,"%10.4lf,%1.15e,%1.15e,%1.15e,%1.15e,%10.4lf,%1.15e,%1.15e,%1.15e,%1.15e,%1.15e\n",
						time[i],Var1[i],Var2[i],Var3[i],Var4[i],Var5[i],Var6[i],Var7[i],Var8[i],Var9[i],Var10[i]);
		}
		fclose(fp);					// ファイル開放
	}
	return;
}



