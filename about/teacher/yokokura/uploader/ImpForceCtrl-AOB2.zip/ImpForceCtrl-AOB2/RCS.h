//
// Robot Control System
// 2009/04/25 Rev.A  Yuki YOKOKURA
//
// アクチュエータの状態表示や数値表示、
// 制御開始やデータの保存等の操作を行う

#include <curses.h>

#define Ndat	100000	// 測定データ格納用配列の要素数 (Ts*Ndat=保存可能時間[s])
#define Irat	0.81	// [A]	モータ定格電流 (使うモータによって変更すること)
#define Imax	2.7		// [A]	モータ最大電流 (使うモータによって変更すること)


// プロトタイプ宣言
void InitialScreen(void);
void CleanupScreen(void);
void PrintScreen(void);
void AddHLine(int X1, int X2, int Y);
void AddVLine(int Y1, int Y2, int X);
int kbhit(void);
int KeyCommand(void);
int CommandScreen(int CmdNum, char *TEXT);
extern void DataStore(int FileInOut, double t, double Var[8]);	// 関数DataStore の実体は Control.h にある


// RCS動作モード指令の定義
enum RCS_CommandID{
	RCS_INIT,		// 初期画面
	RCS_START,		// 動作中画面
	RCS_MESSAGE,	// 警告メッセージ画面
	RCS_STOP		// 終了画面
};


// 表示値格納用構造体
struct RCS_Indicator{
	unsigned long long int counter;	// 制御ループカウンタ
	double time;		// [s] 時刻
	double Iref[8];		// [A] 電流指令値
	double Xres[8];		// [m] 位置応答値
} IndicatorMem;

int RCS_MemFlag=0;	// 保存するしないフラグ

// 関数 DataStore は Control.h へ移動しました

void InitialScreen(void){
	// 画面描画の初期化と準備を行う
	initscr();		// 画面初期化
	noecho();		// エコーなし
	cbreak();		// 
    start_color();	// 色を使う (SSHの設定で色が変わるので注意)
    init_pair(1,COLOR_GREEN,COLOR_BLACK);	// 色の定義 緑字に背景が黒
    init_pair(2,COLOR_BLACK,COLOR_YELLOW);	// 色の定義 黒字に背景が黄
    init_pair(3,COLOR_WHITE,COLOR_BLUE);	// 色の定義 白字に背景が青
    init_pair(4,COLOR_WHITE,COLOR_RED);		// 色の定義 白字に背景が赤
    init_pair(5,COLOR_YELLOW,COLOR_BLACK);	// 色の定義 黄字に背景が黒
    init_pair(6,COLOR_BLACK,COLOR_GREEN);	// 色の定義 黒字に背景が緑
}

void CleanupScreen(void){
	// RCS画面表示の消去
	endwin();
}

void PrintScreen(void){
	// 画面の描画を行う  但し数値の描画は行わない
	attron(COLOR_PAIR(2));
	move( 0,0);addstr(" ROBOT CONTROL SYSTEM  Ver.3.1.1                            Katsura Lab., 2009 ");
	attron(COLOR_PAIR(3));attron(A_BOLD);
	move( 1,0);addstr(" RTAI STATUS                                                                   ");
	attron(COLOR_PAIR(1));attroff(A_BOLD);
	move( 2,0);addstr("|COUNTER               |            [counts] |                                |");
	move( 3,0);addstr("|TIME                  |            [sec]    |                                |");
	move( 4,0);addstr("|DATA MEMORY REMAINING |        --- [%]      |                                |");
	move( 5,0);addstr("|                      |                     |                                |");
	attron(COLOR_PAIR(3));attron(A_BOLD);
	move( 6,0);addstr(" SERVO MOTOR STATUS                                                            ");
	attron(COLOR_PAIR(6));attroff(A_BOLD);
	move( 7,0);addstr("|PARAMETERS   |   1   |   2   |   3   |   4   |   5   |   6   |   7   |   8   |");
	attron(COLOR_PAIR(1));
	move( 8,0);addstr("|STATUS       |STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|");
	move( 9,0);addstr("|POSITION [mm]|  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |");
	move(10,0);addstr("|CURRENT  [A] |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |");
	attron(COLOR_PAIR(6));attroff(A_BOLD);
	move(11,14);             addstr("|   9   |  1 0  |  1 1  |  1 2  |  1 3  |  1 4  |  1 5  |  1 6  |");
	attron(COLOR_PAIR(1));
	move(12,0);addstr("|STATUS       |STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|STANDBY|");
	move(13,0);addstr("|POSITION [mm]|  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |");
	move(14,0);addstr("|CURRENT  [A] |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |  ---- |");
	move(15,0);addstr("|             |       |       |       |       |       |       |       |       |");
	attron(COLOR_PAIR(3));attron(A_BOLD);
	move(16,0);addstr(" VARIABLES                                                                     ");
	attroff(A_BOLD);
	attron(COLOR_PAIR(1));
	move(17,0);addstr("|              |               |               |               |              |");
	move(18,0);addstr("|              |               |               |               |              |");
	move(19,0);addstr("|              |               |               |               |              |");
	move(20,0);addstr("|              |               |               |               |              |");
	attron(COLOR_PAIR(3));attron(A_BOLD);
	move(21,0);addstr(" COMMAND                                                                       ");
	attron(COLOR_PAIR(1));attroff(A_BOLD);

	// 罫線の描画を行う
	AddVLine(2,5,0);AddVLine(2,5,23);AddVLine(2,5,45);AddVLine(2,5,78);
	move(5,0);addch(ACS_LLCORNER);AddHLine(1,22,5);move(5,23);addch(ACS_BTEE);AddHLine(24,44,5);move(5,45);addch(ACS_BTEE);AddHLine(46,77,5);move(5,78);addch(ACS_LRCORNER);
	AddVLine(7,15,0);AddVLine(7,15,14);AddVLine(7,15,22);AddVLine(7,15,30);AddVLine(7,15,38);AddVLine(7,15,46);AddVLine(7,15,54);AddVLine(7,15,62);AddVLine(7,15,70);AddVLine(7,15,78);
	AddHLine(0,78,15);move(15,0);addch(ACS_LLCORNER);move(15,14);addch(ACS_BTEE);move(15,22);addch(ACS_BTEE);move(15,30);addch(ACS_BTEE);move(15,38);addch(ACS_BTEE);move(15,46);addch(ACS_BTEE);move(15,54);addch(ACS_BTEE);move(15,62);addch(ACS_BTEE);move(15,70);addch(ACS_BTEE);move(15,78);addch(ACS_LRCORNER);
	AddVLine(17,20,0);AddVLine(17,20,15);AddVLine(17,20,31);AddVLine(17,20,47);AddVLine(17,20,63);AddVLine(17,20,78);
	AddHLine(0,78,20);move(20,0);addch(ACS_LLCORNER);move(20,15);addch(ACS_BTEE);move(20,31);addch(ACS_BTEE);move(20,47);addch(ACS_BTEE);move(20,63);addch(ACS_BTEE);move(20,78);addch(ACS_LRCORNER);
	attron(COLOR_PAIR(6));
	move( 7,0);addch(ACS_VLINE);move( 7,14);addch(ACS_VLINE);move( 7,22);addch(ACS_VLINE);move( 7,30);addch(ACS_VLINE);move( 7,38);addch(ACS_VLINE);move( 7,46);addch(ACS_VLINE);move( 7,54);addch(ACS_VLINE);move( 7,62);addch(ACS_VLINE);move( 7,70);addch(ACS_VLINE);move( 7,78);addch(ACS_VLINE);
	                            move(11,14);addch(ACS_VLINE);move(11,22);addch(ACS_VLINE);move(11,30);addch(ACS_VLINE);move(11,38);addch(ACS_VLINE);move(11,46);addch(ACS_VLINE);move(11,54);addch(ACS_VLINE);move(11,62);addch(ACS_VLINE);move(11,70);addch(ACS_VLINE);move(11,78);addch(ACS_VLINE);
	attron(COLOR_PAIR(1));

	refresh();
}

void AddHLine(int X1, int X2, int Y){
	// 水平罫線の描画
	int i=0;
	
	for(i=X1;i<=X2;i++){
		move(Y,i);addch(ACS_HLINE);
	}
	return;
}

void AddVLine(int Y1, int Y2, int X){
	// 垂直罫線の描画
	int i=0;
	
	for(i=Y1;i<=Y2;i++){
		move(i,X);addch(ACS_VLINE);
	}
	return;
}

int kbhit(void){
	// キー入力があった場合に1を返す なければ0を返す
	struct timeval tv;
	fd_set read_fd;
	tv.tv_sec=0;
	tv.tv_usec=0;
	FD_ZERO(&read_fd);
	FD_SET(0,&read_fd);
	if(select(1,&read_fd,NULL,NULL,&tv)==-1)return 0;	// キー入力がなかった
	if(FD_ISSET(0,&read_fd))return 1;					// キー入力があった
	return 0;
}

int KeyCommand(void){
	// コマンド入力待機して入力結果を返す
	int key=0;
	echo();									// エコーありに設定
	while(1){								// 有効なキー入力があるまで繰り返し
		move(23,70);addstr("       ");		// 入力部を消去
		move(23,70);						// キー入力位置にカーソルを移動
		refresh();							// 描画実行
		if(scanw("%d",&key)<=0){			// 入力文字数が0なら、
			getchar();						// キー入力
			continue;						// 繰り返し続行
		}else if( (0<=key)&&(key<=3) ){		// 入力された数字が0～3以内なら、(コマンド数によって変更すること)
			break;							// 繰り返し抜ける
		}else{								// 0～3以外だったら、
			move(23,70);addstr("       ");	// 入力部を消去
			move(23,70);					// キー入力位置にカーソルを移動
			refresh();						// 描画実行
			getchar();						// キー入力
			continue;						// 繰り返し続行
		}
	}
	move(23,70);							// キー入力位置にカーソルを移動
	refresh();								// 描画実行
	noecho();								// エコーなしに設定
	return key;								// 入力された値を返す
}

int CommandScreen(int CmdNum, char *TEXT){
	// コマンド入力部の画面表示を制御する関数
	int key=0;
	
	switch(CmdNum){
		case RCS_INIT:
			// 初期入力画面:
			attron(COLOR_PAIR(5));				// 停止状態用の表示
			move(2,47);addstr(" IN OPERATION          ");
			move(3,47);addstr(" NETWORK DATA LINK     ");
			move(4,47);addstr(" MEASURED DATA SAVING  ");
			attron(COLOR_PAIR(1));
			move(22,0);addstr("| START & SAVE   [1]  | START          [3]  |                     |            ");
			move(23,0);addstr("|                     | EXIT           [2]  |                     | >          ");
			AddVLine(22,23,0);AddVLine(22,23,22);AddVLine(22,23,44);AddVLine(22,23,66);AddVLine(22,23,78);
			AddHLine(1,78,24);
			move(24,0);addch(ACS_LLCORNER);move(24,22);addch(ACS_BTEE);move(24,44);addch(ACS_BTEE);move(24,66);addch(ACS_BTEE);move(24,78);addch(ACS_LRCORNER);
			refresh();							// 描画表示
			
			while(1){	// 有効なキー入力があるまで繰り返し
				key=KeyCommand();	// キーボード入力指令待機
				if(key==0)continue;	// "0"のキー入力は無効
				if(key==1){			// "START & SAVE   [1]" が選択されたら、
					move(4,47);attron(A_BLINK);attron(COLOR_PAIR(2));	// 測定データ記憶中メッセージ表示
					addstr(" DATA STORAGE          ");attroff(A_BLINK);
					RCS_MemFlag=1;	// 保存フラグを立てる
					break;
				}
				if(key==2){			// "DISCARD & EXIT [2]" が選択されたら、
					CleanupScreen();	// RCS 画面消去
					break;
				}
				if(key==3){			// "START & SAVE   [1]" が選択されたら、
					RCS_MemFlag=0;	// 保存フラグを立てない
					break;
				}
			}
			break;
		
		case RCS_START:
			// 制御開始時画面
			attron(COLOR_PAIR(2));				// 動作中メッセージ表示
			move(2,47);addstr(" IN OPERATION          ");
			attron(COLOR_PAIR(4));				// 動作中用の表示
			move(22,0);addstr("                                                                               ");
			move(23,0);addstr(" STOP  [ANY]                CONTROL SYSTEM RUNNING                  >          ");
			move(24,0);addstr("                                                                               ");
			AddVLine(22,24,66);
			move(23,70);						// キー入力位置にカーソルを移動
			refresh();							// 描画実行
			break;
		
		case RCS_MESSAGE:
			// 警告・エラーメッセージ画面
			attron(COLOR_PAIR(4));attroff(A_BOLD);
			move( 8,16);addstr("                                               ");
			move( 9,16);addstr("                                               ");
			move(10,16);addstr("                                               ");
			move(11,16);addstr("                                               ");
			move(12,16);addstr("                                               ");
			move(13,16);addstr("                                               ");
			move(14,16);addstr("                                               ");
			move(15,16);addstr("                                               ");
			move(16,16);addstr("                                               ");
			AddHLine(17,61,8);
			AddVLine(8,16,17);
			AddVLine(8,16,61);
			AddHLine(17,61,16);
			move( 8,17);addch(ACS_ULCORNER);move( 8,61);addch(ACS_URCORNER);
			move(16,17);addch(ACS_LLCORNER);move(16,61);addch(ACS_LRCORNER);
			attron(COLOR_PAIR(2));attroff(A_BOLD);
			move(14,33);addstr(" O  K  [ANY] ");
			attron(COLOR_PAIR(4));attroff(A_BOLD);
			move(10,19);printw(TEXT);
			move(23,70);						// キー入力位置にカーソルを移動
			refresh();							// 描画実行
			getchar();
			CleanupScreen();		// RCS 画面消去
			break;
		
		case RCS_STOP:
			// 制御停止時画面
			attron(COLOR_PAIR(5));				// 停止状態用の表示
			move(2,47);addstr(" IN OPERATION          ");
			move(3,47);addstr(" NETWORK DATA LINK     ");
			move(4,47);addstr(" DATA STORAGE          ");
			attron(COLOR_PAIR(1));
			move(22,0);addstr("|                     |                     |                     |            ");
			
			if(RCS_MemFlag==1){	// 保存したかどうかによって表示を変える
				// 保存した場合
				move(23,0);addstr("| WRITE & EXIT   [0]  | DISCARD & EXIT [2]  |                     | >          ");
			}else{
				// 保存しなかった場合
				move(23,0);addstr("|                     | EXIT           [2]  |                     | >          ");
			}
			
			AddVLine(22,23,0);AddVLine(22,23,22);AddVLine(22,23,44);AddVLine(22,23,66);AddVLine(22,23,78);
			AddHLine(1,78,24);
			move(24,0);addch(ACS_LLCORNER);move(24,22);addch(ACS_BTEE);move(24,44);addch(ACS_BTEE);move(24,66);addch(ACS_BTEE);move(24,78);addch(ACS_LRCORNER);
			refresh();	// 描画表示
			
			while(1){	// 有効なキー入力があるまで繰り返し
				key=KeyCommand();	// キーボード入力指令待機
				if(key==0){
					// 保存する場合
					if(RCS_MemFlag==1){	// 保存したかどうかによって動作を変える
						// 保存した場合は保存動作に移行
						attron(COLOR_PAIR(1));	// データ書き出し中メッセージ表示
						move(22,0);addstr("                                                                               ");
						move(23,0);addstr("  WRITIMG.......                                                   PLEASE WAIT ");
						refresh();				// 描画実行
						DataStore(0,0,0);		// メモリに保持された測定データをファイルに書き出す
						break;
					}else{
						// 保存しなかった場合は"0"のキー入力は無効
						continue;
					}
				}
				if(key==1)continue;	// "1"のキー入力は無効
				if(key==2)break;	// 保存しない場合はなにもせずそのまま終了
				if(key==3)continue;	// "3"のキー入力は無効
			}
			CleanupScreen();		// RCS 画面消去
			break;
		
		default:
			break;
	}
	
	return key;
}

void MotorStatus(double Iref, int posX, int posY){
	// モータ状態表示 (使用するモータによって定格電流Iratの上限設定を行うこと)
	if( Iref<=-Imax*0.8 || Imax*0.8<=Iref){
		attron(COLOR_PAIR(4));
		move(posX,posY); printw("OVER L.");		// 最大推力の80％を超える場合
		attron(COLOR_PAIR(5));
	}else{
		if( Iref<=-Irat || Irat<=Iref){
			attron(COLOR_PAIR(2));
			move(posX,posY); printw("WARNING");	// 定格推力を超える場合
			attron(COLOR_PAIR(5));
		}else{
			attron(COLOR_PAIR(6));
			move(posX,posY); printw(" NORMAL");	// 定格推力未満の場合
			attron(COLOR_PAIR(5));
		}
	}
	return;
}

void PrintVal(void){
	// 各々の数値と状態の描画を行う
	
	int MemRem=0;	// メモリ残量計算用
	
	attron(COLOR_PAIR(5));
	
	// RTAI 状態の表示
	// 周期カウンタ、経過時間、測定データ保持用メモリの残量表示
	move(2,25);printw("%10lld",IndicatorMem.counter);
	move(3,25);printw("%10.1lf",IndicatorMem.time);
	if(RCS_MemFlag==1){
		// 測定データを保存する場合のメモリ残量表示
		MemRem=(int)(100.0-IndicatorMem.counter/(double)Ndat*100.0);	// データ保持用メモリ残量計算
		if(MemRem<0){
			// メモリ残量が霊になったら
			MemRem=0;
			move(4,47);addstr(" DATA STORAGE          ");	// 保存中表示を消去
		}
		move(4,25);printw("%10d",MemRem);	// メモリ残量表示
	}
	
	// モータの状態表示 過負荷の警告表示を行う
	MotorStatus(IndicatorMem.Iref[0],8,15);
	MotorStatus(IndicatorMem.Iref[1],8,23);
	MotorStatus(IndicatorMem.Iref[2],8,31);
	MotorStatus(IndicatorMem.Iref[3],8,39);
	MotorStatus(IndicatorMem.Iref[4],8,47);

	// 位置指令値の表示
	move( 9,16);printw("%6.2lf",IndicatorMem.Xres[0]*1e3);
	move( 9,24);printw("%6.2lf",IndicatorMem.Xres[1]*1e3);
	move( 9,32);printw("%6.2lf",IndicatorMem.Xres[2]*1e3);
	move( 9,40);printw("%6.2lf",IndicatorMem.Xres[3]*1e3);
	move( 9,48);printw("%6.2lf",IndicatorMem.Xres[4]*1e3);
	
	// 電流指令値の表示
	move(10,17);printw("%5.2lf",IndicatorMem.Iref[0]);
	move(10,25);printw("%5.2lf",IndicatorMem.Iref[1]);
	move(10,33);printw("%5.2lf",IndicatorMem.Iref[2]);
	move(10,41);printw("%5.2lf",IndicatorMem.Iref[3]);
	move(10,49);printw("%5.2lf",IndicatorMem.Iref[4]);

	move(23,70);	// カーソルをキー入力位置へ移動
	refresh();
}

