//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//
//               Quarry�s��w�b�_�t�@�C��
//
//      Rev.D  2007/12/29 Yuki YOKOKURA  Ohlab. NUT
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void Q2(double X, double Y, double *P, double *Q){
	// 2�� Quarry�s��
	*P=(X+Y)/2.0;
	*Q=(X-Y)/2.0;
	
	return;
}

void Q2inv(double X, double Y, double *P, double *Q){
	// 2�� �tQuarry�s��
	*P=X+Y;
	*Q=X-Y;
	
	return;
}

void Q3(double J1, double J2, double J3, double *M1, double *M2, double *M3){
	// 3�� Quarry�s��
	*M1=(     J1 +J2 +J3 )/3.0;
	*M2=(         J2 -J3 )/3.0;
	*M3=( 2.0*J1 -J2 -J3 )/3.0;
	
	return;
}

void Q3inv(double M1, double M2, double M3, double *J1, double *J2, double *J3){
	// 3�� �tQuarry�s��
	*J1= M1             +M3;
	*J2= M1 +1.5*M2 -0.5*M3;
	*J3= M1 -1.5*M2 -0.5*M3;
	
	return;
}

void Q5(double J[5], double M[5]){
	// 5�� Quarry�s��
	M[0]=(     J[0] + J[1] + J[2] + J[3] + J[4] )/5.0;
	M[1]=(                          J[3] - J[4] )/5.0;
	M[2]=(               2.0*J[2] - J[3] - J[4] )/5.0;
	M[3]=(        3.0*J[1] - J[2] - J[3] - J[4] )/5.0;
	M[4]=( 4.0*J[0] - J[1] - J[2] - J[3] - J[4] )/5.0;
	
	return;
}

void Q5inv(double M[5], double J[5]){
	// 5�� �tQurry�s��
	J[0]=( 12.0*M[0]                                +12.0*M[4] )/12.0;
	J[1]=( 12.0*M[0]                      +15.0*M[3] -3.0*M[4] )/12.0;
	J[2]=( 12.0*M[0]            +20.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	J[3]=( 12.0*M[0] +30.0*M[1] -10.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	J[4]=( 12.0*M[0] -30.0*M[1] -10.0*M[2] -5.0*M[3] -3.0*M[4] )/12.0;
	
	return;
}

void IRcalc(double F1, double F2, double *IR1, double *IR2, double TH){
	// �A�C�f���e�B�e�B��̌v�Z
	double den;
	double IR1_buf=1,IR2_buf=1;
	
	if( F1<0.2 && F2<0.2 ){
		IR1_buf=1;
		IR2_buf=1;
	}else{
		den=F1+F2;
		IR1_buf=F1/den;
		IR2_buf=F2/den;
	}
	
	if(IR1_buf<0.01){
		IR1_buf=0.01;
		IR2_buf=0.09;
	}
	if(IR2_buf<0.01){
		IR1_buf=0.09;
		IR2_buf=0.01;
	}
	
	*IR1=IR1_buf;
	*IR2=IR2_buf;
	
	
	return;
}

void R5(double J[5], double M[5]){
	// 5�� �I���s��
	M[0]=( J[0] + J[1] + J[2] + J[3] + J[4] );
	M[1]=( J[0] - J[1]                      );
	M[2]=(        J[1] - J[2]               );
	M[3]=(               J[2] - J[3]        );
	M[4]=(                      J[3] - J[4] );
	
	return;
}

void R5inv(double M[5], double J[5]){
	// 5�� �t�I���s��
	J[0]=( M[0] + 4.0*M[1] + 3.0*M[2] + 2.0*M[3] +     M[4] )/5.0;
	J[1]=( M[0] -     M[1] + 3.0*M[2] + 2.0*M[3] +     M[4] )/5.0;
	J[2]=( M[0] -     M[1] - 2.0*M[2] + 2.0*M[3] +     M[4] )/5.0;
	J[3]=( M[0] -     M[1] - 2.0*M[2] - 3.0*M[3] +     M[4] )/5.0;
	J[4]=( M[0] -     M[1] - 2.0*M[2] - 3.0*M[3] - 4.0*M[4] )/5.0;
	
	return;
}

