// PCI-3313用 ヘッダファイル
// 2010/04/01 Ver1.0  HIDETAKA MORIMITSU
// Ver1.0……1チャンネル固定変換用

void ADC3133settings(unsigned int BASE0){
	// ADCの設定を行う関数
	// あらかじめバイポーラ±10Vに設定を行っているが，
	// 変えたい場合は説明書に従ってボードのスイッチをいじること。
	
	iopl(3);					// I/O全アドレス空間にアクセス許可
	outb(0x80, BASE0+0x00);		// Ch1にセット(念のため)
	usleep(50);					// チャンネル切換え時間待機
	outb(0x01, BASE0+0x01);		// 差動モードに設定
	usleep(100);				// 念のための待機
	outb(0x00,BASE0+0x03);
	outb(0x40, BASE0+0x00);		// AD変換開始
	usleep(50);					// 念のための待機
	return;
}

void ADCin3133(unsigned int BASE0, unsigned short ADCdata[8]){
	// AD変換を行う関数
	// 上位・下位8ビットを取得し，結合したものをデータとして出力する。
	// ただ，12ビットのADCなので上位は正確にいうと4ビットしかない。
	
	unsigned short  Hbuff=0x00, Lbuff=0x00;		// 変換値取得用バッファ
	Lbuff=inb(BASE0+0x00);						// CH1 下位 8bit データ取得
	Hbuff=inb(BASE0+0x01);						// CH1 上位 8bit データ取得
	ADCdata[0]=IIbyteCat(Hbuff,Lbuff);			// 上位、中位、下位データを24itのデータに結合する
	outb(0x40, BASE0+0x00);						// AD変換開始
	return;
}

