clc;
clear;

FileName='DATA';

CsvData=csvread(strcat(FileName,'.csv'));

t=CsvData(:,1);
tlen=length(t);
Xres=CsvData(:,2);
XDDres=CsvData(:,3);
Fcmd=CsvData(:,4);
Fdis=CsvData(:,5);
clear CsvData;

%s=tf('s');
%g=1000;
%Glpf=g/(s+g);
%XDDresS=lsim(Glpf,XDDresS,t);

%g=1000;
%Glpf=g/(s+g);
%XDDresO=lsim(Glpf,XDDresO,t);

%{
%------- �Ԉ���
RedRate=10;	% �Ԉ����v�f��
t=t(1:RedRate:tlen);
Xres=Xres(1:RedRate:tlen);
XDDresS=XDDresS(1:RedRate:tlen);
XDDresD=XDDresD(1:RedRate:tlen);
XDDresO=XDDresO(1:RedRate:tlen);
Fcmd=Fcmd(1:RedRate:tlen);
Fdis=Fdis(1:RedRate:tlen);
%}

%%{
figure(1);
set(gcf,'PaperPositionMode','auto');
set(gcf,'color',[1 1 1]);
subplot(2,1,1);
	h=plot(t,Fcmd,t,Fdis);
        set(h,'linewidth',1);
	xlabel('Time [s](b)');
	ylabel('Force [N]');
    axis([0 10 -3 3]);
	legend('Command','Reponse','Location','NorthWest','Orientation','Horizontal');
	legend boxoff;
subplot(2,1,2);
	h=plot(t,XDDres);
        set(h,'linewidth',1);
	xlabel('Time [s](b)');
	ylabel('Force [N]');
    %axis([0 10 -1 1]);
	legend('Command','Reponse','Location','NorthWest','Orientation','Horizontal');
	legend boxoff;
%print(gcf,'-depsc2','-tiff',strcat(FileName,'.eps'));
%}

