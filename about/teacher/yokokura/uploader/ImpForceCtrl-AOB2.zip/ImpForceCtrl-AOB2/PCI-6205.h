//
// PCI-6205用 ヘッダファイル
// 2009/05/07 Rev.B  Yuki YOKOKURA
//


void ENCsettings(unsigned int BASE0,unsigned int BASE1,unsigned int BASE2,unsigned int BASE3){
	// エンコーダカウンタの設定を行う関数
	
	iopl(3);	// I/O全アドレス空間にアクセス許可
	
	outb(0x06,BASE0+0x04);	// CH1 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE0+0x14);	// CH2 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE1+0x04);	// CH3 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE1+0x14);	// CH4 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE2+0x04);	// CH5 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE2+0x14);	// CH6 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE3+0x04);	// CH7 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BASE3+0x14);	// CH8 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);

	return;
}


void ENCin(unsigned int BASE0, unsigned int BASE1, unsigned int BASE2, unsigned int BASE3, unsigned long ENCdata[8]){
	// エンコーダカウンタからカウント値を読み込む関数
	
	unsigned short Hbuff=0x00, Mbuff=0x00, Lbuff=0x00; // カウンタ値取得バッファ
	
	outb(0x02,BASE0+0x06);	// CH1 カウンタ値を読み出しレジスタに移動
	outb(0x02,BASE0+0x16);	// CH2 カウンタ値を読み出しレジスタに移動
	outb(0x02,BASE1+0x06);	// CH3 カウンタ値を読み出しレジスタに移動
	outb(0x02,BASE1+0x16);	// CH4 カウンタ値を読み出しレジスタに移動
	outb(0x02,BASE2+0x06);	// CH5 カウンタ値を読み出しレジスタに移動
	//outb(0x02,BASE2+0x16);	// CH6 カウンタ値を読み出しレジスタに移動
	
	// チャネル 1
	Lbuff=inb(BASE0+0x00);	// CH1 下位 8bit データ取得
	Mbuff=inb(BASE0+0x01);	// CH1 中位 8bit データ取得
	Hbuff=inb(BASE0+0x02);	// CH1 上位 8bit データ取得
	ENCdata[0]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 2
	Lbuff=inb(BASE0+0x10);	// CH2 下位 8bit データ取得
	Mbuff=inb(BASE0+0x11);	// CH2 中位 8bit データ取得
	Hbuff=inb(BASE0+0x12);	// CH2 上位 8bit データ取得
	ENCdata[1]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 3
	Lbuff=inb(BASE1+0x00);	// CH3 下位 8bit データ取得
	Mbuff=inb(BASE1+0x01);	// CH3 中位 8bit データ取得
	Hbuff=inb(BASE1+0x02);	// CH3 上位 8bit データ取得
	ENCdata[2]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 4
	Lbuff=inb(BASE1+0x10);	// CH4 下位 8bit データ取得
	Mbuff=inb(BASE1+0x11);	// CH4 中位 8bit データ取得
	Hbuff=inb(BASE1+0x12);	// CH4 上位 8bit データ取得
	ENCdata[3]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	
	// チャネル 5
	Lbuff=inb(BASE2+0x00);	// CH5 下位 8bit データ取得
	Mbuff=inb(BASE2+0x01);	// CH5 中位 8bit データ取得
	Hbuff=inb(BASE2+0x02);	// CH5 上位 8bit データ取得
	ENCdata[4]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	
	/*
	// チャネル 6
	Lbuff=inb(BASE2+0x10);	// CH6 下位 8bit データ取得
	Mbuff=inb(BASE2+0x11);	// CH6 中位 8bit データ取得
	Hbuff=inb(BASE2+0x12);	// CH6 上位 8bit データ取得
	ENCdata[5]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	
	// チャネル 7
	outb(0x02,BASE3+0x06);	// CH7 カウンタ値を読み出しレジスタに移動
	Lbuff=inb(BASE3+0x00);	// CH7 下位 8bit データ取得
	Mbuff=inb(BASE3+0x01);	// CH7 中位 8bit データ取得
	Hbuff=inb(BASE3+0x02);	// CH7 上位 8bit データ取得
	ENCdata[6]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 8
	outb(0x02,BASE3+0x16);	// CH8 カウンタ値を読み出しレジスタに移動
	Lbuff=inb(BASE3+0x10);	// CH8 下位 8bit データ取得
	Mbuff=inb(BASE3+0x11);	// CH8 中位 8bit データ取得
	Hbuff=inb(BASE3+0x12);	// CH8 上位 8bit データ取得
	ENCdata[7]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	*/
	
	//ENCdata[4]=0x7FFFFF;
	ENCdata[5]=0x7FFFFF;
	ENCdata[6]=0x7FFFFF;
	ENCdata[7]=0x7FFFFF;

	return;
}


void ENCzero(unsigned int BASE0,unsigned int BASE1,unsigned int BASE2,unsigned int BASE3){
	// エンコーダカウンタの値を零(0x800000)にする関数
	
	// チャネル 1
	outb(0x00,BASE0+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BASE0+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BASE0+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 2
	outb(0x00,BASE0+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BASE0+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BASE0+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 3
	outb(0x00,BASE1+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BASE1+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BASE1+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 4
	outb(0x00,BASE1+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BASE1+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BASE1+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 5
	outb(0x00,BASE2+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BASE2+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BASE2+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 6
	outb(0x00,BASE2+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BASE2+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BASE2+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 7
	outb(0x00,BASE3+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BASE3+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BASE3+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 8
	outb(0x00,BASE3+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BASE3+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BASE3+0x12);	// 上位カウンタへ書き込み
	
	
	return;
}


