//
// フィルタ関数
// 2010/08/19 Rev.D  Coded by Yuki YOKOKURA
//

double NotchFilter(double u, double w, double Q, double Ts){
	// ノッチフィルタ G(s)=( s^2 + w^2 )/( s^2 + w/Q*s + w^2) (双一次変換)
	// u；入力，w；遮断中心周波数，Q；鋭さ，Ts；サンプリング周期
	double y;
	static double uZ1=0, uZ2=0, yZ1=0, yZ2=0;
	
	y=1.0/(4.0+2.0*Ts*w/Q+w*w*Ts*Ts)*( (u+uZ2)*(4.0+w*w*Ts*Ts) + (uZ1-yZ1)*(2.0*w*w*Ts*Ts-8.0) - yZ2*(4.0-2.0*Ts*w/Q+w*w*Ts*Ts) );

	uZ2=uZ1;
	uZ1=u;
	yZ2=yZ1;
	yZ1=y;
	
	return y;
}

double LPF(double u, double Ts, double g){
	// 1次低域通過濾波器 G(s)=g/(s+g) (双一次変換)
	double y;
	static double uZ1=0, yZ1=0;
	
	y= g*Ts/(2.0+g*Ts)*(u+uZ1) + (2.0-g*Ts)/(2.0+g*Ts)*yZ1;
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

double LPF1(double u, double Ts, double g){
	// 1次低域通過濾波器 G(s)=g/(s+g) (双一次変換)
	double y;
	static double uZ1=0, yZ1=0;
	
	y= g*Ts/(2.0+g*Ts)*(u+uZ1) + (2.0-g*Ts)/(2.0+g*Ts)*yZ1;
	
	uZ1=u;
	yZ1=y;
	
	return y;
}
double LPF2(double u, double Ts, double g){
	// 1次低域通過濾波器 G(s)=g/(s+g) (双一次変換)
	double y;
	static double uZ1=0, yZ1=0;
	
	y= g*Ts/(2.0+g*Ts)*(u+uZ1) + (2.0-g*Ts)/(2.0+g*Ts)*yZ1;
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

double LPF2ord(double u, double Ts, double w, double Q){
	// 2次低域通過濾波器 G(s)=w^2/(s^2 + w/Q*s + w^2) (双一次変換)
	// u；入力，Ts；制御周期 [s]，w；カットオフ周波数 [rad/s]，Q；鋭さ
	double y;
	static double yZ1=0, yZ2=0, yZ3=0;
	static double uZ1=0, uZ2=0, uZ3=0;
	
	y = Q*Ts*Ts*Ts*w*w*(u+3.0*uZ1+3.0*uZ2+uZ3)
	   -4.0*Q*Ts*(yZ3-yZ2-yZ1)
	   -2.0*w*Ts*Ts*(-yZ3-yZ2+yZ1)
	   -Q*Ts*Ts*Ts*w*w*(yZ3+3.0*yZ2+3.0*yZ1);
	y = y * 1.0/(4.0*Q*Ts + 2.0*w*Ts*Ts + Q*Ts*Ts*Ts*w*w);
	
	uZ3=uZ2;
	uZ2=uZ1;
	uZ1=u;
	yZ3=yZ2;
	yZ2=yZ1;
	yZ1=y;
	
	return y;
}

double HPF(double u, double Ts, double g){
	// 1次高域通過濾波器 G(s)=s/(s+g) (双一次変換)
	double y;
	static double uZ1=0, yZ1=0;
	
	y=1.0/(g*Ts+2.0)*( 2.0*(u-uZ1) - yZ1*(g*Ts-2.0) );
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

double HPF2ord(double u, double Ts, double w, double Q){
	// 2次高域通過濾波器 G(s)=s^2/(s^2 + w/Q*s + w^2) (双一次変換)
	// u；入力，Ts；制御周期 [s]，w；カットオフ周波数 [rad/s]，Q；鋭さ
	double y;
	static double yZ1=0, yZ2=0, yZ3=0;
	static double uZ1=0, uZ2=0, uZ3=0;
	
	y = 4.0*Q*Ts*(uZ3-uZ2-uZ1+u)
	   -4.0*Q*Ts*(yZ3-yZ2-yZ1)
	   -2.0*w*Ts*Ts*(-yZ3-yZ2+yZ1)
	   -Q*Ts*Ts*Ts*w*w*(yZ3+3.0*yZ2+3.0*yZ1);
	y = y * 1.0/(4.0*Q*Ts + 2.0*w*Ts*Ts + Q*Ts*Ts*Ts*w*w);
	
	uZ3=uZ2;
	uZ2=uZ1;
	uZ1=u;
	yZ3=yZ2;
	yZ2=yZ1;
	yZ1=y;
	
	return y;
}

