// ARCS画面描画クラス
// 2011/02/09 Yuki YOKOKURA
//
// Advanced Robot Control System 用画面の描画を行います。
//

#ifndef RCSSCREEN
#define RCSSCREEN

#include <curses.h>
#include "Parameters.hh"
#include "GraphPlot2D.hh"

// ARCS指令定義
#define ARCS_ID_START		0
#define ARCS_ID_EXIT		1
#define ARCS_ID_STOP		2
#define ARCS_ID_SAVEEXIT	3
#define ARCS_ID_DISCEXIT	4

// ARCS状態定義
#define ARCS_PHASE_START	10
#define ARCS_PHASE_RUN		11
#define ARCS_PHASE_EXIT		12

class ARCSscreen {
	// RCS画面描画クラス
	private:
		FrameGraphics* FG;						// フレームバッファへのポインタ
		GraphPlot2D* GraphA;					// グラフAへのポインタ
		GraphPlot2D* GraphB;					// グラフBへのポインタ
		void AddHLine(int X1, int X2, int Y);	// 水平罫線の描画
		void AddVLine(int Y1, int Y2, int X);	// 垂直罫線の描画
		void PrintScreen(void);					// 画面の描画を行う  但し数値の描画は行わない
		void OperationIndic(bool SW);
		void StorageIndic(bool SW);
		void NetLinkIndic(bool SW);
		enum CMD_ID {
			CMD_ON,
			CMD_OFF,
			CMD_DISABLE
		};
		enum TEXT_COLOR {
			WHITE_BLACK=1,
			BLACK_CYAN,
			CYAN_BLACK,
			WHITE_BLUE,
			BLUE_BLACK,
			WHITE_RED,
			BLACK_YELLOW,
			BLACK_GREEN,
			GREEN_BLACK,
			RED_BLACK
		};
		void StartCommand(enum CMD_ID command);
		void ExitCommand(enum CMD_ID command);
		void StopCommand(enum CMD_ID command);
		void DiscExitCommand(enum CMD_ID command);
		void SaveExitCommand(enum CMD_ID command);
		void CommandPrint(int phase, int* count);
		void CommandPrintInit(int phase, int* count);
		void StatusIndic(int y, int x, double Iref, double Irat, double Imax);
		void MessageText(const char* Text, int color);	// ARCS画面一番下にメッセージを表示する関数
	
	public:
		ARCSscreen(void);							// 画面描画の初期化と準備を行う
		~ARCSscreen(void);							// RCS画面表示の消去
		void PrintValue(VariableParams* VarParams);	// 数値とグラフの描画を行う
		int CommandInput(int phase);
		void Start(void);
		void Stop(void);
};

#endif

