// PCI-3340入出力クラス
// 2011/02/09 Yuki YOKOKURA
//
// Interface社製PCI-3340のための入出力機能を提供します。
//

#include "PCI-3340.hh"

// 以下のコードはリエントラントであるのでスレッドセーフ関数である(はず)
// 従って複数スレッドから呼び出ししても問題ない(はず)

DAC3340::DAC3340(unsigned int Base0, const double MaxCur[MAX_CH], const double VoltPerAmp[MAX_CH]){
	// コンストラクタ(DAC初期化＆設定)
	BaseAddr0=Base0;							// Baseアドレスの格納
	memcpy(Imax,MaxCur,sizeof(Imax));			// 最大電流値の格納
	memcpy(VperA,VoltPerAmp,sizeof(VoltPerAmp));// サーボアンプ電圧電流換算ゲインの格納
	Settings();
	Zero();
}

DAC3340::~DAC3340(){
	// デストラクタ(DAC終了処理)
	Zero();
}

void DAC3340::OutCurrentCmd(volatile double Iref[MAX_CH]){
	// 電流指令値をDACから出力
	unsigned short DACdata[MAX_CH]={0x8000};
	
	for(unsigned int i=0;i<MAX_CH;i++)DACdata[i]=VoltToDacData(CurrentToVolt(CurrentLimitter(Iref[i],i),i));
	Output(DACdata);
}

double DAC3340::CurrentLimitter(double Iref, unsigned int ch){
	// 電流リミッタ
	if(Imax[ch]<Iref)Iref=Imax[ch];
	if(Iref<-Imax[ch])Iref=-Imax[ch];
	return Iref;
}

double DAC3340::CurrentToVolt(double Iref, unsigned int ch){
	// 電流指令値[A]からDAC出力電圧[V]に変換
	// サーボアンプの設定に従い定数を変更せよ
	// サーボアンプの設定例：3V/0.72A → 3V 与えると 0.72A 流す
	return (Iref*VperA[ch]);
}

unsigned short DAC3340::VoltToDacData(double Vdac){
	// DAC出力電圧[V]からDACの実際の整数値に変換する
	// DACの仕様に従い定数を変更せよ
	// DACの設定：±10V 16bit (+10V=65525 0V=32767 -10V=0)
	return (unsigned short)( Vdac/(20.0/65535.0) + 32767.0 );
}

void DAC3340::Settings(void){
	// DACの設定を行う関数
	
	iopl(3);	// I/O全アドレス空間にアクセス許可
	//------- DAC 設定
	// DAC チャネル 1
	outb(0x00,BaseAddr0+0x07);	// CH1 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 2
	outb(0x01,BaseAddr0+0x07);	// CH2 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 3
	outb(0x02,BaseAddr0+0x07);	// CH3 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 4
	outb(0x03,BaseAddr0+0x07);	// CH4 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 5
	outb(0x04,BaseAddr0+0x07);	// CH5 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 6
	outb(0x05,BaseAddr0+0x07);	// CH6 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 7
	outb(0x06,BaseAddr0+0x07);	// CH7 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	// DAC チャネル 8
	outb(0x07,BaseAddr0+0x07);	// CH8 設定
	outb(0x03,BaseAddr0+0x06);	// 出力電圧範囲を±10Vに設定
	usleep(100);				// 設定後に必要な100μsの待機
	
	outb(0x03,BaseAddr0+0x05);	// 全チャネル同時出力設定
	
	return;
}


void DAC3340::Output(unsigned short DACdata[MAX_CH]){
	// DACから指定した電圧を出力する関数
	
	//------- DAC 出力
	// DAC チャネル 1
	outb(0x00,BaseAddr0+0x02);					// CH1 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[0]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[0]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 2
	outb(0x01,BaseAddr0+0x02);					// CH2 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[1]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[1]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 3
	outb(0x02,BaseAddr0+0x02);					// CH3 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[2]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[2]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 4
	outb(0x03,BaseAddr0+0x02);					// CH4 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[3]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[3]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 5
	outb(0x04,BaseAddr0+0x02);					// CH5 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[4]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[4]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 6
	outb(0x05,BaseAddr0+0x02);					// CH6 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[5]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[5]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 7
	outb(0x06,BaseAddr0+0x02);					// CH7 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[6]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[6]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	// DAC チャネル 8
	outb(0x07,BaseAddr0+0x02);					// CH8 設定		[上位0xFF 下位0xFF]→ +10V
	outb(IIbyteLo(DACdata[7]),BaseAddr0+0x00);	// DAC出力 下位	[上位0x80 下位0x00]→   0V
	outb(IIbyteHi(DACdata[7]),BaseAddr0+0x01);	// DAC出力 上位	[上位0x00 下位0x00]→ -10V
	
	outb(0x01,BaseAddr0+0x05);	// 全チャネル同時出力実行
	
	return;
}


void DAC3340::Zero(void){
	// DACの出力電圧を 0[V] にする関数
	unsigned short DACdata[MAX_CH]={0};
	for(unsigned int i=0;i<MAX_CH;i++)DACdata[i]=0x8000;
	Output(DACdata);
	return;
}

unsigned short DAC3340::IIbyteHi(unsigned short in){
	// 2byteデータの上位1byteを抽出して出力
	return 0x00FF & (in >> 8);
}

unsigned short DAC3340::IIbyteLo(unsigned short in){
	// 2byteデータの下位1byteを抽出して出力
	return 0x00FF & in;
}


