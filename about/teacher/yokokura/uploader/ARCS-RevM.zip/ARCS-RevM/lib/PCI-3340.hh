// PCI-3340入出力クラス
// 2011/02/09 Yuki YOKOKURA
//
// Interface社製PCI-3340のための入出力機能を提供します。
//
#ifndef PCI3340
#define PCI3340

#include <sys/io.h>
#include <unistd.h>
#include <string.h>

class DAC3340 {
	private:
		static const unsigned int MAX_CH=8;	// チャネル最大値
		unsigned int BaseAddr0;				// 先頭アドレス0
		double Imax[MAX_CH];				// 最大電流
		double VperA[MAX_CH];				// サーボアンプ電圧電流換算ゲイン
		
		void Settings(void);									// DACの設定を行う関数
		void Output(unsigned short DACdata[MAX_CH]);			// DACから指定した電圧を出力する関数
		void Zero(void);										// DACの出力電圧を 0[V] にする関数
		unsigned short IIbyteHi(unsigned short in);				// 2byteデータの上位1byteを抽出して出力
		unsigned short IIbyteLo(unsigned short in);				// 2byteデータの下位1byteを抽出して出力
		double CurrentLimitter(double Iref, unsigned int ch);	// 電流リミッタ
		double CurrentToVolt(double Iref, unsigned int ch);		// 電流指令値[A]からDAC出力電圧[V]に変換
		unsigned short VoltToDacData(double Vdac);				// DAC出力電圧[V]からDACの実際の整数値に変換する
		
	public:
		// コンストラクタ(DAC初期化＆設定)
		DAC3340(unsigned int Base0, const double MaxCur[MAX_CH], const double VoltPerAmp[MAX_CH]);
		~DAC3340();											// デストラクタ(DAC終了処理)
		void OutCurrentCmd(volatile double Iref[MAX_CH]);	// 電流指令値をDACから出力
};

#endif



