// 低域通過濾波器クラス
// 2011/02/14 Yuki YOKOKURA
//
// 1次低域通過濾波器 G(s)=g/(s+g) (双一次変換)
//

#ifndef LOWPASSFILTER
#define LOWPASSFILTER

class LowPassFilter {
	private:
		double Ts;	// [s]		制御周期
		double g;	// [rad/s]	遮断周波数
		double uZ1;	// 			状態変数1 変数名Z1の意味はz変換のz^(-1)を示す
		double yZ1;	//			状態変数2
	
	public:
		LowPassFilter(double CutFreq, double SmplTime);
		// コンストラクタ CutFreq；[rad/s] 遮断周波数，SmplTime；[s] 制御周期
		~LowPassFilter();					// デストラクタ
		double GetSignal(double u);			// 出力信号の取得 u；入力信号
		void SetCutFreq(double CutFreq);	// 遮断周波数の再設定 CutFreq；[rad/s] 遮断周波数
		void SetSmplTime(double SmplTime);	// 制御周期の再設定 SmplTime；[s] 制御周期
		void ClearStateVars(void);			// すべての状態変数のリセット
};

#endif



