
#include "RTAItask.hh"

RTAItask::RTAItask(unsigned int ThreadNum, void (**PeriodicFuncs)(void*), void* FuncArgs, const unsigned long *PeriodicTime){
	// コンストラクタ
	NumOfThread=ThreadNum;				// 動作させるスレッドの数を格納
	MinPeriodicTime=PeriodicTime[0];	// 一番速いスレッドの制御周期を格納

	rt_allow_nonroot_hrt();				// root以外での動作を許可
	if (!(RTtaskID = rt_task_init(nam2num("RTAI"), NumOfThread, STACK_SIZE, 0))){	// RTAIタスクの初期化
		StateFlag=RTID_TASK_ERR;		// 初期化できなかったら，動作状態フラグを「タスク内エラー検出」に設定
		return;							// そして終了
	}
	rt_task_use_fpu(RTtaskID,1);		// 浮動小数点が使用可能になるように設定
	
	// 個々の実時間スレッドを生成(メモリ確保)
	char buff[8]={'\0'};				// ユニークなスレッド識別用文字列の生成用バッファ
	for(unsigned int i=0;i<NumOfThread;i++){
		sprintf(buff,"%i",i);			// ユニークなスレッド識別用文字列の生成
		pRTthread[i] = new RTAIthread(
			strcat(buff,"RTAI"),		// ユニークなスレッド識別用文字列
			PeriodicTime[i],			// 制御周期
			i,							// 優先順位
			PeriodicFuncs[i],			// 関数ポインタ
			FuncArgs					// 関数ポインタの引数
		);
	}
	rt_set_oneshot_mode();				// 単発モードに設定
}

RTAItask::~RTAItask(){
	// デストラクタ
	for(unsigned int i=0;i<NumOfThread;i++)delete pRTthread[i];	// すべての実時間スレッドの消去(メモリ解放)
	rt_task_delete(RTtaskID);									// 実時間タスクを消去
}

void RTAItask::Start(void){
	// 実時間スレッドを開始させる関数
	start_rt_timer(0);		// リアルタイムタイマを開始
}

void RTAItask::Stop(void){
	// 実時間スレッドを終了させる関数
	volatile int Flag=1;	// 終了処理待機フラグ(0；まだ終了してない，1；すでに終了した)
	unsigned int i;
	
	for(i=0;i<NumOfThread;i++)pRTthread[i]->SendState(RTID_STOP);	// 全ての実時間スレッドへ終了信号を送信
	
	// すべての実時間スレッド終了処理が完了するまで待機
	while(1){
		Flag=1;				// 終了処理待機フラグセット
		
		// 零との論理積を取ることでどれか一つでもスレッドの終了処理が完了してなければ，Flagは零になる
		for(i=0;i<NumOfThread;i++){
			if(pRTthread[i]->ReadState()!=RTID_EXCMPL)Flag &= 0;	// まだ終了処理が完了してなければ待機
		}
		if(Flag==1)break;	// すべてのスレッドが終了していれば while を抜ける
		usleep(THREAD_EXIT_WAIT);
	}
	
	stop_rt_timer();		// リアルタイムタイマを停止
}

void RTAItask::SendState(int State){
	// 動作状態を書き込む
	// State；所望の動作状態
	StateFlag=State;
	return;
}

int RTAItask::ReadState(void){
	// 動作状態を読み出す
	// 戻り値；現在の動作状態
	return StateFlag;
}

void RTAItask::GetTimeValue(volatile double *Time, volatile long *PeriodicTime, volatile long *ComputationTime){
	// 開始からの経過時間と計算に要した消費時間を取得する関数
	
	// 最優先実時間スレッドの時刻の取得
	*Time = pRTthread[0]->GetTime()*(double)MinPeriodicTime*1e-9;
	
	// 各実時間スレッドの周期時間と消費時間の取得
	for(unsigned int i=0;i<NumOfThread;i++){
		PeriodicTime[i] = pRTthread[i]->GetSmplTime()/1000;
		ComputationTime[i] = pRTthread[i]->GetCompTime()/1000;
	}
	
}


