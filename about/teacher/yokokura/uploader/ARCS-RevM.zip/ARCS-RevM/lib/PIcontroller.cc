// PI制御器クラス
// 2011/02/12 Yuki YOKOKURA
//
// PI制御器 G(s) = Kp + Ki/s (双一次変換)
//

#include "PIcontroller.hh"

PIcontroller::PIcontroller(double Pgain, double Igain, double SmplTime){
	// コンストラクタ
	// Pgain；比例ゲイン，Igain；積分ゲイン，SmplTime；[s] 制御周期
	Kp=Pgain;			// 		比例ゲインの格納
	Ki=Igain;			// 		積分ゲインの格納
	Ts=SmplTime;		// [s]	制御周期の格納
	ClearStateVars();	// 状態変数のクリア
}

PIcontroller::~PIcontroller(){
	// デストラクタ
}

double PIcontroller::GetSignal(double u){
	// 出力信号の取得 u；入力信号
	double y;
	
	y = ( (Ki*Ts+2.0*Kp)*u + (Ki*Ts-2.0*Kp)*uZ1 )/2.0 + yZ1;
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

void PIcontroller::SetPgain(double Pgain){
	// 比例ゲインの再設定 Pgain；比例ゲイン
	Kp=Pgain;
}

void PIcontroller::SetIgain(double Igain){
	// 積分ゲインの再設定 Igain；積分ゲイン
	Ki=Igain;
}

void PIcontroller::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts=SmplTime;	// [s] 制御周期の再設定
}

void PIcontroller::ClearStateVars(void){
	// すべての状態変数のリセット
	uZ1=0;	// 状態変数1のゼロクリア
	yZ1=0;	// 状態変数2のゼロクリア
}


