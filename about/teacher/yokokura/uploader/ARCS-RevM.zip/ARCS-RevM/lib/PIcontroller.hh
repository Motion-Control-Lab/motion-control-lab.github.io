// PI制御器クラス
// 2011/02/12 Yuki YOKOKURA
//
// PI制御器 G(s) = Kp + Ki/s (双一次変換)
//

#ifndef PICTRLLER
#define PICTRLLER

class PIcontroller {
	private:
		double Ts;	// [s]	制御周期
		double Kp;	//		比例ゲイン
		double Ki;	//		積分ゲイン
		double uZ1;	// 		状態変数1 変数名Z1の意味はz変換のz^(-1)を示す
		double yZ1;	//		状態変数2
	
	public:
		PIcontroller(double Pgain, double Igain, double SmplTime);
		// コンストラクタ
		// Pgain；比例ゲイン，Igain；積分ゲイン，SmplTime；[s] 制御周期
		~PIcontroller();					// デストラクタ
		double GetSignal(double u);			// 出力信号の取得 u；入力信号
		void SetPgain(double Pgain);		// 比例ゲインの再設定 Pgain；比例ゲイン
		void SetIgain(double Igain);		// 積分ゲインの再設定 Igain；積分ゲイン
		void SetSmplTime(double SmplTime);	// 制御周期の再設定 SmplTime；[s] 制御周期
		void ClearStateVars(void);			// すべての状態変数のリセット
};

#endif



