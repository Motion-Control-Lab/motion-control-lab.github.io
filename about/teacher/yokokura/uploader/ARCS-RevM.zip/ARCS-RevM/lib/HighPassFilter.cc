// 高域通過濾波器クラス
// 2011/02/14 Yuki YOKOKURA
//
// 1次高域通過濾波器 G(s)=s/(s+g) (双一次変換)
//

#include "HighPassFilter.hh"

HighPassFilter::HighPassFilter(double CutFreq, double SmplTime){
	// コンストラクタ CutFreq；[rad/s] 遮断周波数，SmplTime；[s] 制御周期
	g=CutFreq;			// [rad/s]	遮断周波数
	Ts=SmplTime;		// [s]		制御周期の格納
	ClearStateVars();	// 状態変数のクリア
}

HighPassFilter::~HighPassFilter(){
	// デストラクタ
}

double HighPassFilter::GetSignal(double u){
	// 出力信号の取得 u；入力信号
	double y;
	
	y=1.0/(g*Ts+2.0)*( 2.0*(u-uZ1) - yZ1*(g*Ts-2.0) );
	
	uZ1=u;
	yZ1=y;
	
	return y;
}

void HighPassFilter::SetCutFreq(double CutFreq){
	// 遮断周波数の再設定 CutFreq；[rad/s] 遮断周波数
	g=CutFreq;		// [rad/s]	遮断周波数の再設定
}

void HighPassFilter::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts=SmplTime;	// [s] 制御周期の再設定
}

void HighPassFilter::ClearStateVars(void){
	// すべての状態変数のリセット
	uZ1=0;	// 状態変数1のゼロクリア
	yZ1=0;	// 状態変数2のゼロクリア
}



