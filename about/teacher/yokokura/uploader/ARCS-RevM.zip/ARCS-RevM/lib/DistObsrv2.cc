// 外乱オブザーバクラス
// 2011/02/10 Yuki YOKOKURA
//
// 2次形 外乱オブザーバ
//
// 詳細は以下の論文を参照のこと。
// K. Ohnishi, M. Shibata, and T. Murakami : "Motion Control for Advanced Mechatronics"
// IEEE/ASME Trans. on Mechatronics, Vol. 1, No. 1, Mar. 1996.
//

#include "DistObsrv2.hh"

DistObsrv2::DistObsrv2(double gdis, double Mass, double TrqConst, double SmplTime){
	// コンストラクタ
	// gdis；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
	// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
	
	k1	= gdis*gdis;	// 					2次外乱オブザーバ用係数1(重根の場合)
	k2	= 2.0*gdis;		// 					2次外乱オブザーバ用係数2(重根の場合)
	Mn	= Mass;			// [kg]				慣性の格納
	Kfn	= TrqConst;		// [N/A] or [Nm/A]	推力orトルク定数の格納
	Ts	= SmplTime;		// [s]				制御周期の格納
	ClearStateVars();	// 状態変数のクリア
}

DistObsrv2::~DistObsrv2(){
	// デストラクタ
}

double DistObsrv2::GetForce(double Iref, double Xres){
	// 推定外乱の取得 Iref；[A] 電流参照値，Xres；[m] or [rad] 位置応答値
	double z1,z2,Fdis;
	
	z1=Ts*( -k1*z2Z1 -k1*k2*XresZ1 ) +z1Z1;
	z2=Ts*( z1Z1 -k2*z2Z1 +(k1-k2*k2)*XresZ1 +IrefZ1*Kfn/Mn ) +z2Z1;
	
	Fdis=Mn*( -k1*Xres -z1 );
	
	z1Z1=z1;
	z2Z1=z2;
	XresZ1=Xres;
	IrefZ1=Iref;
	
	return Fdis;
}

void DistObsrv2::SetBandwidth(double gdis){
	// 帯域の再設定 gdis；[rad/s] 帯域
	k1	= gdis*gdis;	// 2次外乱オブザーバ用係数1(重根の場合)
	k2	= 2.0*gdis;		// 2次外乱オブザーバ用係数2(重根の場合)
}

void DistObsrv2::SetInertia(double Mass){
	// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
	Mn	= Mass;			// [kg] 慣性の格納
}

void DistObsrv2::SetTrqConst(double TrqConst){
	// 推力 or トルク定数の再設定 TrqConst；[N/A] or [Nm/A] 推力 or トルク定数
	Kfn	= TrqConst;		// [N/A] or [Nm/A] 推力orトルク定数の格納
}

void DistObsrv2::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts	= SmplTime;		// [s] 制御周期の格納
}

void DistObsrv2::ClearStateVars(void){
	// すべての状態変数のリセット
	z1Z1	= 0;	// 				状態変数1
	z2Z1	= 0;	//				状態変数2
	IrefZ1	= 0;	// [A]			状態変数 電流参照値
	XresZ1	= 0;	// [m] or [rad]	状態変数 位置応答値
}



