// 加速度オブザーバクラス
// 2011/02/16 Yuki YOKOKURA
//
// 加速度オブザーバ
// 加速度参照値と外乱オブザーバによる推定外乱から加速度応答値を計算する

#include "AccObsrv.hh"

AccObsrv::AccObsrv(double AccBandwidth, double DistBandwidth, double Mass, double SmplTime)
	// コンストラクタ
	// gdis；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
	// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
	: gacc(AccBandwidth), gdis(DistBandwidth), Mn(Mass), Ts(SmplTime)
{
	ClearStateVars();
}

AccObsrv::~AccObsrv(){
	// デストラクタ
}

double AccObsrv::GetAcceleration(double XDDref, double Fdis){
	// 加速度応答の取得 XDDref；[m/s^2] 加速度参照値，Fdis；[N] 推定外乱
	double XDDres;
	
	XDDres = ( (2.0-gacc*Ts)*XDDresZ1 + gacc*Ts*(XDDref+XDDrefZ1) - (2.0*gacc)/(gdis*Mn)*(Fdis-FdisZ1) )/(2.0+gacc*Ts);
	
	XDDrefZ1 = XDDref;
	FdisZ1 = Fdis;
	XDDresZ1 = XDDres;
	
	return XDDres;
}

void AccObsrv::SetAccBandwidth(double Bandwidth){
	// 加速度オブザーバの帯域の再設定 Bandwidth；[rad/s] 帯域
	gacc=Bandwidth;
}

void AccObsrv::SetDistBandwidth(double Bandwidth){
	// 外乱オブザーバの帯域の再設定 Bandwidth；[rad/s] 帯域
	gdis=Bandwidth;
}

void AccObsrv::SetInertia(double Mass){
	// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
	Mn=Mass;
}

void AccObsrv::SetSmplTime(double SmplTime){
	// 制御周期の再設定 SmplTime；[s] 制御周期
	Ts=SmplTime;
}

void AccObsrv::ClearStateVars(void){
	// すべての状態変数のリセット
	XDDrefZ1=0;
	FdisZ1=0;
	XDDresZ1=0;
}



