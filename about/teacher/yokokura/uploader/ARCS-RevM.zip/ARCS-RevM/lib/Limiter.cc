// リミッタ
// 2011/02/14 Yuki YOKOKURA
//
// 任意の数値で入力を制限して出力
//

#include "Limiter.hh"

double Limiter(double input, double limit){
	// リミッタ input；入力信号，limit；制限値
	if(limit<input)input=limit;		// 任意の数値で入力を制限して出力
	if(input<-limit)input=-limit;
	return input;
}


