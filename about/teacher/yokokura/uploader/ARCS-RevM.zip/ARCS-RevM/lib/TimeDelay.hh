// 遅延器クラス
// 2011/02/16 Yuki YOKOKURA
//
// 遅延器 G(s)=e^(-s*T*n) -> G(z)=z^(-n)
// (但し T は制御周期で，制御周期単位でしか遅延時間を設定できないことに注意)
//

#ifndef TIMEDELAY
#define TIMEDELAY

class TimeDelay {
	private:
		long dmem_max;	// 最大遅延時間
		long num;		// 遅延時間
		long Wcount;	// 書き込みカウンタ
		long Rcount;	// 読み出しカウンタ
		double* dmem;	// 遅延メモリ
		
	public:
		TimeDelay(const long MaxDelay);			// コンストラクタ MaxDelay；最大遅延時間
		~TimeDelay();							// デストラクタ
		double GetSignal(const double u);		// 出力信号の取得 u；入力信号
		void SetDelayTime(const long DelayTime);//遅延時間の設定 DelayTime；遅延時間 (最大遅延時間を越えないこと)
		void ClearDelayMemory(void);			// 遅延メモリのゼロクリア
};

#endif



