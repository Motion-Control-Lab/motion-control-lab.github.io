// リングバッファクラス
// 2011/02/14 Yuki YOKOKURA
//
// リングバッファ
//

#ifndef RINGBUFFER
#define RINGBUFFER

class RingBuffer {
	private:
		unsigned long N;	// リングバッファの大きさ
		unsigned long i;	// リングバッファカウンタ
		double* Buffer;	// リングバッファ
	
	public:
		RingBuffer(unsigned long Length);	// コンストラクタ Length；リングバッファの大きさ
		~RingBuffer();						// デストラクタ
		void PutValue(double u);			// 値をバッファに格納(同時にバッファのカウンタが増加) u；入力値
		double GetValue(void);				// バッファから最後尾の値を取り出す 戻り値；出力値
		double* GetPointer(void);			// バッファへのポインタを返す
		void SetCounter(unsigned long j);	// カウンタを任意値に設定 j；任意のカウント値
		void ResetCounter(void);			// カウンタリセット
		void ClearBuffer(void);				// バッファのゼロクリア
};

#endif



