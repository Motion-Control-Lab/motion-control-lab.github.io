
#ifndef RTAITASK
#define RTAITASK

#include <rtai_lxrt.h>
#include <string.h>
#include "RTAIthread.hh"

// 動作状態の定義
#define RTID_TASK_ERR	-1	// タスク内エラー検出
#define RTID_THRD_ERR	-2	// スレッド内エラー検出

typedef void (**FuncPtrs)(void*);	// 関数ポインタ配列キャスト用

class RTAItask {
	private:
		static const unsigned int	MAX_THREAD			= 128;	// スレッド最大数 (動的追従はあとで)
		static const int			STACK_SIZE			= 4096;	// RTAIスレッドスタックサイズ
		static const unsigned long	THREAD_EXIT_WAIT	= 50000;// [us] スレッド終了処理待機時間
		
		unsigned int NumOfThread;			// 動作させるスレッドの数
		unsigned long MinPeriodicTime;		// [ns] 一番速いスレッドの制御周期
		volatile int StateFlag;				// 動作状態フラグ
		RT_TASK *RTtaskID;					// 実時間タスク識別子
		RTAIthread* pRTthread[MAX_THREAD];	// 実時間スレッド 0 ～ MAX_THREAD へのポインタ
		
	public:
		// コンストラクタ
		RTAItask(
			unsigned int ThreadNum,				// 動作させるスレッドの数
			void (**PeriodicFuncs)(void*),		// 制御用周期実行関数群への関数ポインタ
			void* FuncArgs,						// 関数ポインタ引数
			const unsigned long *PeriodicTime	// 制御周期
		);
		~RTAItask();					// デストラクタ
		void Start(void);				// 実時間スレッドを開始させる関数
		void Stop(void);				// 実時間スレッドを終了させる関数
		void SendState(int State);		// 動作状態を書き込む State；所望の動作状態
		int  ReadState(void);			// 動作状態を読み出す 戻り値；現在の動作状態
		// 開始からの経過時間と計算に要した消費時間を取得する関数
		void GetTimeValue(volatile double *Time, volatile long *PeriodicTime, volatile long *ComputationTime);
};

#endif

