// 統計処理
// 2011/02/14 Yuki YOKOKURA
//
// 平均，分散，標準偏差，共分散，相関係数の計算
//

#ifndef STATISTICS
#define STATISTICS

#include <math.h>

double Average(const double *u);						// 信号uの平均を計算する
double Variance(const double *u);						// 信号uの分散を求める
double StandardDev(const double *u);					// 信号uの標準偏差を求める
double Covariance(const double *u1, const double *u2);	// 信号u1と信号u2の間の共分散を計算する
double Correlation(const double *u1, const double *u2);	// 信号u1と信号u2の間の相関係数を求める

#endif

