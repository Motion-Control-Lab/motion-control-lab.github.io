// PCI-3133入出力クラス
// 2011/02/18 HIDETAKA MORIMITSU & Yuki YOKOKURA
//
// Interface社製PCI-3133のための入出力機能を提供します。
// 1チャンネル固定変換用

#ifndef PCI3133
#define PCI3133

#include <sys/io.h>
#include <unistd.h>

class ADC3133 {
	private:
		unsigned int BaseAddr;							// 先頭アドレス
		void Settings(void);							// A/Dコンバータの設定を行う関数
		unsigned short Input(void);						// A/Dコンバータから電圧データを読み込む関数
		double AdcDataToVolt(unsigned short ADCdata);	// 電圧データから電圧値[V]に変換する関数
		unsigned long IIbyteCat(unsigned short High, unsigned short Low);
		// 上位、下位に分かれている各々1バイトのデータを、2バイトのデータに結合する

	public:
		ADC3133(const unsigned int Base);		// コンストラクタ(ADC初期化＆設定)
		~ADC3133();								// デストラクタ(ADC終了処理)
		volatile double GetVoltage(void);		// 電圧値[V]を取得
};

#endif



