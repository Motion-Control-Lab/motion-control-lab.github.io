// PCI-6205入出力クラス
// 2011/02/09 Yuki YOKOKURA
//
// Interface社製PCI-6205のための入出力機能を提供します。
//

#ifndef PCI6205
#define PCI6205

#include <sys/io.h>
#include <unistd.h>
#include <string.h>

class ENC6205 {
	private:
		static const unsigned int MAX_CH=8;				// チャネル最大値
		unsigned int BaseAddr[4];						// 先頭アドレス
		double Resolutions[MAX_CH];						// [m] エンコーダ分解能
		void Settings(void);							// エンコーダカウンタの設定を行う関数
		void Input(unsigned long ENCdata[MAX_CH]);		// エンコーダカウンタからカウント値を読み込む関数
		void Zero(void);								// エンコーダカウンタの値を零(0x800000)にする関数
		// エンコーダカウンタ値から位置[m]へ変換する関数
		double EncDataToPosition(unsigned long EncData, unsigned int ch);
		// 上位、中位、下位に分かれている各々1バイトのデータを、3バイトのデータに結合する関数
		unsigned long IIIbyteCat(unsigned short High, unsigned short Middle, unsigned short Low);
	
	public:
		ENC6205(const int Base[4], const double EncResolutions[MAX_CH]);	// コンストラクタ(ENC初期化＆設定)
		~ENC6205();															// デストラクタ(ENC終了処理)
		void InPositionRes(volatile double Xres[MAX_CH]);					// 位置応答値をカウンタから入力
};

#endif



