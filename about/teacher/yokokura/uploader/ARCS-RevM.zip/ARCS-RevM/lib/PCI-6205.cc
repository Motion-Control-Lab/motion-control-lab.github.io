// PCI-6205入出力クラス
// 2011/02/09 Yuki YOKOKURA
//
// Interface社製PCI-6205のための入出力機能を提供します。
//

#include "PCI-6205.hh"

ENC6205::ENC6205(const int Base[4], const double EncResolutions[MAX_CH]){
	// コンストラクタ(ENC初期化＆設定)
	memcpy(BaseAddr,Base,sizeof(BaseAddr));
	memcpy(Resolutions,EncResolutions,sizeof(Resolutions));
	Settings();
	Zero();
}

ENC6205::~ENC6205(){
	// デストラクタ(ENC終了処理)
	Zero();
}

void ENC6205::InPositionRes(volatile double Xres[MAX_CH]){
	// 位置応答値をカウンタから入力
	unsigned long ENCdata[MAX_CH]={0x000000};
	
	Input(ENCdata);
	for(unsigned int i=0;i<MAX_CH;i++)Xres[i]=EncDataToPosition(ENCdata[i],i);
	
}

double ENC6205::EncDataToPosition(unsigned long EncData, unsigned int ch){
	// エンコーダカウンタ値から位置[m]へ変換する
	// エンコーダ分解能 0.1μm  (4逓倍はボード側の設定を参照)
	return (double)((long)(EncData-0x7FFFFF)*Resolutions[ch]);
}

void ENC6205::Settings(void){
	// エンコーダカウンタの設定を行う関数
	
	iopl(3);	// I/O全アドレス空間にアクセス許可
	
	outb(0x06,BaseAddr[0]+0x04);	// CH1 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[0]+0x14);	// CH2 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[1]+0x04);	// CH3 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[1]+0x14);	// CH4 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[2]+0x04);	// CH5 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[2]+0x14);	// CH6 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[3]+0x04);	// CH7 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);
	outb(0x06,BaseAddr[3]+0x14);	// CH8 位相差パルス 4逓倍 非同期クリアモード
	usleep(100);

	return;
}


void ENC6205::Input(unsigned long ENCdata[MAX_CH]){
	// エンコーダカウンタからカウント値を読み込む関数
	
	unsigned short Hbuff=0x00, Mbuff=0x00, Lbuff=0x00; // カウンタ値取得バッファ
	
	outb(0x02,BaseAddr[0]+0x06);	// CH1 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[0]+0x16);	// CH2 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[1]+0x06);	// CH3 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[1]+0x16);	// CH4 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[2]+0x06);	// CH5 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[2]+0x16);	// CH6 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[3]+0x06);	// CH7 カウンタ値を読み出しレジスタに移動
	outb(0x02,BaseAddr[3]+0x16);	// CH8 カウンタ値を読み出しレジスタに移動
	
	// チャネル 1
	Lbuff=inb(BaseAddr[0]+0x00);	// CH1 下位 8bit データ取得
	Mbuff=inb(BaseAddr[0]+0x01);	// CH1 中位 8bit データ取得
	Hbuff=inb(BaseAddr[0]+0x02);	// CH1 上位 8bit データ取得
	ENCdata[0]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 2
	Lbuff=inb(BaseAddr[0]+0x10);	// CH2 下位 8bit データ取得
	Mbuff=inb(BaseAddr[0]+0x11);	// CH2 中位 8bit データ取得
	Hbuff=inb(BaseAddr[0]+0x12);	// CH2 上位 8bit データ取得
	ENCdata[1]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 3
	Lbuff=inb(BaseAddr[1]+0x00);	// CH3 下位 8bit データ取得
	Mbuff=inb(BaseAddr[1]+0x01);	// CH3 中位 8bit データ取得
	Hbuff=inb(BaseAddr[1]+0x02);	// CH3 上位 8bit データ取得
	ENCdata[2]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 4
	Lbuff=inb(BaseAddr[1]+0x10);	// CH4 下位 8bit データ取得
	Mbuff=inb(BaseAddr[1]+0x11);	// CH4 中位 8bit データ取得
	Hbuff=inb(BaseAddr[1]+0x12);	// CH4 上位 8bit データ取得
	ENCdata[3]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	
	// チャネル 5
	Lbuff=inb(BaseAddr[2]+0x00);	// CH5 下位 8bit データ取得
	Mbuff=inb(BaseAddr[2]+0x01);	// CH5 中位 8bit データ取得
	Hbuff=inb(BaseAddr[2]+0x02);	// CH5 上位 8bit データ取得
	ENCdata[4]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 6
	Lbuff=inb(BaseAddr[2]+0x10);	// CH6 下位 8bit データ取得
	Mbuff=inb(BaseAddr[2]+0x11);	// CH6 中位 8bit データ取得
	Hbuff=inb(BaseAddr[2]+0x12);	// CH6 上位 8bit データ取得
	ENCdata[5]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 7
	Lbuff=inb(BaseAddr[3]+0x00);	// CH7 下位 8bit データ取得
	Mbuff=inb(BaseAddr[3]+0x01);	// CH7 中位 8bit データ取得
	Hbuff=inb(BaseAddr[3]+0x02);	// CH7 上位 8bit データ取得
	ENCdata[6]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
	// チャネル 8
	Lbuff=inb(BaseAddr[3]+0x10);	// CH8 下位 8bit データ取得
	Mbuff=inb(BaseAddr[3]+0x11);	// CH8 中位 8bit データ取得
	Hbuff=inb(BaseAddr[3]+0x12);	// CH8 上位 8bit データ取得
	ENCdata[7]=IIIbyteCat(Hbuff,Mbuff,Lbuff);	// 上位、中位、下位データを24itのデータに結合する
	
}


void ENC6205::Zero(void){
	// エンコーダカウンタの値を零(0x800000)にする関数
	
	// チャネル 1
	outb(0x00,BaseAddr[0]+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[0]+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[0]+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 2
	outb(0x00,BaseAddr[0]+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[0]+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[0]+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 3
	outb(0x00,BaseAddr[1]+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[1]+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[1]+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 4
	outb(0x00,BaseAddr[1]+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[1]+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[1]+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 5
	outb(0x00,BaseAddr[2]+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[2]+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[2]+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 6
	outb(0x00,BaseAddr[2]+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[2]+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[2]+0x12);	// 上位カウンタへ書き込み
	
	// チャネル 7
	outb(0x00,BaseAddr[3]+0x00);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[3]+0x01);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[3]+0x02);	// 上位カウンタへ書き込み
	
	// チャネル 8
	outb(0x00,BaseAddr[3]+0x10);	// 下位カウンタへ書き込み
	outb(0x00,BaseAddr[3]+0x11);	// 中位カウンタへ書き込み
	outb(0x80,BaseAddr[3]+0x12);	// 上位カウンタへ書き込み
	
}

unsigned long ENC6205::IIIbyteCat(unsigned short High, unsigned short Middle, unsigned short Low){
	// 上位、中位、下位に分かれている各々1バイトのデータを、3バイトのデータに結合する
	// 例： 0xAB, 0xCD, 0xEF → 0xABCDEF
	unsigned long Hbuff=0, Mbuff=0, Lbuff=0, buff=0;
	Hbuff=(unsigned long)High   & 0x000000FF;
	Mbuff=(unsigned long)Middle & 0x000000FF;
	Lbuff=(unsigned long)Low    & 0x000000FF;
	
	// Hbuffを8bit左シフトしてMbuffとORを取り、その結果をさらに8bit左シフトしLbuffとORを取る
	buff = Hbuff << 8;
	buff = buff | Mbuff;
	buff = buff << 8;
	buff = buff | Lbuff;
	return buff;
}

