
#ifndef RTAITHREADING
#define RTAITHREADING

#include <stdio.h>
#include <rtai_lxrt.h>
#include <sys/io.h>

// 動作状態の定義
#define RTID_ERROR	-1	// エラー検出
#define RTID_STOP	0	// 停止状態
#define RTID_RUN	1	// 動作中
#define RTID_EXCMPL	2	// 終了動作完了

class RTAIthread {
	// RTAI実時間スレッド生成クラス
	private:
		static const int STACK_SIZE = 4096;	// スレッドスタックサイズ
		
		volatile int StateFlag;		// 動作状態フラグ
		char *TaskName;				// 実時間スレッド名(6文字まで)
		unsigned long Ts;			// 制御周期
		int Priority;				// 実時間スレッド優先順位
		void (*pRTfunc)(void*);		// 制御用実行関数へのポインタ
		void* pArg;					// 関数ポインタの引数
		long RealTimeThread_ID;		// 実時間スレッド識別子
		unsigned long Time;			// 時刻 ( 稼働できる時間 = Ts*2^(sizeof(unsigned long)*8) = 100e-6*2^32 = 約119時間(例) ) 稼働時間を伸ばしたければ「unsigned long long」にする
		long PeriodicTime;			// 計測された実際の周期時間
		long ComputationTime;		// 計算によって消費された時間 (つまり ComputationTime < PeriodicTime でなければならない)
		static void RealTimeThread(RTAIthread *pParam);	// 実時間スレッド
		
	public:
		// コンストラクタ Name；スレッド名，Time；制御周期，Prio；優先順位，RTfunc；制御用実行関数(関数ポインタ)
		RTAIthread(const char *Name, unsigned long Time, int Prio, void (*RTfunc)(void*), void* Arg);
		~RTAIthread();				// デストラクタ
		void SendState(int State);	// 動作状態を書き込む State；所望の動作状態
		int  ReadState(void);		// 動作状態を読み出す 戻り値；現在の動作状態
		unsigned long GetTime(void);// 時刻を取得する関数
		long GetSmplTime(void);		// 計測された実際のサンプリング時間を取得する関数
		long GetCompTime(void);		// 計測された消費時間を取得する関数
};


#endif

