// 加速度オブザーバクラス
// 2011/02/16 Yuki YOKOKURA
//
// 加速度オブザーバ
// 加速度参照値と外乱オブザーバによる推定外乱から加速度応答値を計算する

#ifndef ACCOBSRV
#define ACCOBSRV

class AccObsrv {
	private:
		double gacc;	// [rad/s]			加速度オブザーバの帯域
		double gdis;	// [rad/s]			外乱オブザーバの帯域
		double Mn;		// [kg] or [kgm^2]	慣性
		double Ts;		// [s]				制御周期
		double XDDrefZ1;// 					状態変数1
		double FdisZ1;	//					状態変数2
		double XDDresZ1;//					状態変数3
	
	public:
		AccObsrv(double AccBandwidth, double DistBandwidth, double Mass, double SmplTime);
		// コンストラクタ
		// gdis；[rad/s] 帯域，Mass；[kg] or [kgm^2] 慣性
		// TrqConst；[N/A] or [Nm/A] トルク定数，SmplTime；[s] 制御周期
		~AccObsrv();										// デストラクタ
		double GetAcceleration(double XDDref, double Fdis);	// 加速度応答の取得 XDDref；[m/s^2] 加速度参照値，Fdis；[N] 推定外乱
		void SetAccBandwidth(double Bandwidth);				// 加速度オブザーバの帯域の再設定 Bandwidth；[rad/s] 帯域
		void SetDistBandwidth(double Bandwidth);			// 外乱オブザーバの帯域の再設定 Bandwidth；[rad/s] 帯域
		void SetInertia(double Mass);						// 慣性の再設定 Mass；[kg] or [kgm^2] 慣性
		void SetSmplTime(double SmplTime);					// 制御周期の再設定 SmplTime；[s] 制御周期
		void ClearStateVars(void);							// すべての状態変数のリセット
};

#endif



