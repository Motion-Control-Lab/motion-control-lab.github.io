// フレームバッファグラフィックスクラス
// 2011/02/07 Yuki YOKOKURA
//
// 画面上に図等の描画を行います。ただし，/dev/fb* が必要。
//

#ifndef FRAMEGRAPHICS
#define FRAMEGRAPHICS

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <linux/fs.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <string.h>


// 色の定義 (色深度16bitモード用)
// ビットパターン MSB RRRRRGGGGGGBBBBB LSB (赤：ビット15～11 緑：ビット10～5 青：ビット4～0)
// 実は赤青に比べ緑の分解能が1bit分だけ多い
// 以下は基本色の定義  この他にも勝手に好きな色を作れる
#define FG_COLOR_RED		0xF800	// 赤
#define FG_COLOR_GREEN		0x07E0	// 緑
#define FG_COLOR_BLUE		0x001F	// 青
#define FG_COLOR_CYAN		FG_COLOR_GREEN | FG_COLOR_BLUE	// 水 (シアン)		// ORを取ると色が足せるよ～!
#define FG_COLOR_MAGENTA	FG_COLOR_RED | FG_COLOR_BLUE	// 紫 (マゼンタ)
#define FG_COLOR_YELLOW		FG_COLOR_RED | FG_COLOR_GREEN	// 黄 (イエロー)
#define FG_COLOR_BLACK		0x0000	// 黒
#define FG_COLOR_WHITE		0xFFFF	// 白
#define FG_COLOR_GRAY50		0x7BEF	// 灰 輝度50％
#define FG_COLOR_GRAY25		0x39E7	// 灰 輝度25％

class FrameGraphics {
	// フレームバッファクラス
	private:
		int FBfd;		// フレームバッファ ファイルディスクリプタ
		short *FBptr;	// フレームバッファ ポインタ
		struct fb_fix_screeninfo finfo;	// 固定情報構造体
		struct fb_var_screeninfo vinfo;	// 可変情報構造体
		int width;		// [px]		横幅
		int height;		// [px]		高さ
		int depth;		// [bits]	色深度
		int size;		// [bytes]	画面の大きさ
		int length;		// 			フレームバッファポインタの長さ
	
	public:
		FrameGraphics(const char* device);							// コンストラクタ フレームバッファ初期化
		~FrameGraphics(void);										// デストラクタ   フレームバッファ開放
		void ShowParam(void);										// 画面情報の表示
		void DrawPoint(int x, int y, short color);					// 点の描画
		void DrawLine(int x1, int y1, int x2, int y2, short color);	// 直線の描画
		void DrawRect(int x, int y, int w, int h, short color);		// 長方形の描画(色は塗らない)
		void DrawRectFill(int x, int y, int w, int h, short color);	// 長方形の描画(色を塗る)
		void ClearScreen(void);										// 画面の消去
		void ClearRect(int x, int y, int w, int h);					// 長方形の範囲内を消去
		int GetWidth(void);											// 画面の幅の取得
		int GetHeight(void);										// 画面の高さの取得
	

};

#endif

