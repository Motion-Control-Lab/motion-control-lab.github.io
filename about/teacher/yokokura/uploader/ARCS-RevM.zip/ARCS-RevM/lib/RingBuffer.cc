// リングバッファクラス
// 2011/02/14 Yuki YOKOKURA
//
// リングバッファ
//

#include "RingBuffer.hh"

RingBuffer::RingBuffer(unsigned long Length){
	// コンストラクタ Length；リングバッファの大きさ
	N=Length;				// バッファサイズ格納
	Buffer=new double [N];	// バッファ生成
	ClearBuffer();			// バッファクリア
	i=0;					// バッファカウンタクリア
}

RingBuffer::~RingBuffer(){
	// デストラクタ
	delete [] Buffer;	// バッファ消去
}

void RingBuffer::PutValue(double u){
	// 値をバッファに格納(同時にバッファのカウンタが増加) u；入力値
	i++;			// リングバッファカウンタ
	if(N<=i)i=0;	// カウンタリセット
	Buffer[i]=u;	// バッファに入力値を格納
}

double RingBuffer::GetValue(void){
	// バッファから最後尾の値を取り出す 戻り値；出力値
	unsigned long j;
	if(i==N-1){		// バッファカウンタがリングの終端に達していたら，
		j=0;		// リングの先端へ
	}else{
		j=i+1;		// それ以外は最後尾へ
	}
	return Buffer[j];
}

double* RingBuffer::GetPointer(void){
	// バッファへのポインタを返す(この関数は本来あるべきではないが，あると大変便利なので用意しておく)
	return Buffer;
}

void RingBuffer::SetCounter(unsigned long j){
	// カウンタを任意値に設定 j；任意のカウント値
	i=j;
}

void RingBuffer::ResetCounter(void){
	// カウンタリセット
	i=0;
}

void RingBuffer::ClearBuffer(void){
	// バッファのゼロクリア
	for(unsigned long j=0;j<N;j++)Buffer[j]=0;
}



