// 制御用周期実行関数群クラス
// 2011/02/09 Yuki YOKOKURA
//
// 実際の制御プログラムを実行します。
//

#ifndef CONTROL_FUNCTIONS
#define CONTROL_FUCNTIONS

#include <math.h>
#include "Parameters.hh"
#include "PCI-3340.hh"
#include "PCI-6205.hh"

#define RTID_CTRL_INIT	1	// 初期化モード
#define RTID_CTRL_LOOP	2	// 周期モード
#define RTID_CTRL_EXIT	3	// 終了処理モード

class ControlFunctions {
	private:
		volatile int CmdFlag;	// 動作モード設定フラグ
		// 制御用周期実行関数群
		static void ControlFunction0(ControlFunctions* pCF);	// 制御用周期実行関数0
		static void ControlFunction1(ControlFunctions* pCF);	// 制御用周期実行関数1
		static void ControlFunction2(ControlFunctions* pCF);	// 制御用周期実行関数2
		static void ControlFunction3(ControlFunctions* pCF);	// 制御用周期実行関数3
		static void ControlFunction4(ControlFunctions* pCF);	// 制御用周期実行関数4
		static void ControlFunction5(ControlFunctions* pCF);	// 制御用周期実行関数5
		static void ControlFunction6(ControlFunctions* pCF);	// 制御用周期実行関数6
		static void ControlFunction7(ControlFunctions* pCF);	// 制御用周期実行関数7
		
	public:
		ControlFunctions();									// コンストラクタ
		~ControlFunctions();								// デストラクタ
		void GetControlValue(VariableParams* VarParams);	// 制御用変数値を取得する関数
		void (*pCFuncs[8])(ControlFunctions*);				// 各制御用周期実行関数への関数ポインタ
};

#endif

