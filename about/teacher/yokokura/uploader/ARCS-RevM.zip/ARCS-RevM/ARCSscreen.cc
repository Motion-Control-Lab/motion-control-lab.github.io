// ARCS画面描画クラス
// 2011/02/09 Yuki YOKOKURA
//
// Advanced Robot Control System 用画面の描画を行います。
//

#include "ARCSscreen.hh"

ARCSscreen::ARCSscreen(void){
	// 画面描画の初期化と準備を行う
	initscr();		// 画面初期化
	noecho();		// エコーなし
	curs_set(0);	// カーソルを表示しない
	cbreak();		// 
	start_color();	// 色を使う
	init_pair(WHITE_BLACK,COLOR_WHITE,COLOR_BLACK);		// 色の定義
	init_pair(BLACK_CYAN,COLOR_BLACK,COLOR_CYAN);		// 色の定義
	init_pair(CYAN_BLACK,COLOR_CYAN,COLOR_BLACK);		// 色の定義
	init_pair(WHITE_BLUE,COLOR_WHITE,COLOR_BLUE);		// 色の定義
	init_pair(BLUE_BLACK,COLOR_BLUE,COLOR_BLACK);		// 色の定義
	init_pair(WHITE_RED,COLOR_WHITE,COLOR_RED);			// 色の定義 白字に背景が赤
	init_pair(BLACK_YELLOW,COLOR_BLACK,COLOR_YELLOW);	// 色の定義 黒字に背景が黄
	init_pair(BLACK_GREEN,COLOR_BLACK,COLOR_GREEN);		// 色の定義 黒字に背景が緑
	init_pair(GREEN_BLACK,COLOR_GREEN,COLOR_BLACK);		// 色の定義
	init_pair(RED_BLACK,COLOR_RED,COLOR_BLACK);			// 色の定義
	
	// 初期画面描画
	PrintScreen();							// 基本画面描画
	OperationIndic(false);					// 「IN OPERATION」消灯
	StorageIndic(false);					// 「DATA STORAGE」消灯
	NetLinkIndic(false);					// 「NETWORK LINK」消灯
	MessageText("Ready...",GREEN_BLACK);	// 準備完了メッセージ表示
	
	// グラフ描画準備
	FG = new FrameGraphics("/dev/fb0");	// フレームバッファグラフィックス生成
	GraphA = new GraphPlot2D;			// グラフA生成
	GraphB = new GraphPlot2D;			// グラフB生成
	
	// グラフの設定
	using namespace ConstParams;	// ここはさすがに using namespace を解禁
	attron(COLOR_PAIR(WHITE_BLACK));
	GraphA->SetAxis(*FG,GRAPH_A_TITLE,2,18,9,120,GRAPH_A_YMAX,GRAPH_A_YMIN,GRAPH_A_NUM);
	GraphB->SetAxis(*FG,GRAPH_B_TITLE,2,31,9,120,GRAPH_B_YMAX,GRAPH_B_YMIN,GRAPH_B_NUM);
	GraphA->Legend(GRAPH_A_NAMES);	// グラフA(上側)の凡例表示
	GraphB->Legend(GRAPH_B_NAMES);	// グラフB(下側)の凡例表示
	
	// 任意変数値表示のための変数名の表示
	for(unsigned int i=0;i<NUM_OPT_VARS;i++)mvprintw( 7+i,102,"%s",OPT_VAR_NAMES[i].c_str());
	
}

ARCSscreen::~ARCSscreen(void){
	// RCS画面表示の消去
	
	delete FG;
	delete GraphA;
	delete GraphB;
	
	endwin();
}

void ARCSscreen::AddHLine(int X1, int X2, int Y){
	// 水平罫線の描画
	int i=0;
	
	for(i=X1;i<=X2;i++){
		move(Y,i);addch(ACS_HLINE);
	}
	return;
}

void ARCSscreen::AddVLine(int Y1, int Y2, int X){
	// 垂直罫線の描画
	int i=0;
	
	for(i=Y1;i<=Y2;i++){
		move(i,X);addch(ACS_VLINE);
	}
	return;
}

void ARCSscreen::PrintScreen(void){
	// 画面の描画を行う  但し数値の描画は行わない
	// 描画関連の即値は許して。
	attron(COLOR_PAIR(BLACK_CYAN));
	move( 0,0);addstr(" ADVANCED ROBOT CONTROL SYSTEM  Ver.4.1                                                                                         ");
	mvprintw(0,111,ConstParams::ARCS_REVISION);
	attron(COLOR_PAIR(WHITE_BLUE));
	move( 1,0);addstr(" RTAI STATUS                                                                                                                    ");
	attron(COLOR_PAIR(WHITE_BLACK));
	move( 2,0);addstr("|TIME    |        sec |                                                                                         | IN OPERATION |");
	attron(COLOR_PAIR(WHITE_BLUE));move( 2,32);addstr("| THREAD0 | THREAD1 | THREAD2 | THREAD3 | THREAD4 | THREAD5 | THREAD6 | THREAD7 |");
	attron(COLOR_PAIR(WHITE_BLACK));
	move( 3,0);addstr("|STORAGE |    --- sec |SMPL TIME| ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | DATA STORAGE |");
	move( 4,0);addstr("|        |    --- %   |COMP TIME| ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | ---- us | NETWORK LINK |");
	attron(COLOR_PAIR(WHITE_BLUE));
	move( 6,0);addstr(" STATUS OF ACTUATORS                                                                                ");
																									   move( 6,101);addstr(" OPTIONAL VARIABLES        ");
	move( 7,11);          addstr("|    01         02         03         04         05         06         07         08    |");
	attron(COLOR_PAIR(WHITE_BLACK));
	move( 8,0);addstr("|STATUS    | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  |");
	move( 9,0);addstr("|FORCE     |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |");
	move(10,0);addstr("|POSITION  |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |");
	attron(COLOR_PAIR(WHITE_BLUE));
	move(11,11);          addstr("|    09    |    10    |    11    |    12    |    13    |    14    |    15    |    16    |");
	attron(COLOR_PAIR(WHITE_BLACK));
	move(12,0);addstr("|STATUS    | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  | STANDBY  |");
	move(13,0);addstr("|FORCE     |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |  ---- N  |");
	move(14,0);addstr("|POSITION  |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |  ---- mm |");
	attron(COLOR_PAIR(WHITE_BLUE));
	move(16,0);addstr(" WAVEFORMS                                                                                                                      ");
	move(44,0);addstr(" COMMAND                                                                                                                        ");
	
	// 罫線の描画を行う
	attron(COLOR_PAIR(BLUE_BLACK));
	AddVLine(2,5,0);AddVLine(2,5,9);AddVLine(2,5,22);AddVLine(2,5,32);AddVLine(2,5,42);AddVLine(2,5,52);AddVLine(2,5,62);AddVLine(2,5,72);AddVLine(2,5,82);AddVLine(2,5,92);AddVLine(2,5,102);AddVLine(2,5,112);AddVLine(2,5,127);
	AddHLine(1,127,5);move(5,0);addch(ACS_LLCORNER);move(5,9);addch(ACS_BTEE);move(5,22);addch(ACS_BTEE);move(5,32);addch(ACS_BTEE);move(5,42);addch(ACS_BTEE);move(5,52);addch(ACS_BTEE);move(5,62);addch(ACS_BTEE);move(5,72);addch(ACS_BTEE);move(5,82);addch(ACS_BTEE);move(5,92);addch(ACS_BTEE);move(5,102);addch(ACS_BTEE);move(5,112);addch(ACS_BTEE);move(5,127);addch(ACS_LRCORNER);
	AddVLine(7,15,101);AddVLine(7,15,114);AddVLine(7,15,127);AddHLine(101,127,15);move(15,101);addch(ACS_LLCORNER);move(15,114);addch(ACS_BTEE);move(15,127);addch(ACS_LRCORNER);
	AddVLine(8,15,0);AddVLine(8,15,11);AddVLine(8,15,22);AddVLine(8,15,33);AddVLine(8,15,44);AddVLine(8,15,55);AddVLine(8,15,66);AddVLine(8,15,77);AddVLine(8,15,88);AddVLine(8,15,99);
	AddHLine(0,99,15);move(15,0);addch(ACS_LLCORNER);move(15,11);addch(ACS_BTEE);move(15,22);addch(ACS_BTEE);move(15,33);addch(ACS_BTEE);move(15,44);addch(ACS_BTEE);move(15,55);addch(ACS_BTEE);move(15,66);addch(ACS_BTEE);move(15,77);addch(ACS_BTEE);move(15,88);addch(ACS_BTEE);move(15,99);addch(ACS_LRCORNER);
	move( 7,0);addch(ACS_VLINE);move( 7,11);addch(ACS_VLINE);move( 7,22);addch(ACS_VLINE);move( 7,33);addch(ACS_VLINE);move( 7,44);addch(ACS_VLINE);move( 7,55);addch(ACS_VLINE);move( 7,66);addch(ACS_VLINE);move( 7,77);addch(ACS_VLINE);move( 7,88);addch(ACS_VLINE);move( 7,99);addch(ACS_VLINE);
	AddVLine(17,43,0);AddVLine(17,43,127);AddHLine(0,127,43);move(43,0);addch(ACS_LLCORNER);move(43,127);addch(ACS_LRCORNER);
	AddVLine(45,45,0);AddVLine(45,45,127);AddHLine(0,127,46);move(46,0);addch(ACS_LLCORNER);move(46,127);addch(ACS_LRCORNER);
	
	refresh();
}

void ARCSscreen::PrintValue(VariableParams* VarParams){
	unsigned int i;
	attron(COLOR_PAIR(CYAN_BLACK));		// 文字色変更
	
	// 時刻の表示
	mvprintw(2,10,"%7.2lf",VarParams->Time);
	
	// 各スレッドにおける制御周期と消費時間の表示
	for(i=0;i<ConstParams::THREAD_NUM;i++){
		mvprintw(3, 33+10*i,"%5ld",(long)VarParams->PeriodicTime[i]);
		mvprintw(4, 33+10*i,"%5ld",VarParams->ComputationTime[i]);
	}
	
	// 推力指令値の表示
	for(i=0;i<ConstParams::NUM_CH_3340;i++){
		mvprintw( 9,12+11*i,"%6.2lf",VarParams->IrefA[i]*ConstParams::Kf_A[i]);
	}

	// 位置応答値の表示 ([mm]にするので 1e3 を掛ける)
	for(i=0;i<ConstParams::NUM_CH_6205;i++){
		mvprintw(10,12+11*i,"%6.2lf",VarParams->XresA[i]*1e3);
	}
	
	// モータ状態表示
	for(i=0;i<ConstParams::NUM_CH_3340;i++){
		StatusIndic(8,12+11*i,VarParams->IrefA[i],ConstParams::Irat_A[i],ConstParams::Imax_A[i]);
	}
	
	// 任意変数値の表示
	for(i=0;i<ConstParams::NUM_OPT_VARS;i++){
		mvprintw(7+i,117,"%5.4G",VarParams->OptionalVars[i]);
	}
	
	// グラフの描画
	attron(COLOR_PAIR(WHITE_BLACK));	// 文字色変更
	GraphA->DrawWave(VarParams->Time,VarParams->GraphA);	// グラフAに波形を描画
	GraphB->DrawWave(VarParams->Time,VarParams->GraphB);	// グラフBに波形を描画
	
	refresh();	// ARCS画面更新
}

void ARCSscreen::OperationIndic(bool SW){
	// 「IN OPERATION」の描画を制御する関数
	// SW；true=点灯，false=消灯
	if(SW==true){
		attron(COLOR_PAIR(BLACK_CYAN));
	}else{
		attron(COLOR_PAIR(CYAN_BLACK));
	}
	move(2,113);
	addstr(" IN OPERATION ");
}

void ARCSscreen::StorageIndic(bool SW){
	// 「DATA STORAGE」の描画を制御する関数
	// SW；true=点灯，false=消灯
	move(3,113);
	if(SW==true){
		attron(A_BLINK);
		attron(COLOR_PAIR(BLACK_CYAN));
		addstr(" DATA STORAGE ");
		attroff(A_BLINK);
	}else{
		attron(COLOR_PAIR(CYAN_BLACK));
		addstr(" DATA STORAGE ");
	}
	
}

void ARCSscreen::NetLinkIndic(bool SW){
	// 「NETWORK LINK」の描画を制御する関数
	// SW；true=点灯，false=消灯
	if(SW==true){
		attron(COLOR_PAIR(BLACK_CYAN));
	}else{
		attron(COLOR_PAIR(CYAN_BLACK));
	}
	move(4,113);
	addstr(" NETWORK LINK ");
}

void ARCSscreen::StartCommand(enum CMD_ID command){
	// 「START」の描画を制御する関数
	// command；CMD_ON=点灯，CMD_OFF=消灯，CMD_DISABLE=無効
	if(command==CMD_ON )attron(COLOR_PAIR(BLACK_CYAN));
	if(command==CMD_OFF)attron(COLOR_PAIR(CYAN_BLACK));
	if(command==CMD_DISABLE)attron(COLOR_PAIR(BLUE_BLACK));
	move(45,2);
	addstr("       START       ");
}

void ARCSscreen::ExitCommand(enum CMD_ID command){
	// 「EXIT」の描画を制御する関数
	// command；CMD_ON=点灯，CMD_OFF=消灯，CMD_DISABLE=無効
	if(command==CMD_ON )attron(COLOR_PAIR(BLACK_CYAN));
	if(command==CMD_OFF)attron(COLOR_PAIR(CYAN_BLACK));
	if(command==CMD_DISABLE)attron(COLOR_PAIR(BLUE_BLACK));
	move(45,24);
	addstr("        EXIT        ");
}

void ARCSscreen::StopCommand(enum CMD_ID command){
	// 「STOP」の描画を制御する関数
	// command；CMD_ON=点灯，CMD_OFF=消灯，CMD_DISABLE=無効
	if(command==CMD_ON )attron(COLOR_PAIR(BLACK_CYAN));
	if(command==CMD_OFF)attron(COLOR_PAIR(CYAN_BLACK));
	if(command==CMD_DISABLE)attron(COLOR_PAIR(BLUE_BLACK));
	move(45,46);
	addstr("        STOP        ");
}

void ARCSscreen::DiscExitCommand(enum CMD_ID command){
	// 「DISCARD and EXIT」の描画を制御する関数
	// command；CMD_ON=点灯，CMD_OFF=消灯，CMD_DISABLE=無効
	if(command==CMD_ON )attron(COLOR_PAIR(BLACK_CYAN));
	if(command==CMD_OFF)attron(COLOR_PAIR(CYAN_BLACK));
	if(command==CMD_DISABLE)attron(COLOR_PAIR(BLUE_BLACK));
	move(45,68);
	addstr("  DISCARD and EXIT  ");
}

void ARCSscreen::SaveExitCommand(enum CMD_ID command){
	// 「SAVE and EXIT」の描画を制御する関数
	// command；CMD_ON=点灯，CMD_OFF=消灯，CMD_DISABLE=無効
	if(command==CMD_ON )attron(COLOR_PAIR(BLACK_CYAN));
	if(command==CMD_OFF)attron(COLOR_PAIR(CYAN_BLACK));
	if(command==CMD_DISABLE)attron(COLOR_PAIR(BLUE_BLACK));
	move(45,90);
	addstr("   SAVE and EXIT   ");
}

int ARCSscreen::CommandInput(int phase){
	// 指令入力画面の描画と入力をする関数
	int InKey, count=0;
	keypad(stdscr, TRUE);	// 特殊文字が使えるようにする
	
	CommandPrintInit(phase, &count);	// 指令画面の初期状態の描画
	
	while(1){
		InKey=getch();					// キー入力待機
		if(InKey=='\n')break;			// ENTERが押されたらループを抜ける
		if(InKey==KEY_RIGHT)count++;	// 「→」が押されたらカウントアップ
		if(InKey==KEY_LEFT)count--;		// 「←」が押されたらカウントダウン
		
		CommandPrint(phase, &count);	// カウント値に従って描画
	}
	
	if(count==0)return ARCS_ID_START;
	if(count==1)return ARCS_ID_EXIT;
	if(count==2)return ARCS_ID_STOP;
	if(count==3)return ARCS_ID_DISCEXIT;
	if(count==4)return ARCS_ID_SAVEEXIT;
	return 0;
}

void ARCSscreen::CommandPrint(int phase, int* count){
	// 指令入力画面の描画をする関数
	
	if(phase==ARCS_PHASE_START){
		StartCommand(CMD_OFF);
		ExitCommand(CMD_OFF);
		if(*count<0)*count=0;
		if(1<*count)*count=1;
	}
	if(phase==ARCS_PHASE_EXIT){
		DiscExitCommand(CMD_OFF);
		SaveExitCommand(CMD_OFF);
		if(*count<3)*count=3;
		if(4<*count)*count=4;
	}
	
	if(*count==0)StartCommand(CMD_ON);
	if(*count==1)ExitCommand(CMD_ON);
	if(*count==2)StopCommand(CMD_ON);
	if(*count==3)DiscExitCommand(CMD_ON);
	if(*count==4)SaveExitCommand(CMD_ON);
}

void ARCSscreen::CommandPrintInit(int phase, int* count){
	if(phase==ARCS_PHASE_START){
		StartCommand(CMD_ON);
		ExitCommand(CMD_OFF);
		StopCommand(CMD_DISABLE);
		DiscExitCommand(CMD_DISABLE);
		SaveExitCommand(CMD_DISABLE);
		*count=0;
	}
	if(phase==ARCS_PHASE_EXIT){
		StartCommand(CMD_DISABLE);
		ExitCommand(CMD_DISABLE);
		StopCommand(CMD_DISABLE);
		DiscExitCommand(CMD_ON);
		SaveExitCommand(CMD_OFF);
		*count=3;
	}
}

void ARCSscreen::Start(void){
	OperationIndic(true);			// 「IN OPERATION」点灯
	StorageIndic(true);				// 「DATA STORAGE」点灯
	StartCommand(CMD_DISABLE);		// 「START」無効
	ExitCommand(CMD_DISABLE);		// 「EXIT」無効
	StopCommand(CMD_ON);			// 「STOP」点灯
	DiscExitCommand(CMD_DISABLE);	// 「DISCARD and EXIT」無効
	SaveExitCommand(CMD_DISABLE);	// 「SAVE and EXIT」無効
	MessageText("Control System Running...",RED_BLACK);	// 動作中メッセージ表示
}

void ARCSscreen::Stop(void){
	OperationIndic(false);			// 「IN OPERATION」消灯
	StorageIndic(false);			// 「DATA STORAGE」消灯
	MessageText("Operation Stopped.",GREEN_BLACK);	// 動作中メッセージ表示
}

void ARCSscreen::StatusIndic(int y, int x, double Iref, double Irat, double Imax){
	// モータ状態表示
	if( Iref<=-Imax || Imax<=Iref){
		attron(COLOR_PAIR(WHITE_RED));			// 文字色変更
		mvprintw(y,x," OVERLOAD ");				// 最大推力を超える場合
	}else{
		if( Iref<=-Irat || Irat<=Iref){
			attron(COLOR_PAIR(BLACK_YELLOW));	// 文字色変更
			mvprintw(y,x," WARNING  ");			// 定格推力を超える場合
		}else{
			attron(COLOR_PAIR(BLACK_GREEN));	// 文字色変更
			mvprintw(y,x,"  NORMAL  ");			// 定格推力未満の場合
		}
	}
	attron(COLOR_PAIR(CYAN_BLACK));				// 文字色変更
}

void ARCSscreen::MessageText(const char* Text, int color){
	// ARCS画面一番下にメッセージを表示する関数
	attron(COLOR_PAIR(color));
	mvprintw(47,1,"                                                                                                                               ");
	mvprintw(47,1,"%s",Text);
	refresh();
}

