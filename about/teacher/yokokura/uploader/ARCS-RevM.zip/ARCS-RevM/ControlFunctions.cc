// 制御用周期実行関数群クラス
// 2011/02/09 Yuki YOKOKURA
//
// 実際の制御プログラムを実行します。
//

#include "ControlFunctions.hh"

// スレッド間での値のやり取りにはグローバル変数を使う
// 但し，「static」を付けて変数のスコープをこのソース内に留めること
// Spinlock or Mutex による排他制御をすべきだが実際に問題が出てから実装する
static volatile unsigned long count=0;		// [回]	ループカウンタ (ControlFunction0を基準とする)
static volatile double t=0;					// [s]	時刻 (ControlFunction0を基準とする)
static volatile double GraphA[ConstParams::MAX_GRAPH_A]={0};		//		グラフA(上側)の表示値格納用 (ここに書き込めば好きな値を描画できる(最大8つまで))
static volatile double GraphB[ConstParams::MAX_GRAPH_B]={0};		//		グラフB(下側)の表示値格納用 (ここに書き込めば好きな値を描画できる(最大8つまで))
static volatile double OptionalVars[ConstParams::MAX_OPT_VARS]={0};	// 		任意変数値表示用 (ここに書き込めば好きな値を表示できる(最大8つまで))
static volatile double IrefA[ConstParams::NUM_CH_3340]={0};			// [A]	D/Aコンバータ      1枚目 電流指令値
static volatile double XresA[ConstParams::NUM_CH_6205]={0};			// [m]	エンコーダカウンタ 1枚目 位置応答値

// 制御用周期実行関数群
// 以下の関数は初期化モード若しくは終了処理モードのときに非実時間空間上で動作する
// 周期モードのときは実時間スレッド( RTAItask.cc の RTAItask関数 で生成された RTAIthread.cc の RealTimeThread関数 )
// から関数ポインタを経由して，以下の関数が呼ばれる

void ControlFunctions::ControlFunction0(ControlFunctions* pCF){
	// 制御用周期実行関数0
	
	// 制御用定数設定
	//static DAC3340* DacA;	// D/Aコンバータボード 1枚目
	//static ENC6205* EncA;	// エンコーダカウンタボード 1枚目
	
	// 制御用変数宣言
	const double Ts = ConstParams::Ts[0]*1e-9;
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		//DacA = new DAC3340(ConstParams::Base3340_A,ConstParams::Imax_A,ConstParams::VAconv_A);	// D/Aコンバータ 1枚目 初期化処理
		//EncA = new ENC6205(ConstParams::Base6205_A,ConstParams::EncResolutions_A); 				// エンコーダカウンタ 1枚目 初期化処理
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
		count++;	// ループカウンタを進める
		t=count*Ts;	// 時刻の計算
		
		//EncA->InPositionRes(XresA);	// エンコーダカウンタボード 1枚目 から位置応答値を入力
		//DacA->OutCurrentCmd(IrefA);	// D/Aコンバータボード 1枚目 から電流指令値を出力
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
		//delete DacA;	// D/Aコンバータボード 1枚目 終了処理
		//delete EncA;	// エンコーダカウンタボード 1枚目 終了処理
	}
}


void ControlFunctions::ControlFunction1(ControlFunctions* pCF){
	// 制御用周期実行関数1
	
	// 制御用定数宣言
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
		GraphA[0]=1.0*sin(2.0*3.14159265358979*0.5*t);
		GraphA[1]=1.0*sin(2.0*3.14*0.5*t);
		GraphA[2]=1.0*sin(2.0*3.14*0.5*t+0.707+0.707);
		GraphA[3]=1.5*cos(2.0*3.14*0.5*t);
		GraphA[4]=1.5*cos(2.0*3.14*0.5*t+0.707);
		GraphA[5]=1.5*cos(2.0*3.14*0.5*t+0.707+0.707);
		GraphA[6]=1.5*cos(2.0*3.14*0.5*t+0.707+0.707+0.707);
		GraphA[7]=0.5*sin(2.0*3.14*0.5*t+0.707+0.707+0.707);
		GraphB[0]=30.0*sin(2.0*3.14*2.0*t)*cos(2.0*3.14*0.1*t);
		OptionalVars[0]=3.14159265358979;
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction2(ControlFunctions* pCF){
	// 制御用周期実行関数2
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction3(ControlFunctions* pCF){
	// 制御用周期実行関数3
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction4(ControlFunctions* pCF){
	// 制御用周期実行関数4
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction5(ControlFunctions* pCF){
	// 制御用周期実行関数5
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction6(ControlFunctions* pCF){
	// 制御用周期実行関数6
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::ControlFunction7(ControlFunctions* pCF){
	// 制御用周期実行関数7
	
	// 制御用定数設定
	
	// 制御用変数宣言
	
	if(pCF->CmdFlag==RTID_CTRL_INIT){
		// 初期化モード (ここは制御開始時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
	if(pCF->CmdFlag==RTID_CTRL_LOOP){
		// 周期モード (ここは制御周期Ts1毎に呼び出される(実時間空間なので処理は制御周期内に収めること))
	}
	if(pCF->CmdFlag==RTID_CTRL_EXIT){
		// 終了処理モード (ここは制御終了時に1度だけ呼び出される(非実時間空間なので重い処理もOK))
	}
}

void ControlFunctions::GetControlValue(VariableParams* VarParams){
	// 制御用変数値を取得する関数
	
	// memcpyは使用不可(キャストによる volatile の無効化は禁止)
	unsigned int i;
	for(i=0;i<ConstParams::NUM_CH_3340;i++){
		VarParams->IrefA[i]=IrefA[i];				// [A]	D/Aコンバータ      1枚目 電流指令値
	}
	for(i=0;i<ConstParams::NUM_CH_6205;i++){
		VarParams->XresA[i]=XresA[i];				// [m]	エンコーダカウンタ 1枚目 位置応答値
	}
	for(i=0;i<ConstParams::GRAPH_A_NUM;i++){
		VarParams->GraphA[i]=GraphA[i];				//		グラフA(上側)の表示値
	}
	for(i=0;i<ConstParams::GRAPH_B_NUM;i++){
		VarParams->GraphB[i]=GraphB[i];				//		グラフB(下側)の表示値
	}
	for(i=0;i<ConstParams::NUM_OPT_VARS;i++){
		VarParams->OptionalVars[i]=OptionalVars[i];	// 		任意変数値表示用
	}

}

ControlFunctions::ControlFunctions(){
	// コンストラクタ
	
	// 各制御用周期実行関数の関数ポインタを格納 (関数の配列となる)
	// (実時間スレッド生成に必要な作業)
	pCFuncs[0]=ControlFunction0;	pCFuncs[4]=ControlFunction4;
	pCFuncs[1]=ControlFunction1;	pCFuncs[5]=ControlFunction5;
	pCFuncs[2]=ControlFunction2;	pCFuncs[6]=ControlFunction6;
	pCFuncs[3]=ControlFunction3;	pCFuncs[7]=ControlFunction7;
	
	// 初期化モードでの各制御用周期実行関数の実行
	CmdFlag=RTID_CTRL_INIT;		// フラグを初期化モードに設定して，
	for(unsigned int i=0;i<ConstParams::THREAD_NUM;i++)(*pCFuncs[i])(this);	// 各々の制御関数(関数の配列)を実行
	CmdFlag=RTID_CTRL_LOOP;		// フラグを周期モードに設定
}

ControlFunctions::~ControlFunctions(){
	// デストラクタ
	
	// 終了処理モードでの各制御用周期実行関数の実行
	CmdFlag=RTID_CTRL_EXIT;		// フラグを終了処理モードに設定して，
	for(unsigned int i=0;i<ConstParams::THREAD_NUM;i++)(*pCFuncs[i])(this);	// 各々の制御関数(関数の配列)を実行
}

