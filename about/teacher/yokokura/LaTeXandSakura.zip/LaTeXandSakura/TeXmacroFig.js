Editor.InsText('\\begin{figure}[t]\r\n');
Editor.InsText('	\\centering\r\n');
Editor.InsText('	\\includegraphics[width=\\hsize,clip]{FILENAME.eps}\r\n');
Editor.InsText('	\\caption{CAPTION}\r\n');
Editor.InsText('	\\label{fig:LABEL}\r\n');
Editor.InsText('\\end{figure}\r\n');
