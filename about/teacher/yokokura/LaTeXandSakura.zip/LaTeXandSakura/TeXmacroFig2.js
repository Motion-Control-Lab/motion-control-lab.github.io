// �Q�J�����ŉ摜�����ɂQ���\��t����
Editor.InsText('\\begin{figure*}[t]\r\n');
Editor.InsText('	\\begin{minipage}{0.5 \\hsize}\r\n');
Editor.InsText('		\\centering\r\n');
Editor.InsText('		\\includegraphics[width=\\hsize,clip]{FILENAME.eps}\r\n');
Editor.InsText('		\\caption{CAPTION}\r\n');
Editor.InsText('		\\label{fig:LABEL}\r\n');
Editor.InsText('	\\end{minipage}\r\n');
Editor.InsText('	\\begin{minipage}{0.5 \\hsize}\r\n');
Editor.InsText('		\\centering\r\n');
Editor.InsText('		\\includegraphics[width=\\hsize,clip]{FILENAME.eps}\r\n');
Editor.InsText('		\\caption{CAPTION}\r\n');
Editor.InsText('		\\label{fig:LABEL}\r\n');
Editor.InsText('	\\end{minipage}\r\n');
Editor.InsText('\\end{figure*}\r\n');
